"""Small, defensive validators for untrusted external data."""
from __future__ import annotations

import re
from typing import Any, List, Optional
from urllib.parse import urlparse


def clean_url(url: Any) -> Optional[str]:
    """Return the URL only if it is a well-formed http(s) URL, else None."""
    if not isinstance(url, str):
        return None
    url = url.strip()
    if not url or len(url) > 2048 or re.search(r"\s", url):
        return None
    try:
        p = urlparse(url)
    except ValueError:
        return None
    if p.scheme not in ("http", "https") or not p.netloc or "." not in p.netloc:
        return None
    if p.username or p.password:  # never follow credential-bearing links
        return None
    return url


def to_float(value: Any) -> Optional[float]:
    """Parse numbers like 1299, '1,299.50', '₹ 12,999'. Returns None if not parseable."""
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value) if value == value and abs(value) != float("inf") else None
    if isinstance(value, str):
        groups = re.findall(r"\d[\d,]*(?:\.\d+)?", value)
        if len(groups) != 1:  # "", "abc" or ranges like "₹1,299 - ₹1,999": do not guess
            return None
        try:
            num = float(groups[0].replace(",", ""))
        except ValueError:
            return None
        return -num if value.strip().startswith("-") else num
    return None


def to_int(value: Any) -> Optional[int]:
    f = to_float(value)
    return int(f) if f is not None and f >= 0 else None


def clean_str_list(value: Any, lower: bool = False) -> List[str]:
    if isinstance(value, str):
        value = [v for v in re.split(r"[,;|]", value)]
    if not isinstance(value, (list, tuple)):
        return []
    out = []
    for v in value:
        if isinstance(v, (str, int, float)) and not isinstance(v, bool):
            s = str(v).strip()
            if s:
                out.append(s.lower() if lower else s)
    return out
