"""Google Shopping results via Serper (https://serper.dev), POST /shopping.

Implemented from Serper's public documentation and unit-tested against a response *fixture*. NOT called against
the live service from this build. Merchant coverage (e.g. Amazon.in / Flipkart) is decided by Google Shopping.
"""
from __future__ import annotations

from typing import Any, List

from src.config import Settings
from src.data_validation import normalize_products
from src.models import Product, SearchCriteria
from src.providers._shopping import now_iso, request_json, search_text
from src.providers.base import ProviderBase, ProviderError

ENDPOINT = "https://google.serper.dev/shopping"


def parse_response(data: Any, name: str = "Serper") -> List[dict]:
    if not isinstance(data, dict):
        raise ProviderError(f"{name}: unexpected response format.")
    items = data.get("shopping")
    if items is None:
        return []
    if not isinstance(items, list):
        raise ProviderError(f"{name}: unexpected 'shopping' format.")
    return [{
        "id": it.get("productId") or it.get("position"), "name": it.get("title"), "seller": it.get("source"),
        "price": it.get("price"), "url": it.get("link"), "image_url": it.get("imageUrl"),
        "rating": it.get("rating"), "review_count": it.get("ratingCount"), "delivery": it.get("delivery"),
    } for it in items if isinstance(it, dict)]


class SerperShoppingProvider(ProviderBase):
    name = "Google Shopping via Serper"
    source_type = "live"

    def __init__(self, settings: Settings):
        self.s = settings

    def is_available(self) -> bool:
        return bool(self.s.serper_key)

    def search(self, criteria: SearchCriteria, limit: int = 40) -> List[Product]:
        if not self.is_available():
            raise ProviderError(f"{self.name}: SERPER_API_KEY is not set.")
        text = search_text(criteria)
        if not text:
            return []
        data = request_json(self.s, self.name, "POST", ENDPOINT, self.s.product_api_timeout,
                            headers={"X-API-KEY": self.s.serper_key, "Content-Type": "application/json"},
                            json={"q": text, "gl": "in", "hl": "en", "num": min(limit, 40)})
        products, _ = normalize_products(parse_response(data, self.name)[:limit], self.name, "live",
                                         retrieved_at=now_iso(), default_currency=self.s.currency)
        return products
