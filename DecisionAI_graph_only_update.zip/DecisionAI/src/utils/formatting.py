"""Formatting helpers and safe purchase-link handling."""
from __future__ import annotations

from typing import Optional, Tuple
from urllib.parse import parse_qsl, quote_plus, urlencode, urlparse, urlunparse

from src.models import Product
from src.utils.validation import clean_url


def format_inr(amount: Optional[float]) -> str:
    """12345678 -> ₹1,23,45,678 (Indian digit grouping)."""
    if amount is None:
        return "—"
    n = int(round(amount))
    sign = "-" if n < 0 else ""
    s = str(abs(n))
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        s = ",".join(parts) + "," + tail
    return f"{sign}₹{s}"


def format_price(amount: Optional[float], currency: str = "INR") -> str:
    if currency == "INR":
        return format_inr(amount)
    return "—" if amount is None else f"{amount:,.2f} {currency}"


def add_affiliate(url: str, amazon_tag: str = "") -> Tuple[str, bool]:
    """Append the configured Amazon Associates tag to amazon.* product URLs. Returns (url, applied)."""
    if not amazon_tag:
        return url, False
    p = urlparse(url)
    host = p.netloc.lower()
    if not (host.startswith("amazon.") or ".amazon." in host):
        return url, False
    q = [(k, v) for k, v in parse_qsl(p.query) if k != "tag"] + [("tag", amazon_tag)]
    return urlunparse(p._replace(query=urlencode(q))), True


def search_links(name: str) -> dict:
    q = quote_plus(name)
    return {
        "Google Shopping (India)": f"https://www.google.com/search?tbm=shop&gl=in&q={q}",
        "Amazon.in search": f"https://www.amazon.in/s?k={q}",
        "Flipkart search": f"https://www.flipkart.com/search?q={q}",
    }


def buy_link(product: Product, amazon_tag: str = "") -> Tuple[str, str, bool, bool]:
    """Return (url, button_label, is_direct, affiliate_applied).

    Direct product URL if valid; otherwise a clearly labelled search link (never an invented product link).
    """
    direct = clean_url(product.url)
    if direct:
        url, applied = add_affiliate(direct, amazon_tag)
        return url, "View Deal", True, applied
    return search_links(product.name)["Google Shopping (India)"], "Search for this product", False, False


def retailer_search_url(retailer: str, text: str) -> Optional[str]:
    """Labelled search link for retailers we know the public search URL of (never a product page)."""
    q = quote_plus(text)
    return {"amazon_in": f"https://www.amazon.in/s?k={q}", "flipkart": f"https://www.flipkart.com/search?q={q}"}.get(retailer)
