"""Application service: everything the web UI needs, as plain functions returning JSON-ready dicts."""
from __future__ import annotations

import hashlib
import logging
import re
from typing import Dict, List, Optional
from urllib.parse import urlparse

from src import rag
from src.assistant import DecisionAssistant
from src.config import Settings
from src.db import Database
from src.identity import RETAILERS, identity_key
from src.insights import price_insight
from src.llm import LLMClient, LLMError, explanation_is_grounded
from src.offers import build_offers, offer_stats
from src.product_search import sort_groups, validate_budget
from src.url_extractor import UrlReadError, extract_product_from_url
from src.url_intake import HOSTS
from src.identity import tokens as _tokens
from src.utils.formatting import format_inr

log = logging.getLogger("decision_assistant")
REC_KEYS = {"Best Overall": "best_overall", "Lowest Price": "cheapest_suitable", "Best Value": "best_value"}
CATEGORIES = {"phone", "laptop", "ssd", "mouse"}


class ApiError(Exception):
    def __init__(self, status: int, message: str, extra: Optional[dict] = None):
        super().__init__(message)
        self.status, self.message, self.extra = status, message, extra or {}


def product_key(group) -> str:
    return hashlib.sha1(identity_key(group).encode()).hexdigest()[:12]


def _norm_link(u: str) -> str:
    p = urlparse(u or "")
    return (p.netloc.lower().replace("www.", "") + p.path.rstrip("/")).lower()


class AppService:
    def __init__(self, settings: Optional[Settings] = None, db: Optional[Database] = None,
                 assistant: Optional[DecisionAssistant] = None, llm: Optional[LLMClient] = None, url_reader=None):
        self.settings = settings or Settings.from_env()
        self.db = db or Database(self.settings.db_path)
        self.llm = llm or LLMClient(self.settings)
        self.assistant = assistant or DecisionAssistant(self.settings, llm=self.llm)
        self._insight_cache: Dict[str, Optional[str]] = {}
        self.url_reader = url_reader or extract_product_from_url

    # ------------------------------------------------------------------ search
    def _need_provider(self) -> None:
        if not self.assistant.search.providers:
            raise ApiError(503, "No product data provider is configured. Add your SerpApi key as SERPAPI_KEY in the .env file "
                                "(get one at serpapi.com) and restart the app.", {"code": "no_provider"})

    def search(self, p: dict) -> dict:
        q, url_info = (p.get("query") or p.get("q") or "").strip(), None
        if (p.get("url") or "").strip():
            self._need_provider()
            try:
                info = self.url_reader(p["url"].strip())
            except UrlReadError as e:
                raise ApiError(422, f"{e.message} Please enter the product name instead.",
                               {"code": "url_unreadable", "suggested_query": e.suggested_query})
            url_info = {k: info.get(k) for k in ("url", "retailer", "retailer_name", "recognised", "title", "brand", "variant", "price",
                                                 "currency", "image_url", "source")}
            url_info["notes"] = ["Product details were read from the page's own metadata (" + str(info.get("source")) + ").",
                                 "Any price shown here is what that page listed; the comparison below uses only prices from the data provider."]
            q = info["title"]
        if not q:
            raise ApiError(400, "Enter a product name, or paste a product URL.")
        if len(q) > 200:
            raise ApiError(400, "That search is too long. Please shorten it.")
        self._need_provider()
        budget, err = validate_budget(p.get("budget"))
        if err:
            raise ApiError(400, err)
        category = p.get("category") if p.get("category") in CATEGORIES else None
        use_ai = str(p.get("ai", "1")) != "0"

        # A user-initiated search is an explicit refresh: bypass provider cache so
        # current offers and genuine price snapshots can be collected immediately.
        fetched = self.assistant.fetch(q, {"category": category}, use_ai=use_ai, force_refresh=bool(p.get("refresh", True)))
        self._raise_if_all_failed(fetched.outcome)
        c = fetched.criteria
        brands = list(dict.fromkeys(c.brands + ([p["brand"].strip()] if (p.get("brand") or "").strip() else [])))
        filters = {"max_budget": budget or c.max_budget, "brands": brands, "category": category or c.category,
                   "use_case": c.use_case, "features": c.features, "priorities": c.priorities, "budget_tolerance": 0.0,
                   "sellers": [], "conditions": [], "in_stock_only": False}
        res = self.assistant.rank(fetched, filters, None, use_ai=use_ai)
        out = res.outcome
        groups = sort_groups(out.products, out.tiers, "relevance")
        rec_groups = {product_key(r.scored.product): r.scored.product for r in res.result.recommendations}
        shown = groups[:8]
        for k, g in rec_groups.items():
            if all(product_key(x) != k for x in shown):
                shown.append(g)
        tag = self.settings.amazon_affiliate_tag
        views, affiliate, triggered = [], False, []
        for g in shown:
            v, aff = self._view(g, tag, url_info, out.intent, out.tiers.get(identity_key(g)))
            views.append(v)
            affiliate = affiliate or aff
            self.db.upsert_product(v["key"], v)
            live = [o for o in v["offers"] if o["available"] and o["source_type"] == "live"]
            if live:
                # Keep offer identity stable across searches. Aggregator/search URLs
                # can contain per-search tokens and must not create a new seller row.
                # Only persist a URL as the offer identity when it is a direct merchant URL.
                self.db.record_offers(
                    v["key"],
                    [{"seller_id": o["seller_id"], "seller": o["seller"], "price": o["price"],
                      "url": o["url"] if o["kind"] == "direct" else None, "url_kind": o["kind"],
                      "currency": o["currency"], "source": o["source"]} for o in live],
                    min_gap_hours=0,
                )
                best = min(live, key=lambda o: o["price"])
                for a in self.db.trigger_alerts(v["key"], best["price"], best["seller"]):
                    triggered.append({"id": a["id"], "product": v["name"], "target": a["target_price"], "price": best["price"], "seller": best["seller"]})
        for v in views:
            series = Database.daily_series(self.db.history(v["key"]))
            v["history_days"] = len(series)
            v["insight"] = self._insight(v, series, use_ai and v is views[0])
        by_key = {v["key"]: v for v in views}
        recs, ai = {}, res.ai_explanation or {}
        for r in res.result.recommendations:
            k = product_key(r.scored.product)
            recs[REC_KEYS[r.label]] = {"key": k, "name": r.scored.product.name, "reason": ai.get(r.label) or r.reason,
                                       "ai": bool(ai.get(r.label)), "pros": r.scored.pros[:3], "cons": r.scored.cons[:2]}
        if "best_value" not in recs:
            recs["best_value"] = None
        order = [v["key"] for v in views]
        if out.products:
            self.db.add_search(q, product_key(groups[0]), out.mode)
        compare_keys = [product_key(g) for g in res.compare_top]
        return {
            "query": q, "interpreted": {"category": res.criteria.category, "budget": res.criteria.max_budget, "brands": res.criteria.brands,
                                        "use_case": res.criteria.use_case, "features": res.criteria.features},
            "url": url_info,
            "mode": out.mode, "demo": False, "ai": {"enabled": self.llm.available, "understood": res.ai_understood,
                                                               "explained": bool(res.ai_explanation), "summary": ai.get("summary")},
            "products": views, "order": order, "recommendations": recs, "compare_keys": compare_keys,
            "offer_count": out.offer_count, "seller_count": out.seller_count, "notes": res.result.notes[:3],
            "suggestions": out.suggestions, "messages": res.messages, "affiliate": affiliate, "alerts_triggered": triggered,
            "sources": [{"name": s.provider, "ok": s.ok, "message": s.message, "mode": s.mode, "count": s.count} for s in out.statuses],
            "budget_note": None if (budget or c.max_budget) else "No budget set.",
        }

    @staticmethod
    def _raise_if_all_failed(out) -> None:
        if out.statuses and not any(x.ok for x in out.statuses):
            msg = out.statuses[0].message
            low = msg.lower()
            status = 429 if ("quota" in low or "rate limit" in low) else 504 if "timed out" in low else 401 if "access denied" in low else 502
            raise ApiError(status, f"Could not retrieve prices: {msg}", {"code": "provider_error"})

    @staticmethod
    def _match(g, intent, tier) -> dict:
        if intent is None or not intent.specific or tier is None:
            return {"level": "browse", "label": ""}
        if tier == 0:
            return {"level": "exact", "label": "Exact match"}
        why = []
        if intent.storage_gb and not g.storage_gb:
            why.append("the listing doesn't state the storage")
        if intent.ram_gb and not g.ram_gb:
            why.append("the listing doesn't state the RAM")
        qt = set(intent.model_tokens) - set(_tokens(g.brand))
        extra = [t for t in _tokens(g.model) if t not in qt]
        if why:
            return {"level": "possible", "label": "Possible match: " + " and ".join(why)}
        if extra and qt <= set(_tokens(g.model)):
            return {"level": "related", "label": "Different variant (" + " ".join(extra) + ")"}
        if g.condition in ("refurbished", "used"):
            return {"level": "possible", "label": g.condition.capitalize() + " listing"}
        return {"level": "possible", "label": "Possible match"}

    def _view(self, g, amazon_tag: str, url_info: Optional[dict], intent=None, tier=None):
        offers, aff = build_offers(g, amazon_tag)
        if url_info:
            mine = _norm_link(url_info["url"])
            for o in offers:
                o["matches_pasted_link"] = o["kind"] == "direct" and _norm_link(o["url"]) == mine
        stats = offer_stats(offers)
        bits = [f"{g.storage_gb // 1000 if g.storage_gb and g.storage_gb % 1000 == 0 and g.storage_gb >= 1000 else g.storage_gb}{' TB' if g.storage_gb and g.storage_gb % 1000 == 0 and g.storage_gb >= 1000 else ' GB'}" if g.storage_gb else "",
                f"{g.ram_gb} GB RAM" if g.ram_gb else "", g.color.title() if g.color else "", g.condition.capitalize() if g.condition in ("refurbished", "used") else ""]
        v = {"key": product_key(g), "id": product_key(g), "title": g.name, "variant_label": ", ".join(b for b in bits if b),
             "match": self._match(g, intent, tier), "name": g.name, "brand": g.brand, "model": g.model, "category": g.category,
             "variant": {"storage_gb": g.storage_gb, "ram_gb": g.ram_gb, "color": g.color, "condition": g.condition},
             "image_url": g.image_url, "specs": g.specs, "rating": g.rating, "review_count": g.review_count,
             "source": g.source, "source_type": g.source_type, "retrieved_at": g.retrieved_at, "currency": g.currency,
             "offers": offers, "stats": stats}
        return v, aff

    def _insight(self, v: dict, series: List[dict], try_ai: bool) -> dict:
        ins = price_insight(v, series)
        ins["ai"] = False
        if try_ai and self.llm.available and v["source_type"] != "demo":
            sig = hashlib.sha1("|".join(ins["facts"]).encode()).hexdigest()
            if sig not in self._insight_cache:
                allowed = [float(n.replace(",", "")) for f in ins["facts"] for n in re.findall(r"₹\s?([\d,]+(?:\.\d+)?)", f)]
                try:
                    text = self.llm.ask("Rewrite these verified facts as a friendly 1-2 sentence buying insight. Use only these facts, "
                                        "keep every ₹ amount exactly as written, add no new claims.", " ".join(ins["facts"]))
                    ok = explanation_is_grounded(text, allowed + [abs(a - b) for a in allowed for b in allowed]) and len(text) < 400
                    self._insight_cache[sig] = text.strip() if ok else None
                except LLMError:
                    self._insight_cache[sig] = None
            if self._insight_cache[sig]:
                ins["text"], ins["ai"] = self._insight_cache[sig], True
        return ins

    # ------------------------------------------------------------------ products / offers / history
    @staticmethod
    def _pid(pid: str) -> str:
        if not re.fullmatch(r"[a-f0-9]{12}", pid or ""):
            raise ApiError(400, "That is not a valid product id.")
        return pid

    def product(self, pid: str) -> dict:
        pid = self._pid(pid)
        row, snap = self.db.product_row(pid), self.db.get_product(pid)
        if not row or not snap:
            raise ApiError(404, "Product not found. Search for it first.")
        return {"product": row, "latest": snap}

    def offers(self, pid: str) -> dict:
        pid = self._pid(pid)
        if not self.db.product_row(pid):
            raise ApiError(404, "Product not found. Search for it first.")
        rows = self.db.list_offers(pid)
        prices = [r["price"] for r in rows]
        stats = {"count": len(prices), "lowest": min(prices), "highest": max(prices), "average": round(sum(prices) / len(prices), 2)} if prices else {"count": 0}
        return {"product_id": pid, "offers": rows, "stats": stats,
                "note": "These are the last prices retrieved for each offer (see last_checked). Run a search to refresh them."}

    def history(self, key: str, seller_id: str = "") -> dict:
        key = self._pid(key)
        rows = self.db.history(key, seller_id or None)
        sellers = sorted({(r["seller"], r["seller"]) for r in self.db.history(key)})
        series = Database.daily_series(rows)
        return {"product_id": key, "series": series, "stats": Database.series_stats(series),
                "sellers": [{"id": i, "name": n} for i, n in sellers], "available": bool(series),
                "observations": [{"observed_at": r["observed_at"], "seller": r["seller"], "price": r["price"], "source": r["source"]} for r in rows][-200:],
                "message": None if series else "Price history starts when tracking begins."}

    # ------------------------------------------------------------------ RAG: chat + compare
    def _load(self, keys: List[str]) -> List[dict]:
        views = [v for v in (self.db.get_product(k) for k in keys[:4] if re.fullmatch(r"[a-f0-9]{12}", str(k))) if v]
        if not views:
            raise ApiError(400, "Search for a product first, then ask about it.")
        return views

    def _hist(self, views: List[dict]) -> Dict[str, dict]:
        out = {}
        for v in views:
            s = Database.daily_series(self.db.history(v["key"]))
            if len(s) >= 2:
                out[v["key"]] = Database.series_stats(s)
        return out

    def chat(self, body: dict) -> dict:
        msg = (body.get("message") or "").strip()
        if not msg or len(msg) > 500:
            raise ApiError(400, "Ask a question (up to 500 characters).")
        views = self._load(body.get("keys") or [])
        chunks = rag.build_chunks(views, self._hist(views))
        r = rag.answer(msg, chunks, views, self.llm, body.get("history") if isinstance(body.get("history"), list) else None)
        return {"mode": r["mode"], "answer": r["answer"], "note": r["note"], "sources": r["sources"]}

    def compare(self, body: dict) -> dict:
        keys = body.get("keys") or []
        if not isinstance(keys, list) or len(keys) < 2:
            raise ApiError(400, "Select at least two products to compare.")
        views = self._load(keys)
        if len(views) < 2:
            raise ApiError(400, "Those products are no longer available. Search again.")
        q = (body.get("question") or "").strip()[:400] or "Compare these products: key differences, and which offers better value for money?"
        comp = rag.compare_views(views)
        chunks = rag.build_chunks(views, self._hist(views))
        r = rag.answer(q, chunks, views, self.llm)
        if r["mode"] == "facts":
            r["answer"] = " ".join(comp["facts"][:6])
        return {"table": {"columns": comp["columns"], "rows": comp["rows"]}, "facts": comp["facts"], "mode": r["mode"],
                "answer": r["answer"], "note": r["note"], "sources": r["sources"]}

    # ------------------------------------------------------------------ alerts / lists / stores
    def create_alert(self, body: dict) -> dict:
        key = str(body.get("key") or "")
        snap = self.db.get_product(key)
        if not snap:
            raise ApiError(400, "Search for the product first, then set an alert.")
        try:
            target = float(body.get("target_price"))
        except (TypeError, ValueError):
            raise ApiError(400, "Enter a target price in rupees.")
        if not (100 <= target <= 10_000_000):
            raise ApiError(400, "Enter a realistic target price (₹100 to ₹1,00,00,000).")
        aid = self.db.add_alert(key, snap["name"], target, snap.get("currency", "INR"))
        low = (snap.get("stats") or {}).get("lowest")
        return {"id": aid, "name": snap["name"], "target_price": target, "current_lowest": low,
                "already_met": bool(low is not None and snap.get("source_type") == "live" and low <= target),
                "note": ("You'll be notified in this app when a newly retrieved live price reaches the target. Checks only happen while the app is running and a search or check runs.")}

    def alerts(self) -> List[dict]:
        return self.db.list_alerts()

    def check_alerts(self) -> dict:
        if not self.assistant.search.providers:
            return {"checked": 0, "triggered": [], "message": "No data provider is configured, so alerts can't be checked."}
        triggered, checked = [], 0
        for a in [x for x in self.db.list_alerts() if x["active"]]:
            checked += 1
            try:
                r = self.search({"query": a["product_name"], "ai": "0"})
                triggered += r["alerts_triggered"]
            except ApiError:
                continue
        return {"checked": checked, "triggered": triggered, "message": f"Checked {checked} alert(s) using the cached/live data providers."}

    def trending(self) -> dict:
        items = self.db.trending()
        return {"sample": False, "items": items,
                "note": "Most-searched products on this installation." if items else "Nothing is trending yet. Products appear here after real searches."}

    def stores(self) -> dict:
        s = self.settings
        provs = [("Google Shopping via SerpApi", bool(s.serpapi_key)), ("Flipkart Affiliate API", bool(s.flipkart_affiliate_id and s.flipkart_affiliate_token)),
                 ("Google Shopping via SerpApi", bool(s.serpapi_key)), ("Google Shopping via Serper", bool(s.serper_key)),
                 ("Custom JSON provider", bool(s.product_api_url and s.product_api_field_map))]
        return {"retailers": [{"key": k, "name": n, "link_recognised": True} for k, (n, _) in HOSTS.items()],
                "providers": [{"name": n, "configured": c} for n, c in provs], "demo": False,
                "ai": self.llm.available, "contact_email": s.contact_email}

    def health(self) -> dict:
        from src.config import ROOT
        d = ROOT / "web" / "static" / "logos"
        logos = {f.stem: f.name for f in d.glob("*") if f.suffix.lower() in (".png", ".svg", ".webp") and f.stem in RETAILERS} if d.is_dir() else {}
        return {"ok": self.db.ping(), "serpapi_configured": bool(self.settings.serpapi_key), "providers": len(self.assistant.search.providers),
                "ai": self.llm.available, "database": self.db.ping(), "logos": logos}
