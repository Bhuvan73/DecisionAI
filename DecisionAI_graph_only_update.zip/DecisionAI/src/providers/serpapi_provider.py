"""Google Shopping results via SerpApi (https://serpapi.com), engine=google_shopping.

Implemented from SerpApi's public documentation and unit-tested against a response *fixture* shaped like that
documentation. It has NOT been called against the live service from this build (no key / no network).
Which merchants appear (e.g. whether Amazon.in or Flipkart) is decided by Google Shopping, not by this code.
"""
from __future__ import annotations

from typing import Any, List

from src.config import Settings
from src.data_validation import normalize_products
from src.models import Product, SearchCriteria
from src.providers._shopping import first, now_iso, request_json, search_text
from src.providers.base import ProviderBase, ProviderError

ENDPOINT = "https://serpapi.com/search.json"


def parse_response(data: Any, name: str = "SerpApi") -> List[dict]:
    """Return raw product dicts from a SerpApi google_shopping payload; raise ProviderError for API-level errors."""
    if not isinstance(data, dict):
        raise ProviderError(f"{name}: unexpected response format.")
    err = data.get("error")
    if isinstance(err, str):
        low = err.lower()
        if "hasn't returned any results" in low or "no results" in low:
            return []
        if "invalid api key" in low or "api key" in low and "missing" in low:
            raise ProviderError(f"{name}: access denied - check SERPAPI_KEY.")
        if "run out of searches" in low or "limit" in low:
            raise ProviderError(f"{name}: search quota reached for this account.")
        raise ProviderError(f"{name}: the service reported an error.")
    items = data.get("shopping_results")
    if items is None:
        return []
    if not isinstance(items, list):
        raise ProviderError(f"{name}: unexpected 'shopping_results' format.")
    raws = []
    for it in items:
        if not isinstance(it, dict):
            continue
        old = first(it.get("extracted_old_price"), it.get("old_price"))
        # Prefer a merchant URL when SerpApi supplies one. Some results expose
        # only a Google Shopping URL; retain that as an explicitly classified fallback.
        link_candidates = [it.get("product_link"), it.get("link")]
        merchant_link = next((u for u in link_candidates
                              if isinstance(u, str) and u.startswith(("https://", "http://"))
                              and not any(host in u.lower() for host in ("google.", "googleadservices.", "googleusercontent."))), None)
        result_link = merchant_link or first(*link_candidates)
        raws.append({
            "id": first(it.get("product_id"), it.get("position")),
            "name": it.get("title"), "seller": it.get("source"),
            "price": first(it.get("extracted_price"), it.get("price")),
            "original_price": old, "original_price_verified": old is not None,
            "url": result_link,
            "image_url": it.get("thumbnail"), "rating": it.get("rating"), "review_count": it.get("reviews"),
            "delivery": it.get("delivery"), "condition": it.get("second_hand_condition"),
        })
    return raws


def _merchant_offers(payload: Any, parent: dict) -> List[dict]:
    """Extract merchant-level offers from SerpApi's immersive product response.

    SerpApi's ordinary shopping result often links to Google Shopping. When it
    supplies an immersive-product API URL, that endpoint can expose individual
    store offers and their outbound merchant URLs. We only use URLs actually
    returned by that endpoint; otherwise the original Google link remains.
    """
    if not isinstance(payload, dict) or payload.get("error"):
        return []
    entries = None
    for key in ("stores", "online_sellers", "offers", "seller_results"):
        value = payload.get(key)
        if isinstance(value, list) and value:
            entries = value
            break
    if entries is None:
        # Some responses nest merchant offers under product_results.
        pr = payload.get("product_results")
        if isinstance(pr, dict):
            for key in ("stores", "online_sellers", "offers"):
                if isinstance(pr.get(key), list) and pr[key]:
                    entries = pr[key]
                    break
    out = []
    for offer in entries or []:
        if not isinstance(offer, dict):
            continue
        # SerpApi/Google payloads use different field names across merchant
        # offer variants. Prefer explicit merchant/product URLs; reject Google
        # redirect/aggregator URLs so the UI can label the fallback honestly.
        link_candidates = [
            offer.get("merchant_link"), offer.get("seller_link"), offer.get("direct_link"),
            offer.get("product_url"), offer.get("product_link"), offer.get("store_link"),
            offer.get("link"), offer.get("url"),
        ]
        link = next((u for u in link_candidates
                     if isinstance(u, str) and u.startswith(("https://", "http://"))
                     and not any(host in u.lower() for host in
                                 ("google.", "googleadservices.", "googleusercontent."))), None)
        seller = first(offer.get("name"), offer.get("source"), offer.get("seller"), offer.get("merchant"), offer.get("store"))
        price = first(offer.get("extracted_price"), offer.get("price"))
        if not seller or price is None:
            continue
        out.append({
            "id": first(parent.get("product_id"), parent.get("position")),
            "name": first(parent.get("title"), offer.get("title")),
            "seller": seller, "price": price, "url": link,
            "image_url": parent.get("thumbnail"),
            "rating": first(offer.get("rating"), parent.get("rating")),
            "review_count": first(offer.get("reviews"), parent.get("reviews")),
            "delivery": offer.get("delivery"),
        })
    return out


class SerpApiShoppingProvider(ProviderBase):
    name = "Google Shopping via SerpApi"
    source_type = "live"

    def __init__(self, settings: Settings):
        self.s = settings

    def is_available(self) -> bool:
        return bool(self.s.serpapi_key)

    def search(self, criteria: SearchCriteria, limit: int = 40) -> List[Product]:
        if not self.is_available():
            raise ProviderError(f"{self.name}: SERPAPI_KEY is not set.")
        text = search_text(criteria)
        if not text:
            return []
        data = request_json(self.s, self.name, "GET", ENDPOINT, self.s.product_api_timeout,
                            params={"engine": "google_shopping", "q": text, "gl": "in", "hl": "en",
                                    "google_domain": "google.co.in", "api_key": self.s.serpapi_key})
        raw_items = parse_response(data, self.name)[:limit]
        # Resolve merchant-specific URLs through SerpApi's immersive product API
        # where available. Limit detail lookups to five products to protect the
        # user's free monthly search allowance. This is best-effort: no guessed URLs.
        shopping_items = data.get("shopping_results", []) if isinstance(data, dict) else []
        expanded = []
        for index, item in enumerate(shopping_items[:min(limit, 5)]):
            if not isinstance(item, dict):
                continue
            detail_url = item.get("serpapi_immersive_product_api")
            if not isinstance(detail_url, str) or not detail_url.startswith("https://"):
                continue
            try:
                detail = request_json(self.s, self.name + " merchant details", "GET", detail_url,
                                      self.s.product_api_timeout, params={"api_key": self.s.serpapi_key})
                expanded.extend(_merchant_offers(detail, item))
            except ProviderError:
                # Preserve the valid Shopping result even if merchant-detail lookup fails.
                continue
        # Prefer merchant offers for a product when found; keep original results
        # for products whose detail endpoint did not expose direct seller URLs.
        expanded_parent_ids = {str(x["id"]) for x in expanded if x.get("id") is not None}
        raw_items = [r for r in raw_items if str(r.get("id")) not in expanded_parent_ids] + expanded
        products, rejected = normalize_products(raw_items[:limit * 5], self.name, "live",
                                                retrieved_at=now_iso(), default_currency=self.s.currency)
        return products
