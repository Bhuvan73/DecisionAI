"""Optional browser check (pip install playwright && playwright install chromium).

Starts the real server in-process and drives the real page in headless Chromium. Because no real SerpApi key/network is
assumed, the provider is a FIXTURE shaped like a SerpApi response and the database is a TEMPORARY file seeded with test
observations. This verifies the UI and API wiring, NOT live SerpApi data. For that, run scripts/verify_serpapi.py.
Usage: python scripts/e2e_check.py [screenshot_dir]
"""
import os
import sys
import tempfile
import threading
from datetime import timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.api import AppService  # noqa: E402
from src.cache import FileCache  # noqa: E402
from src.config import Settings  # noqa: E402
from src.data_validation import normalize_products  # noqa: E402
from src.db import Database, utcnow  # noqa: E402
from src.product_search import ProductSearchService  # noqa: E402
from src.providers.base import ProviderBase  # noqa: E402
from src.providers.serpapi_provider import parse_response  # noqa: E402
from src.url_extractor import UrlReadError  # noqa: E402
from server import create_server  # noqa: E402

OUT = sys.argv[1] if len(sys.argv) > 1 else tempfile.mkdtemp()
FIXTURE = {"shopping_results": [
    {"position": 1, "title": "Apple iPhone 17 Pro Max 256GB Cosmic Orange", "source": "Amazon.in", "extracted_price": 149900, "link": "https://www.amazon.in/dp/FIXTURE1", "rating": 4.5, "reviews": 120, "delivery": "Free delivery"},
    {"position": 2, "title": "Apple iPhone 17 Pro Max (256 GB) - Cosmic Orange", "source": "Flipkart", "extracted_price": 148500, "product_link": "https://www.google.com/shopping/product/FIXTURE2"},
    {"position": 3, "title": "Apple iPhone 17 Pro Max 256GB Cosmic Orange", "source": "Croma", "extracted_price": 152500, "link": "https://www.croma.com/p/FIXTURE3", "old_price": "₹1,59,900", "extracted_old_price": 159900},
    {"position": 4, "title": "Apple iPhone 17 Pro Max 512GB Cosmic Orange", "source": "Croma", "extracted_price": 170500, "link": "https://www.croma.com/p/FIXTURE4"},
]}


class FixtureProvider(ProviderBase):
    name, source_type = "Fixture (test data)", "live"

    def __init__(self, img):
        self.img = img

    def search(self, criteria, limit=40):
        raws = parse_response(FIXTURE)
        for r in raws:
            r["image_url"] = self.img
        return normalize_products(raws, self.name, "live")[0]


def blocked_reader(url):
    raise UrlReadError("The website refused automated access to this page (it may require a browser or login). It was not bypassed.", "Apple iPhone 17 Pro Max 256GB")


def serve(app):
    srv = create_server(app, "127.0.0.1", 0)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv.server_address[1]


def main():
    from playwright.sync_api import sync_playwright
    tmp = tempfile.mkdtemp()
    db = Database(os.path.join(tmp, "live.db"))
    app = AppService(Settings(), db, url_reader=blocked_reader)
    port = serve(app)
    app.assistant.search = ProductSearchService(app.settings, [FixtureProvider(f"http://127.0.0.1:{port}/static/favicon.svg")], FileCache(tmp + "/c", 1, False))
    nokey_port = serve(AppService(Settings(), Database(os.path.join(tmp, "nokey.db"))))
    errors, R = [], {}
    base = f"http://127.0.0.1:{port}"
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": 1180, "height": 900})
        pg.on("pageerror", lambda e: errors.append(str(e)))
        # 1. setup message when no key is configured
        n = b.new_page(); n.goto(f"http://127.0.0.1:{nokey_port}/"); n.wait_for_selector(".setup")
        R["nokey-banner"] = "SERPAPI_KEY" in n.inner_text("#status")
        n.fill("#q", "iPhone 16 128GB"); n.click("#go"); n.wait_for_selector(".setup")
        R["nokey-on-search"] = "Setup needed" in n.inner_text("#status")
        # 2. search + results
        pg.goto(base + "/"); R["hero"] = pg.inner_text("h1")
        R["nav"] = pg.inner_text(".links").replace("\n", " | ")
        pg.screenshot(path=f"{OUT}/home.png")
        pg.fill("#q", "iPhone 17 Pro Max"); pg.press("#q", "Enter"); pg.wait_for_selector(".product")  # Enter key searches
        R["stat-cards"] = pg.locator(".stat").count()
        R["seller-cards"] = pg.locator(".seller").count()
        R["amazon-tooltip"] = pg.locator('a.seller[title="View this product on Amazon India"]').count()
        R["google-link-labelled"] = "Link opens Google Shopping" in pg.inner_text(".sellers")
        R["history-empty-or-first"] = "Price history starts when tracking begins" in pg.inner_text("#hist-card")
        R["match-label"] = pg.locator(".match.exact").count()
        # 3. inline assistant (rule-based: no LLM key)
        pg.click(".sugs button >> nth=0"); pg.wait_for_selector(".msg.a .modeb")
        R["assistant-label"] = pg.inner_text(".msg.a .modeb")
        # 4. seed OLDER real-shaped snapshots for the chart (test DB only), re-search
        key = app.search({"query": "iPhone 17 Pro Max"})["products"][0]["key"]
        for days, price in ((60, 156000), (45, 154000), (30, 151500), (14, 152000), (6, 150500), (2, 149500)):
            db.record_offers(key, [{"seller_id": "flipkart", "seller": "Flipkart", "price": price, "currency": "INR", "url": "https://www.google.com/shopping/product/FIXTURE2"}], now=utcnow() - timedelta(days=days))
        pg.fill("#q", "iPhone 17 Pro Max"); pg.click("#go"); pg.wait_for_selector(".product")
        for _ in range(40):
            if pg.locator("#hist-card circle").count() >= 4:
                break
            pg.wait_for_timeout(200)
        R["chart-points"] = pg.locator("#hist-card circle").count()
        pg.hover("#hist-card svg", position={"x": 300, "y": 120}); R["chart-tooltip"] = pg.locator(".tip").is_visible()
        pg.click('[data-range="7"]'); R["range-7-points"] = pg.locator("#hist-card circle").count()
        pg.click('[data-range="max"]'); R["observations-listed"] = pg.locator(".obs tr").count() - 1
        pg.fill("#alert-price", "149000"); pg.click("#alert-set"); pg.wait_for_timeout(500)
        pg.screenshot(path=f"{OUT}/results-desktop.png", full_page=True)
        # 5. compare page
        pg.click('input[data-pick] >> nth=0'); pg.click('input[data-pick] >> nth=1'); pg.click("#cmp-btn")
        pg.wait_for_selector("#cmp-out .cmp")
        R["compare-page"] = "Lowest verified price" in pg.inner_text("#cmp-out") and pg.locator("#cmp-out .modeb").count() == 1
        # 6. tracker + assistant pages
        pg.click('.links a[data-route="tracker"]'); pg.wait_for_selector("#trk-list .mini"); pg.click("#trk-list .mini >> nth=0"); pg.wait_for_selector("#trk-hist .chart-h")
        R["tracker-page"] = True; R["tracker-alerts"] = pg.locator("#trk-alerts .alert-row").count()
        pg.click('.links a[data-route="assistant"]'); pg.wait_for_selector("#asst-list label"); pg.click("#asst-list label >> nth=0")
        pg.click("#asst-box .sugs button >> nth=1"); pg.wait_for_selector("#asst-box .msg.a .modeb")
        R["assistant-page"] = "worth" in pg.inner_text("#asst-box .msg.u").lower()
        # 7. URL that cannot be read: honest message + suggestion, no invented product
        pg.goto(base + "/#/"); pg.fill("#q", "https://www.amazon.in/Apple-iPhone-17/dp/B0FXXXX"); pg.click("#go"); pg.wait_for_selector("#use-sug")
        R["url-unreadable-msg"] = "enter the product name" in pg.inner_text("#status")
        R["no-result-cards-after-url-failure"] = pg.locator(".product").count() == 0
        # 8. theme + theme persistence + footer pages
        pg.click("#theme"); R["dark"] = pg.evaluate("document.documentElement.dataset.theme")
        for r in ("trending", "stores", "faq", "about", "contact"):
            pg.goto(f"{base}/#/{r}"); pg.wait_for_timeout(250); R[f"page:{r}"] = pg.locator(f"#view-{r}").is_visible()
        # 9. mobile
        m = b.new_page(viewport={"width": 390, "height": 900}); m.goto(base + "/"); m.fill("#q", "iPhone 17 Pro Max"); m.click("#go"); m.wait_for_selector("#hist-card .chart-h")
        R["mobile-no-hscroll"] = m.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1")
        m.screenshot(path=f"{OUT}/results-mobile.png", full_page=True)
        b.close()
    for k, v in R.items():
        print(f"{k}: {v}")
    print("page errors:", errors or "none")
    print("screenshots in", OUT)


if __name__ == "__main__":
    main()
