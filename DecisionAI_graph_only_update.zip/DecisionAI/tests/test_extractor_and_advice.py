import http.server
import logging
import os
import tempfile
import threading
from pathlib import Path
from unittest.mock import MagicMock, patch

from src import rag
from src.cache import FileCache
from src.config import Settings
from src.models import SearchCriteria
from src.product_search import ProductSearchService, fallback_parse_query
from src.providers.serpapi_provider import SerpApiShoppingProvider
from src.url_extractor import UrlReadError, assert_public, clean_title, extract_product_from_url, fetch_html, parse_product_html
from tests.test_platform import RAWS, FixtureLive, make_app

PAGE = """<html><head><title>Buy Apple iPhone 16 (128 GB) - Black : Amazon.in: Electronics</title>
<meta property="og:image" content="https://img.example.com/i.jpg">
<script type="application/ld+json">{"@context":"https://schema.org","@graph":[{"@type":"BreadcrumbList"},{"@type":"Product","name":"Apple iPhone 16 128GB Black",
"brand":{"@type":"Brand","name":"Apple"},"image":["https://img.example.com/x.jpg"],"offers":{"@type":"Offer","price":"69,900","priceCurrency":"INR"}}]}</script></head><body>x</body></html>"""


# ------------------------------------------------------------------ SerpApi request contract + key handling
def test_serpapi_request_uses_documented_parameters_and_key_only_server_side():
    s = Settings(serpapi_key="sk-test-0123456789")
    r = MagicMock(); r.status_code = 200; r.json.return_value = {"shopping_results": []}
    with patch("src.providers._shopping.requests.request", return_value=r) as m:
        SerpApiShoppingProvider(s).search(fallback_parse_query("iPhone 16 128GB"))
    args, kw = m.call_args
    assert args[:2] == ("GET", "https://serpapi.com/search.json")
    p = kw["params"]
    assert (p["engine"], p["google_domain"], p["gl"], p["hl"], p["q"], p["api_key"]) == ("google_shopping", "google.co.in", "in", "en", "iPhone 16 128GB", "sk-test-0123456789")
    for f in ("web/index.html", "web/app.js"):
        assert "sk-test" not in Path(f).read_text(encoding="utf-8") and "api_key" not in Path(f).read_text(encoding="utf-8")


def test_env_var_names_and_gitignore(tmp_path=None):
    old = {k: os.environ.pop(k, None) for k in ("SERPAPI_KEY", "SERPAPI_API_KEY")}
    try:
        os.environ["SERPAPI_KEY"] = "abc12345"
        assert Settings.from_env(load_file=False).serpapi_key == "abc12345"
        del os.environ["SERPAPI_KEY"]; os.environ["SERPAPI_API_KEY"] = "legacy123"
        assert Settings.from_env(load_file=False).serpapi_key == "legacy123"
    finally:
        for k in ("SERPAPI_KEY", "SERPAPI_API_KEY"):
            os.environ.pop(k, None)
        for k, v in old.items():
            if v is not None:
                os.environ[k] = v
    assert ".env" in Path(".gitignore").read_text().split() and "SERPAPI_KEY" in Path(".env.example").read_text()
    s = Settings(serpapi_key="abc12345")
    assert "abc12345" not in s.redact("failure with abc12345 inside")


def test_key_never_appears_in_logs_when_provider_fails():
    class H(logging.Handler):
        def __init__(self): super().__init__(); self.lines = []
        def emit(self, rec): self.lines.append(rec.getMessage())
    h = H(); lg = logging.getLogger("decision_assistant"); lg.addHandler(h); lg.setLevel(logging.DEBUG)
    s = Settings(serpapi_key="sk-LEAK-0123456789")
    import requests
    with patch("src.providers._shopping.requests.request", side_effect=requests.ConnectionError("https://serpapi.com/search.json?api_key=sk-LEAK-0123456789")):
        svc = ProductSearchService(s, [SerpApiShoppingProvider(s)], FileCache(Path(tempfile.mkdtemp()), 1, False))
        out = svc.fetch(fallback_parse_query("iPhone 16"))
    lg.removeHandler(h)
    assert not out.statuses[0].ok and "sk-LEAK" not in out.statuses[0].message and not any("sk-LEAK" in x for x in h.lines)


def test_repeated_searches_with_different_case_or_spacing_cost_one_api_call():
    s = Settings(serpapi_key="k")
    r = MagicMock(); r.status_code = 200; r.json.return_value = {"shopping_results": []}
    with patch("src.providers._shopping.requests.request", return_value=r) as m:
        svc = ProductSearchService(s, [SerpApiShoppingProvider(s)], FileCache(Path(tempfile.mkdtemp()), 60, True))
        for q in ("iPhone 16 128GB", "iphone  16 128gb", "Best iPhone 16 128GB under ₹80,000"):
            svc.fetch(fallback_parse_query(q))
    assert m.call_count == 1


# ------------------------------------------------------------------ URL extraction
def test_json_ld_and_open_graph_extraction():
    info = parse_product_html(PAGE)
    assert (info["title"], info["brand"], info["price"], info["currency"], info["source"]) == ("Apple iPhone 16 128GB Black", "Apple", 69900.0, "INR", "json-ld")
    assert info["image_url"] == "https://img.example.com/x.jpg" and info["variant"] == "128 GB, Black"
    og = parse_product_html('<html><head><meta property="og:title" content="Sony WH-1000XM5 Headphones | Croma"><meta property="og:image" content="https://i.example.com/a.png">'
                            '<meta property="product:price:amount" content="24990"><meta property="product:price:currency" content="INR"></head></html>')
    assert og["title"] == "Sony WH-1000XM5 Headphones" and og["price"] == 24990.0 and og["source"] == "open-graph"
    no_price = parse_product_html('<html><head><title>Lenovo LOQ RTX 4060</title></head></html>')
    assert no_price["price"] is None and no_price["title"] == "Lenovo LOQ RTX 4060"  # a price is never invented
    try:
        parse_product_html("<html><body>nothing</body></html>"); assert False
    except UrlReadError:
        pass
    assert clean_title("Buy Apple iPhone 16 (128 GB) - Black : Amazon.in: Electronics") == "Apple iPhone 16 (128 GB) - Black"


def test_ssrf_protection_blocks_internal_targets():
    for bad in ("http://127.0.0.1/admin", "http://localhost:8000/", "http://169.254.169.254/latest/meta-data/", "http://10.0.0.5/", "http://192.168.1.1/",
                "ftp://example.com/x", "https://example.com:8443/"):
        try:
            assert_public(bad); assert False, bad
        except UrlReadError:
            pass
    try:
        extract_product_from_url("not a url"); assert False
    except UrlReadError as e:
        assert "valid product link" in e.message


class _Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        routes = {"/robots.txt": (200, "text/plain", "User-agent: *\nDisallow: /private/\n"),
                  "/ok": (200, "text/html", PAGE), "/private/p": (200, "text/html", PAGE),
                  "/blocked": (503, "text/html", "<html>service unavailable</html>"), "/captcha": (200, "text/html", "<html><title>Robot Check</title>Enter the characters you see</html>"),
                  "/pdf": (200, "application/pdf", "%PDF"), "/missing": (404, "text/html", "no")}
        if self.path == "/redir":
            self.send_response(302); self.send_header("Location", "http://169.254.169.254/x"); self.end_headers(); return
        st, ct, body = routes.get(self.path, (404, "text/html", "no"))
        self.send_response(st); self.send_header("Content-Type", ct); self.end_headers(); self.wfile.write(body.encode())


def test_fetch_reads_public_pages_and_refuses_politely_otherwise():
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), _Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{srv.server_address[1]}"
    try:
        info = extract_product_from_url(base + "/ok", allow_private=True)
        assert info["title"] == "Apple iPhone 16 128GB Black" and info["price"] == 69900.0
        cases = {"/private/p": "robots.txt", "/blocked": "refused automated access", "/captcha": "anti-bot", "/pdf": "doesn't point to a web page", "/missing": "HTTP 404"}
        for path, needle in cases.items():
            try:
                fetch_html(base + path, allow_private=True); assert False, path
            except UrlReadError as e:
                assert needle in e.message, (path, e.message)
        try:  # a redirect to an internal address is re-validated and refused (private check ON for the hop)
            extract_product_from_url(base + "/redir", allow_private=False); assert False
        except UrlReadError:
            pass
    finally:
        srv.shutdown()


# ------------------------------------------------------------------ rule-based advice (no LLM)
def views_for_advice():
    app = make_app(live=True)
    prods = app.search({"query": "iPhone 17 Pro Max"})["products"]
    return prods, rag.build_chunks(prods)


def test_rule_based_advice_covers_the_requested_questions_and_stays_grounded():
    views, chunks = views_for_advice()
    ask = lambda q, v=views: rag.advice_answer(q, chunks, v)
    a = ask("Which seller is offering the cheapest price?")
    assert "₹1,48,500 at Flipkart" in a and "[S" in a
    w = ask("Is this product worth buying?")
    assert "below the average" in w and "No price history has been recorded" in w and "My take" in w and "can't judge product quality" in w
    c = ask("Should I choose the cheaper or more expensive variant?")
    assert "cheaper than" in c and "My take" in c and "256" in c and "512" in c
    b = ask("Which one should I buy within my budget of ₹1,60,000?")
    assert "Within ₹1,60,000" in b and "170" not in b
    nb = ask("best under ₹50,000")
    assert "Nothing retrieved is within ₹50,000" in nb
    p = ask("What are the advantages and disadvantages?")
    assert "advantages" in p and "disadvantages" in p
    for text, q in ((a, ""), (w, ""), (c, ""), (b, "within my budget of ₹1,60,000"), (nb, "best under ₹50,000"), (p, "")):
        # every rupee amount quoted must exist in the sources, be a difference of two, or be the user's own number
        assert rag.validate_answer(text, chunks, rag.question_amounts(q)) is None, text


def test_advice_admits_missing_data():
    app = make_app(live=True)
    prods = app.search({"query": "iPhone 17 Pro Max 512GB"})["products"]
    chunks = rag.build_chunks(prods)
    w = rag.advice_answer("Is it worth buying?", chunks, prods)
    assert "Only one verified offer" in w and "The data has no rating" in w
