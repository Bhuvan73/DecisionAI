"""Read a product page the way a polite client may: public pages only, robots.txt respected, SSRF-safe, no CAPTCHA/login bypass.

Metadata is taken from JSON-LD (schema.org Product) and Open Graph tags with BeautifulSoup. Nothing is guessed: if the
page can't be read, UrlReadError says why and the user is asked to type the product name instead.
"""
from __future__ import annotations

import ipaddress
import json
import re
import socket
from typing import Optional, Tuple
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import requests
from bs4 import BeautifulSoup

from src.identity import parse_title
from src.url_intake import intake_url
from src.utils.validation import clean_url, to_float

UA = "DecisionAI/1.0 (personal price-comparison tool; respects robots.txt)"
MAX_BYTES = 1_500_000
BLOCK_MARKERS = ("captcha", "robot check", "automated access", "unusual traffic", "enter the characters you see", "are you a human")


class UrlReadError(Exception):
    def __init__(self, message: str, suggested_query: str = ""):
        super().__init__(message)
        self.message, self.suggested_query = message, suggested_query


def assert_public(url: str, allow_private: bool = False) -> None:
    """Refuse localhost/private/link-local targets (server-side request forgery protection)."""
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise UrlReadError("That link must start with http:// or https://.")
    if allow_private:
        return
    if p.port not in (None, 80, 443):
        raise UrlReadError("Links with custom ports can't be read.")
    try:
        infos = socket.getaddrinfo(p.hostname, p.port or (443 if p.scheme == "https" else 80), proto=socket.IPPROTO_TCP)
    except socket.gaierror:
        raise UrlReadError("That website's address could not be found.")
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified:
            raise UrlReadError("That link points to a private or internal address and can't be read.")


def _get(url: str, session, timeout: float, allow_private: bool, accept="text/html,application/xhtml+xml"):
    for _ in range(4):  # follow at most 3 redirects, re-validating each hop
        assert_public(url, allow_private)
        resp = session.get(url, headers={"User-Agent": UA, "Accept": accept, "Accept-Language": "en-IN,en;q=0.8"},
                           timeout=timeout, allow_redirects=False, stream=True)
        if resp.status_code in (301, 302, 303, 307, 308) and resp.headers.get("Location"):
            url = urljoin(url, resp.headers["Location"])
            resp.close()
            continue
        return url, resp
    raise UrlReadError("That link redirects too many times.")


def robots_allows(url: str, session, timeout: float, allow_private: bool) -> bool:
    p = urlparse(url)
    robots = f"{p.scheme}://{p.netloc}/robots.txt"
    try:
        _, r = _get(robots, session, min(timeout, 5), allow_private, accept="text/plain")
    except (UrlReadError, requests.RequestException):
        return True  # robots.txt unreachable: proceed (the page fetch itself may still be refused)
    try:
        if r.status_code in (401, 403):
            return False
        if r.status_code != 200:
            return True  # no robots.txt => allowed
        rp = RobotFileParser()
        rp.parse(r.raw.read(200_000, decode_content=True).decode("utf-8", "replace").splitlines())
        return rp.can_fetch(UA, url) or rp.can_fetch("*", url)
    finally:
        r.close()


def fetch_html(url: str, session=None, timeout: float = 8, allow_private: bool = False) -> Tuple[str, str]:
    session = session or requests.Session()
    try:
        if not robots_allows(url, session, timeout, allow_private):
            raise UrlReadError("That site's robots.txt doesn't allow automated reading of this page, so it was not opened.")
        final, r = _get(url, session, timeout, allow_private)
    except requests.Timeout:
        raise UrlReadError("The page took too long to respond.")
    except requests.RequestException:
        raise UrlReadError("The page could not be reached.")
    try:
        if r.status_code in (401, 403, 429, 503):
            raise UrlReadError("The website refused automated access to this page (it may require a browser or login). It was not bypassed.")
        if r.status_code != 200:
            raise UrlReadError(f"The page returned HTTP {r.status_code}.")
        if "html" not in (r.headers.get("Content-Type") or "").lower():
            raise UrlReadError("That link doesn't point to a web page.")
        body = r.raw.read(MAX_BYTES + 1, decode_content=True)
        if len(body) > MAX_BYTES:
            body = body[:MAX_BYTES]
        html = body.decode(r.encoding or "utf-8", "replace")
    finally:
        r.close()
    low = html[:20000].lower()
    if any(m in low for m in BLOCK_MARKERS):
        raise UrlReadError("The website showed an anti-bot check instead of the product page. It was not bypassed.")
    return final, html


def clean_title(title: str) -> str:
    t = re.sub(r"\s+", " ", title or "").strip()
    t = re.sub(r"^(buy|shop)\s+", "", t, flags=re.I)
    t = re.split(r"\s*(?::\s*Amazon|\|\s|\s-\s*(?:Buy|Amazon|Flipkart|Croma|Reliance|Vijay|Tata)|\sOnline\b|\sat Best Price|\sat Flipkart|\s:\s*Flipkart)", t, flags=re.I)[0]
    return t.strip(" -|:")


def _types(node) -> list:
    t = node.get("@type") if isinstance(node, dict) else None
    return [t] if isinstance(t, str) else (t if isinstance(t, list) else [])


def _walk(node):
    if isinstance(node, list):
        for n in node:
            yield from _walk(n)
    elif isinstance(node, dict):
        yield node
        for k in ("@graph", "itemListElement", "mainEntity"):
            if k in node:
                yield from _walk(node[k])


def parse_product_html(html: str, url: str = "") -> dict:
    """Extract product facts from JSON-LD / Open Graph / <title>. Raises UrlReadError if no product title is found."""
    soup = BeautifulSoup(html, "html.parser")
    info = {"title": "", "brand": "", "model": "", "price": None, "currency": "", "image_url": None, "source": ""}
    for tag in soup.find_all("script", type="application/ld+json"):
        try:
            data = json.loads(tag.string or tag.get_text() or "")
        except ValueError:
            continue
        for node in _walk(data):
            if "Product" in _types(node) and node.get("name"):
                info["title"] = str(node["name"])
                b = node.get("brand")
                info["brand"] = str(b.get("name") if isinstance(b, dict) else b or "")
                info["model"] = str(node.get("model") or node.get("mpn") or "")
                img = node.get("image")
                img = img[0] if isinstance(img, list) and img else img
                info["image_url"] = clean_url(img.get("url") if isinstance(img, dict) else img)
                offers = node.get("offers")
                offers = offers[0] if isinstance(offers, list) and offers else offers
                if isinstance(offers, dict):
                    price = to_float(offers.get("price") if offers.get("price") is not None else offers.get("lowPrice"))
                    info["price"] = price if price and price > 0 else None
                    info["currency"] = str(offers.get("priceCurrency") or "")
                info["source"] = "json-ld"
                break
        if info["title"]:
            break
    og = {m.get("property") or m.get("name"): m.get("content") for m in soup.find_all("meta") if (m.get("property") or m.get("name")) and m.get("content")}
    if not info["title"]:
        if og.get("og:title"):
            info["title"], info["source"] = og["og:title"], "open-graph"
        elif soup.title and soup.title.string and soup.title.string.strip():
            info["title"], info["source"] = soup.title.string, "html-title"
    if not info["title"]:
        raise UrlReadError("No product name could be found on that page.")
    info["image_url"] = info["image_url"] or clean_url(og.get("og:image"))
    if info["price"] is None:
        p = to_float(og.get("product:price:amount") or og.get("og:price:amount"))
        if p and p > 0:
            info["price"], info["currency"] = p, og.get("product:price:currency") or og.get("og:price:currency") or info["currency"]
    info["brand"] = info["brand"] or og.get("product:brand") or ""
    info["title"] = clean_title(info["title"])
    ident = parse_title(info["title"], info["brand"])
    info["brand"] = info["brand"] or ident.brand
    bits = [f"{ident.storage_gb} GB" if ident.storage_gb else "", f"{ident.ram_gb} GB RAM" if ident.ram_gb else "", ident.color.title() if ident.color else ""]
    info["variant"] = ", ".join(b for b in bits if b)
    return info


def extract_product_from_url(raw_url: str, session=None, allow_private: bool = False) -> dict:
    """Validate -> fetch -> parse. Raises UrlReadError (with a slug-based *suggestion* when possible)."""
    meta = intake_url(raw_url)
    if not meta["valid"]:
        raise UrlReadError(meta["error"])
    try:
        final, html = fetch_html(meta["url"], session=session, allow_private=allow_private)
        info = parse_product_html(html, final)
    except UrlReadError as e:
        raise UrlReadError(e.message, meta.get("title_guess", ""))
    info.update({"url": meta["url"], "retailer": meta["retailer"], "retailer_name": meta["retailer_name"], "recognised": meta["recognised"]})
    return info
