"""Query understanding + cautious relevance matching on structured attributes (not raw text similarity)."""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from src.identity import BRAND_DISPLAY, COLORS, CONDITION_WORDS, LINE_TO_BRAND, brand_key, extract_memory, tokens
from src.models import Product, SearchCriteria

CATEGORY_WORDS = {"phone", "phones", "smartphone", "smartphones", "mobile", "mobiles", "laptop", "laptops", "notebook",
                  "notebooks", "ssd", "ssds", "mouse", "mice", "keyboard", "headphones", "earbuds", "tv", "monitor"}
GENERIC = {"best", "good", "top", "great", "cheap", "cheapest", "lowest", "price", "priced", "offer", "offers", "deal", "deals",
           "under", "below", "within", "upto", "up", "to", "less", "than", "around", "budget", "for", "the", "a", "an", "with",
           "and", "or", "find", "me", "i", "need", "want", "buy", "in", "of", "my", "compare", "vs", "versus", "available",
           "india", "online", "gaming", "games", "game", "gamer", "fps", "esports", "competitive", "coding", "programming",
           "developer", "college", "student", "students", "study", "office", "work", "photography", "camera", "video",
           "editing", "everyday", "daily", "use", "5g", "4g", "inr", "rs", "k", "lakh", "lac", "new", "latest"}
ACCESSORY_WORDS = {"case", "cover", "protector", "tempered", "glass", "charger", "cable", "adapter", "strap", "skin", "stand",
                   "pouch", "sleeve", "bag", "holder", "film", "guard", "mount", "dock", "stylus", "pad", "mousepad",
                   "replacement", "battery", "screen", "lens", "sticker", "wrap"}
SPELLING = {"i phone": "iphone", "iphon": "iphone", "galexy": "galaxy", "samsumg": "samsung", "samsng": "samsung",
            "lap top": "laptop", "labtop": "laptop", "mobiel": "mobile", "macbok": "macbook", "onplus": "oneplus"}
_NUM = r"\d[\d,]*(?:\.\d+)?"
# A number counts as money only with a budget phrase, a currency marker, or a k/lakh suffix ("17" in "iPhone 17" is not money).
MONEY = re.compile(
    rf"(?:(?:under|below|within|upto|up to|less than|max(?:imum)?|budget(?: of)?|around)\s*(?:rs\.?|inr|₹)?\s*{_NUM}\s*(?:k|lakh|lac)?\b)"
    rf"|(?:(?:rs\.?|inr|₹)\s*{_NUM}\s*(?:k|lakh|lac)?\b)|(?:\b{_NUM}\s*(?:k|lakh|lac)\b)", re.I)
CATEGORY_OF = {"phone": "phone", "phones": "phone", "smartphone": "phone", "smartphones": "phone", "mobile": "phone",
               "mobiles": "phone", "laptop": "laptop", "laptops": "laptop", "notebook": "laptop", "notebooks": "laptop",
               "ssd": "ssd", "ssds": "ssd", "mouse": "mouse", "mice": "mouse"}


@dataclass
class Intent:
    query: str = ""
    model_tokens: List[str] = field(default_factory=list)
    brand: Optional[str] = None       # display name, only when the user named one
    category: Optional[str] = None
    storage_gb: Optional[int] = None
    ram_gb: Optional[int] = None
    color: str = ""
    condition: Optional[str] = None
    specific: bool = False            # user named a concrete product/model


def split_compare(text: str) -> List[str]:
    """'compare A and B' / 'A vs B' -> ['A', 'B'] (2-4 parts), else []."""
    t = re.sub(r"^\s*compare\s+", "", text.strip(), flags=re.I)
    parts = [p.strip(" ,.") for p in re.split(r"\s+(?:vs\.?|versus|and|&)\s+|\s*,\s*", t, flags=re.I) if p.strip(" ,.")]
    is_compare = bool(re.match(r"^\s*compare\b", text, re.I)) or re.search(r"\s(?:vs\.?|versus)\s", text, re.I)
    return parts[:4] if is_compare and len(parts) >= 2 else []


def parse_intent(text: str) -> Intent:
    q = (text or "").strip()
    low = q.lower()
    for wrong, right in SPELLING.items():
        low = re.sub(rf"\b{re.escape(wrong)}\b", right, low)
    it = Intent(query=q)
    it.ram_gb, it.storage_gb, rest = extract_memory(low)
    rest = MONEY.sub(" ", rest)
    toks = tokens(rest)
    for t in toks:
        if t in CATEGORY_OF and not it.category:
            it.category = CATEGORY_OF[t]
        if t in BRAND_DISPLAY and not it.brand:
            it.brand = BRAND_DISPLAY[t]
        elif t in LINE_TO_BRAND and not it.brand:
            it.brand = BRAND_DISPLAY[LINE_TO_BRAND[t]]
        if t in CONDITION_WORDS and not it.condition:
            it.condition = CONDITION_WORDS[t]
        if t in COLORS and not it.color:
            it.color = "gray" if t == "grey" else t
    keep = []
    for t in toks:
        if t in GENERIC or t in CATEGORY_WORDS or t in COLORS or t in CONDITION_WORDS or t in ("ram", "storage", "gb", "tb"):
            continue
        if t in BRAND_DISPLAY and brand_key(t) == brand_key(it.brand or ""):
            continue  # brand tokens are matched through p.brand, not the model
        keep.append(t)
    it.model_tokens = keep
    it.specific = bool(keep) and (any(ch.isdigit() for t in keep for ch in t) or bool(it.brand) or len(keep) >= 2)
    return it


def _product_tokens(p: Product) -> List[str]:
    return tokens(p.model) if p.model else tokens(p.name)


def correct_tokens(toks: List[str], vocab: set) -> List[str]:
    """Fix likely typos against words actually present in results. Cautious: long, non-numeric, high similarity only."""
    out = []
    for t in toks:
        if t in vocab or len(t) < 5 or any(c.isdigit() for c in t):
            out.append(t)
            continue
        m = difflib.get_close_matches(t, vocab, n=1, cutoff=0.86)
        out.append(m[0] if m else t)
    return out


def is_accessory(p: Product, it: Intent) -> bool:
    asked = set(tokens(it.query))
    words = set(tokens(p.name))
    return bool((words & ACCESSORY_WORDS) - asked) and p.category not in ("accessory",)


def tier_for(p: Product, it: Intent, model_toks: List[str]) -> Optional[int]:
    """0 = exact product, 1 = related variant/other spec, 2 = generic category match, None = not relevant."""
    if is_accessory(p, it):
        return None
    if it.brand and brand_key(p.brand) != brand_key(it.brand):
        return None
    tier = 2
    if it.specific:
        pm = set(_product_tokens(p))
        if not set(model_toks) <= pm and not set(model_toks) <= (pm | set(tokens(p.name))):
            return None
        tier = 0 if set(model_toks) - set(tokens(p.brand)) == pm else 1
    elif it.category and p.category and p.category != it.category:
        return None
    if it.storage_gb:
        if p.storage_gb and p.storage_gb != it.storage_gb:
            return None
        if not p.storage_gb:
            tier = max(tier, 1)
    if it.ram_gb and p.ram_gb and p.ram_gb != it.ram_gb:
        return None
    if it.color and p.color and it.color not in p.color:
        return None
    if it.condition:
        if p.condition != it.condition:
            return None
    elif p.condition in ("refurbished", "used"):
        tier += 1  # still shown, ranked below new unless the user asked for them
    return tier


def filter_relevant(products: List[Product], it: Intent) -> Tuple[List[Product], Dict[str, int]]:
    """Keep relevant products; returns (kept, {product_id|seller: tier})."""
    vocab = {t for p in products for t in _product_tokens(p)} | set(BRAND_DISPLAY) | set(LINE_TO_BRAND)
    model_toks = correct_tokens(it.model_tokens, vocab)
    kept, tiers = [], {}
    for p in products:
        t = tier_for(p, it, model_toks)
        if t is not None:
            kept.append(p)
            tiers[f"{p.id}|{p.seller}"] = t
    return kept, tiers


def suggestions(it: Intent, products: List[Product], limit: int = 5) -> List[str]:
    """Closest known product names for a query with no match (fuzzy, used only as hints)."""
    q = " ".join(tokens(it.query))
    names = {}
    for p in products:
        if not is_accessory(p, it):
            names[p.name] = difflib.SequenceMatcher(None, q, " ".join(tokens(p.name))).ratio()
    ranked = sorted(names.items(), key=lambda kv: -kv[1])
    return [n for n, r in ranked if r >= 0.6][:limit]
