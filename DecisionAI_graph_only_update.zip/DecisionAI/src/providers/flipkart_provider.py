"""Flipkart Affiliate Product Feed API adapter.

IMPORTANT: written from Flipkart's historic public affiliate documentation and unit-tested only against a
hand-written FIXTURE of that shape. It has NOT been called against the real service. Flipkart controls who gets
API credentials (affiliate approval) and has changed this programme before, so field names/endpoints may differ
for your account: check your affiliate dashboard docs. Credentials: FLIPKART_AFFILIATE_ID + FLIPKART_AFFILIATE_TOKEN.
"""
from __future__ import annotations

from typing import Any, List

from src.config import Settings
from src.data_validation import normalize_products
from src.models import Product, SearchCriteria
from src.providers._shopping import now_iso, request_json, search_text
from src.providers.base import ProviderBase, ProviderError

ENDPOINT = "https://affiliate-api.flipkart.net/affiliate/1.0/search.json"


def _amount(node: Any):
    return node.get("amount") if isinstance(node, dict) else None


def parse_response(data: Any, name: str = "Flipkart Affiliate API") -> List[dict]:
    if not isinstance(data, dict):
        raise ProviderError(f"{name}: unexpected response format.")
    items = data.get("products")
    if items is None:
        return []
    if not isinstance(items, list):
        raise ProviderError(f"{name}: unexpected 'products' format.")
    raws = []
    for it in items:
        base = (it or {}).get("productBaseInfoV1") if isinstance(it, dict) else None
        if not isinstance(base, dict):
            continue
        images = base.get("imageUrls") if isinstance(base.get("imageUrls"), dict) else {}
        mrp = _amount(base.get("maximumRetailPrice"))
        price = _amount(base.get("flipkartSpecialPrice")) or _amount(base.get("flipkartSellingPrice"))
        raws.append({
            "id": base.get("productId"), "name": base.get("title"), "brand": base.get("productBrand"),
            "seller": "Flipkart", "price": price, "original_price": mrp, "original_price_verified": mrp is not None,
            "url": base.get("productUrl"), "image_url": next(iter(images.values()), None) if images else None,
            "currency": (base.get("flipkartSellingPrice") or {}).get("currency") if isinstance(base.get("flipkartSellingPrice"), dict) else None,
            "availability": ("in_stock" if base.get("inStock") else "out_of_stock") if "inStock" in base else None,
            "condition": "new",
        })
    return raws


class FlipkartAffiliateProvider(ProviderBase):
    name = "Flipkart Affiliate API"
    source_type = "live"

    def __init__(self, settings: Settings):
        self.s = settings

    def is_available(self) -> bool:
        return bool(self.s.flipkart_affiliate_id and self.s.flipkart_affiliate_token)

    def search(self, criteria: SearchCriteria, limit: int = 40) -> List[Product]:
        if not self.is_available():
            raise ProviderError(f"{self.name}: FLIPKART_AFFILIATE_ID / FLIPKART_AFFILIATE_TOKEN are not set.")
        text = search_text(criteria)
        if not text:
            return []
        data = request_json(self.s, self.name, "GET", ENDPOINT, self.s.product_api_timeout,
                            params={"query": text, "resultCount": min(limit, 10)},
                            headers={"Fk-Affiliate-Id": self.s.flipkart_affiliate_id,
                                     "Fk-Affiliate-Token": self.s.flipkart_affiliate_token})
        products, _ = normalize_products(parse_response(data, self.name)[:limit], self.name, "live",
                                         retrieved_at=now_iso(), default_currency=self.s.currency)
        return products
