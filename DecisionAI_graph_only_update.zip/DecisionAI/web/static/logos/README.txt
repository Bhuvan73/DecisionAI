Optional store logos. Drop PNG/SVG files named after the retailer key here and they replace the letter badge:
amazon_in.png  flipkart.png  croma.png  reliance_digital.png  vijay_sales.png  tata_cliq.png
(Only use logos you are allowed to use. None are bundled.)
