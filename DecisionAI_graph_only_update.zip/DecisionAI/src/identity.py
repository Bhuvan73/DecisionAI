"""Structured product identity: brand, model key, storage, RAM, colour, condition, retailer.

Offers are grouped ONLY when all of these match, never because titles merely look similar.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List, Optional, Tuple

BRAND_DISPLAY = {
    "apple": "Apple", "samsung": "Samsung", "xiaomi": "Xiaomi", "redmi": "Redmi", "poco": "Poco", "oneplus": "OnePlus",
    "realme": "Realme", "motorola": "Motorola", "moto": "Motorola", "google": "Google", "nothing": "Nothing", "vivo": "Vivo",
    "iqoo": "iQOO", "oppo": "Oppo", "tecno": "Tecno", "infinix": "Infinix", "lava": "Lava", "nokia": "Nokia",
    "lenovo": "Lenovo", "hp": "HP", "dell": "Dell", "asus": "ASUS", "acer": "Acer", "msi": "MSI", "lg": "LG", "sony": "Sony",
    "logitech": "Logitech", "razer": "Razer", "corsair": "Corsair", "redragon": "Redragon", "hyperx": "HyperX",
    "steelseries": "SteelSeries", "crucial": "Crucial", "wd": "Western Digital", "seagate": "Seagate", "kingston": "Kingston",
    "sandisk": "SanDisk", "lexar": "Lexar", "adata": "ADATA", "boat": "boAt", "zebronics": "Zebronics", "microsoft": "Microsoft",
}
# product-line words that imply a brand but stay part of the model ("iPhone 15" keeps "iphone")
LINE_TO_BRAND = {"iphone": "apple", "ipad": "apple", "macbook": "apple", "airpods": "apple", "galaxy": "samsung",
                 "pixel": "google", "thinkpad": "lenovo", "ideapad": "lenovo", "legion": "lenovo", "rog": "asus", "tuf": "asus",
                 "vivobook": "asus", "zenbook": "asus", "inspiron": "dell", "xps": "dell", "pavilion": "hp", "victus": "hp",
                 "omen": "hp", "nitro": "acer", "aspire": "acer", "predator": "acer"}
COLORS = {"black", "white", "blue", "green", "red", "silver", "gold", "grey", "gray", "purple", "pink", "titanium", "graphite",
          "midnight", "starlight", "natural", "desert", "orange", "yellow", "lavender", "mint", "teal", "navy", "violet",
          "bronze", "copper", "cream", "onyx", "obsidian", "phantom", "cosmic", "space", "sky", "deep", "rose"}
CONDITION_WORDS = {"refurbished": "refurbished", "renewed": "refurbished", "reconditioned": "refurbished",
                   "preowned": "used", "pre-owned": "used", "used": "used", "secondhand": "used", "open box": "used"}
NOISE = {"smartphone", "smartphones", "mobile", "mobiles", "phone", "phones", "laptop", "laptops", "notebook", "with", "and",
         "for", "the", "new", "latest", "brand", "original", "genuine", "gaming", "inch", "inches", "display", "ram", "storage",
         "ssd", "nvme", "sata", "internal", "solid", "state", "drive", "5g", "4g", "lte", "wireless", "wired", "rgb",
         "bluetooth", "usb", "mouse", "gb", "tb", "mp", "hz", "mah", "by", "in", "of", "mobilephone", "unlocked", "dual", "sim"}
RETAILERS = {"amazon_in": ("Amazon India", ("amazon",)), "flipkart": ("Flipkart", ("flipkart",)),
             "croma": ("Croma", ("croma",)), "reliance_digital": ("Reliance Digital", ("reliance digital", "reliancedigital")),
             "vijay_sales": ("Vijay Sales", ("vijay sales", "vijaysales")), "tata_cliq": ("Tata CLiQ", ("tata cliq", "tatacliq"))}
SIZE = r"(\d+(?:\.\d+)?)\s?(tb|gb)\b"


@dataclass
class Identity:
    brand: str = ""
    model_key: str = ""
    storage_gb: Optional[int] = None
    ram_gb: Optional[int] = None
    color: str = ""
    condition: Optional[str] = None  # explicit only


def tokens(s: str) -> List[str]:
    s = s.lower().replace("’", "").replace("'", "")
    s = re.sub(r"\b(iphone|galaxy|redmi|pixel|macbook|ipad|poco|moto)\s?(\d)", r"\1 \2", s)
    return re.findall(r"[a-z0-9]+", s)


def _gb(v: str, u: str) -> int:
    return int(round(float(v) * (1000 if u == "tb" else 1)))


def extract_memory(text: str) -> Tuple[Optional[int], Optional[int], str]:
    """Return (ram_gb, storage_gb, text_with_memory_expressions_removed)."""
    low = text.lower()
    ram = storage = None
    m = re.search(r"(\d+)\s?gb\s?(?:ram|memory|ddr\d?)|(?:ram|memory)\s?:?\s?(\d+)\s?gb", low)
    if m:
        ram = int(m.group(1) or m.group(2))
        low = low[:m.start()] + " " + low[m.end():]
    m = re.search(r"(\d+)\s?gb\s?[/+]\s?(\d+(?:\.\d+)?)\s?(gb|tb)\b", low)
    if m and ram is None:
        ram, storage = int(m.group(1)), _gb(m.group(2), m.group(3))
        low = low[:m.start()] + " " + low[m.end():]
    sizes = [(_gb(a, b), mm.span()) for mm in re.finditer(SIZE, low) for a, b in [mm.groups()]]
    vals = sorted(v for v, _ in sizes)
    if storage is None and vals:
        if ram is None and len(vals) >= 2 and vals[0] <= 32:
            ram, storage = vals[0], vals[-1]
        else:
            storage = vals[-1]
    low = re.sub(SIZE, " ", low)
    return ram, storage, low


def canonical_retailer(seller: str, url: Optional[str] = None) -> Tuple[str, str]:
    """('amazon_in', 'Amazon India') for Amazon/Flipkart/etc.; ('', seller) otherwise."""
    hay = (seller or "").lower()
    host = ""
    if url:
        m = re.match(r"https?://([^/]+)", url.lower())
        host = m.group(1) if m else ""
    for key, (display, needles) in RETAILERS.items():
        if any(n in hay for n in needles) or (host and any(n in host for n in needles) and "google" not in host):
            return key, display
    return "", (seller or "Unknown seller")


def infer_brand(title: str) -> Optional[str]:
    toks = tokens(title)
    for t in toks[:4]:
        if t in BRAND_DISPLAY:
            return BRAND_DISPLAY[t]
    for t in toks[:4]:
        if t in LINE_TO_BRAND:
            return BRAND_DISPLAY[LINE_TO_BRAND[t]]
    return None


def brand_key(brand: str) -> str:
    b = re.sub(r"[^a-z0-9]", "", (brand or "").lower())
    return {"westerndigital": "wd", "moto": "motorola"}.get(b, b)


def model_key(text: str, brand: str = "") -> str:
    """Normalised model tokens: storage/RAM/colour/condition/marketing noise and the brand name removed."""
    _, _, rest = extract_memory(text)
    bk = brand_key(brand)
    out = []
    for t in tokens(rest):
        if t in COLORS or t in CONDITION_WORDS or t in NOISE or t in ("renewed", "refurb"):
            continue
        if brand_key(t) == bk or (t in BRAND_DISPLAY and brand_key(BRAND_DISPLAY[t]) == bk):
            continue
        out.append(t)
    return " ".join(out)


def parse_title(title: str, brand_hint: str = "") -> Identity:
    ident = Identity()
    ident.ram_gb, ident.storage_gb, _ = extract_memory(title)
    ident.brand = brand_hint.strip() or infer_brand(title) or (tokens(title)[0].capitalize() if tokens(title) else "")
    ident.model_key = model_key(title, ident.brand) or " ".join(tokens(title))
    toks = tokens(title)
    run: List[str] = []
    for t in toks:
        if t in COLORS:
            run.append("gray" if t == "grey" else t)
        elif run:
            break
    ident.color = " ".join(run)
    low = title.lower()
    for word, cond in CONDITION_WORDS.items():
        if re.search(rf"\b{re.escape(word)}\b", low):
            ident.condition = cond
            break
    return ident


def identity_key(p) -> str:
    """Two offers are the same product only if brand, model, storage, RAM, colour and condition all match."""
    cond = p.condition if p.condition in ("refurbished", "used") else "new"
    return "|".join([brand_key(p.brand), p.model or model_key(p.name, p.brand), str(p.storage_gb or ""),
                     str(p.ram_gb or ""), (p.color or "").lower(), cond])
