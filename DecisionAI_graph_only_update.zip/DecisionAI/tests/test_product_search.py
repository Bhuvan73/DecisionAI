import tempfile
from pathlib import Path

from src.cache import FileCache
from src.config import Settings
from src.data_validation import normalize_product
from src.models import SearchCriteria
from src.product_search import (ProductSearchService, apply_filters, dedupe_products, fallback_parse_query,
                                parse_budget, sort_products)
from src.providers.base import ProviderBase, ProviderError
from tests.fixture_provider import DemoProvider


def mk(name, price, seller="S1", brand=None, model=None, **kw):
    brand = brand or name.split()[0]
    return normalize_product({"name": name, "price": price, "seller": seller, "brand": brand,
                              "model": model or name.split(" ", 1)[-1], "category": "phone", **kw}, "t", "demo")


class Boom(ProviderBase):
    name, source_type = "Boom", "live"
    def search(self, criteria, limit=40):
        raise ProviderError("Boom: timed out.")


class Crash(ProviderBase):
    name, source_type = "Crash", "live"
    def search(self, criteria, limit=40):
        raise RuntimeError("secret-key-123 leaked?")


def svc(providers):
    return ProductSearchService(Settings(), providers, FileCache(Path(tempfile.mkdtemp()), 60, True))


def test_parse_budget_variants():
    assert parse_budget("best gaming laptop under ₹70,000") == 70000
    assert parse_budget("phone below 25k") == 25000
    assert parse_budget("laptop within 1.5 lakh") == 150000
    assert parse_budget("best mouse") is None


def test_fallback_parser_without_ai():
    c = fallback_parse_query("best laptop for coding under ₹60,000 with 16gb ram", ["Lumen"])
    assert c.category == "laptop" and c.max_budget == 60000 and c.use_case == "coding" and "16gb ram" in c.features
    c2 = fallback_parse_query("Cheapest available 1 TB SSD")
    assert c2.category == "ssd" and "lowest price" in c2.priorities and "1 tb" in c2.features


def test_budget_filter_and_tolerance():
    ps = [mk("A one", 9000), mk("B two", 10000), mk("C three", 10500)]
    assert [p.name for p in apply_filters(ps, SearchCriteria(max_budget=10000))] == ["A one", "B two"]
    assert len(apply_filters(ps, SearchCriteria(max_budget=10000, budget_tolerance=0.1))) == 3
    assert apply_filters(ps, SearchCriteria(max_budget=100)) == []


def test_brand_seller_and_stock_filters():
    ps = [mk("Aa x", 1, "S1"), mk("Bb y", 2, "S2"), mk("Cc z", 3, "S1", availability="out of stock")]
    assert len(apply_filters(ps, SearchCriteria(brands=["aa"]))) == 1
    assert len(apply_filters(ps, SearchCriteria(sellers=["s2"]))) == 1
    assert len(apply_filters(ps, SearchCriteria())) == 2  # out-of-stock removed


def test_deduplication_keeps_cheapest_and_lists_other_offers():
    ps = [mk("Aurora A7", 16999, "S1"), mk("Aurora A7", 16490, "S2"), mk("Aurora A7", 16490, "S2"), mk("Zenith Z3", 14000)]
    out = dedupe_products(ps)
    assert len(out) == 2
    a7 = [p for p in out if p.brand == "Aurora"][0]
    assert a7.price == 16490 and len(a7.other_offers) == 1 and a7.other_offers[0]["seller"] == "S1"


def test_sorting_handles_missing_ratings():
    ps = [mk("Aa a", 5, rating=None), mk("Bb b", 9, rating=4.5), mk("Cc c", 7, rating=4.0)]
    assert [p.name for p in sort_products(ps, "rating")] == ["Bb b", "Cc c", "Aa a"]
    assert [p.name for p in sort_products(ps, "price")][0] == "Aa a"


def test_demo_search_end_to_end_and_labelled_demo():
    out = svc([DemoProvider()]).search(fallback_parse_query("best phone under 25k"))
    assert out.mode == "demo" and out.products and all(p.price <= 25000 for p in out.products)
    assert all(p.source_type == "demo" and p.url is None for p in out.products)


def test_empty_results():
    out = svc([DemoProvider()]).search(fallback_parse_query("xylophone zzzz"))
    assert out.products == [] and out.statuses[0].ok


def test_failing_providers_do_not_crash_and_demo_fallback_used():
    s = Settings(llm_api_key="secret-key-123")
    service = ProductSearchService(s, [Boom(), Crash(), DemoProvider()], FileCache(Path(tempfile.mkdtemp()), 60, True))
    out = service.search(fallback_parse_query("best phone"))
    assert out.products and out.mode == "demo"
    assert [st.ok for st in out.statuses] == [False, False, True]
    assert all("secret-key-123" not in st.message for st in out.statuses)


def test_missing_demo_file_is_handled():
    out = svc([DemoProvider(Path("/nonexistent/x.json"))]).search(SearchCriteria(query="phone", category="phone"))
    assert out.products == [] and not out.statuses[0].ok


class FakeLive(ProviderBase):
    name, source_type, calls = "FakeLive", "live", 0
    def search(self, criteria, limit=40):
        FakeLive.calls += 1
        return [mk("Live one", 100)]


def test_live_results_are_cached_and_labelled():
    service = svc([FakeLive()])
    c = SearchCriteria(query="live", category="phone")
    first = service.search(c)
    second = service.search(c)
    assert first.mode == "live" and second.mode == "cached" and FakeLive.calls == 1
