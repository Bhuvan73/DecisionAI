"""Generic provider for ANY authorised JSON product API or affiliate feed you have access to.

You supply the endpoint + a field mapping in `.env`; nothing here is specific to (or pretends to be)
Amazon, Flipkart, etc. Responses are validated; failures raise ProviderError with secret-free messages.
"""
from __future__ import annotations

from typing import Any, List

import requests

from src.config import Settings
from src.data_validation import normalize_products
from src.models import Product, SearchCriteria
from src.providers.base import ProviderBase, ProviderError
from src.utils.validation import clean_url

OUR_FIELDS = ["id", "name", "brand", "model", "category", "seller", "price", "original_price",
              "original_price_verified", "currency", "url", "image_url", "rating", "review_count",
              "availability", "specs", "features", "use_cases", "warranty_months"]


def dig(obj: Any, path: str) -> Any:
    """Read 'a.b.0.c' from nested dict/list; None if missing."""
    cur = obj
    for part in [p for p in path.split(".") if p]:
        if isinstance(cur, dict):
            cur = cur.get(part)
        elif isinstance(cur, list) and part.isdigit() and int(part) < len(cur):
            cur = cur[int(part)]
        else:
            return None
    return cur


def map_item(item: Any, field_map: dict) -> dict:
    if not isinstance(item, dict):
        return {}
    return {ours: dig(item, theirs) for ours, theirs in field_map.items() if ours in OUR_FIELDS and isinstance(theirs, str)}


class ConfiguredApiProvider(ProviderBase):
    source_type = "live"

    def __init__(self, settings: Settings):
        self.s = settings
        self.name = settings.product_api_name or "Configured product API"

    def is_available(self) -> bool:
        return bool(self.s.product_api_url and self.s.product_api_field_map)

    def build_url(self, query: str, limit: int) -> str:
        from urllib.parse import quote_plus
        return self.s.product_api_url.replace("{query}", quote_plus(query)).replace("{limit}", str(limit))

    def search(self, criteria: SearchCriteria, limit: int = 40) -> List[Product]:
        if not self.is_available():
            raise ProviderError("Product API is not fully configured (PRODUCT_API_URL and PRODUCT_API_FIELD_MAP required).")
        url = self.build_url(criteria.query or " ".join(criteria.keywords), limit)
        if not clean_url(url):
            raise ProviderError("PRODUCT_API_URL is not a valid http(s) URL.")
        headers = {"Accept": "application/json"}
        if self.s.product_api_key:
            prefix = (self.s.product_api_key_prefix + " ") if self.s.product_api_key_prefix else ""
            headers[self.s.product_api_key_header] = prefix + self.s.product_api_key
        try:
            resp = requests.get(url, headers=headers, timeout=self.s.product_api_timeout)
        except requests.Timeout:
            raise ProviderError(f"{self.name}: request timed out.")
        except requests.RequestException as exc:
            raise ProviderError(self.s.redact(f"{self.name}: network error ({type(exc).__name__})."))
        if resp.status_code == 429:
            raise ProviderError(f"{self.name}: rate limit reached. Try again later.")
        if resp.status_code in (401, 403):
            raise ProviderError(f"{self.name}: access denied - check the API key/permissions.")
        if resp.status_code != 200:
            raise ProviderError(f"{self.name}: unexpected HTTP status {resp.status_code}.")
        try:
            data = resp.json()
        except ValueError:
            raise ProviderError(f"{self.name}: response was not valid JSON.")
        items = dig(data, self.s.product_api_items_path) if self.s.product_api_items_path else data
        if not isinstance(items, list):
            raise ProviderError(f"{self.name}: could not find the item list (check PRODUCT_API_ITEMS_PATH).")
        raws = [map_item(i, self.s.product_api_field_map) for i in items[:limit]]
        products, rejected = normalize_products(raws, self.name, "live", default_currency=self.s.currency)
        if items and not products:
            raise ProviderError(f"{self.name}: no valid products in response ({rejected} rejected). Check PRODUCT_API_FIELD_MAP.")
        return products
