"""Shared helpers for Google-Shopping-style API providers."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, List, Optional

import requests

from src.config import Settings
from src.models import SearchCriteria
from src.providers.base import ProviderError


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def search_text(c: SearchCriteria, limit_words: int = 10) -> str:
    """The text sent to a provider: the user's words without budget phrases (price filtering is done locally)."""
    from src.matching import MONEY
    text = MONEY.sub(" ", c.query or "")
    text = " ".join(w for w in text.split() if w.lower() not in ("best", "under", "below", "within", "upto", "for"))
    return " ".join(text.split()[:limit_words]) or " ".join(c.keywords)


def http_error(name: str, status: int) -> ProviderError:
    if status in (401, 403):
        return ProviderError(f"{name}: access denied - check the API key and plan.")
    if status == 429:
        return ProviderError(f"{name}: rate limit or quota reached. Try again later.")
    return ProviderError(f"{name}: unexpected HTTP status {status}.")


def request_json(s: Settings, name: str, method: str, url: str, timeout: float, **kw) -> Any:
    try:
        resp = requests.request(method, url, timeout=timeout, **kw)
    except requests.Timeout:
        raise ProviderError(f"{name}: request timed out.")
    except requests.RequestException as exc:
        raise ProviderError(s.redact(f"{name}: network error ({type(exc).__name__})."))
    if resp.status_code != 200:
        raise http_error(name, resp.status_code)
    try:
        return resp.json()
    except ValueError:
        raise ProviderError(f"{name}: response was not valid JSON.")


def first(*vals: Any) -> Optional[Any]:
    for v in vals:
        if v not in (None, ""):
            return v
    return None
