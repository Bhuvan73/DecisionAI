from datetime import datetime, timezone

from src.db import Database
from src.providers.serpapi_provider import _merchant_offers


def test_history_keeps_later_same_day_price_changes_as_separate_points():
    rows = [
        {"observed_at": "2026-11-04T10:00:00+00:00", "price": 61900, "seller": "Store A"},
        {"observed_at": "2026-11-04T10:00:20+00:00", "price": 62500, "seller": "Store B"},
        {"observed_at": "2026-11-04T11:15:00+00:00", "price": 62900, "seller": "Store A"},
    ]
    series = Database.daily_series(rows)
    assert len(series) == 3
    assert [p["price"] for p in series] == [61900, 62500, 62900]


def test_immersive_product_response_extracts_direct_merchant_links():
    parent = {"product_id": "abc", "title": "Example Phone 128GB", "thumbnail": "https://img.example/a.jpg"}
    payload = {"stores": [
        {"name": "Amazon.in", "price": "₹61,900", "extracted_price": 61900,
         "link": "https://www.amazon.in/dp/EXAMPLE"},
        {"name": "Flipkart", "price": "₹62,500", "extracted_price": 62500,
         "link": "https://www.flipkart.com/example/p/itm123"},
    ]}
    offers = _merchant_offers(payload, parent)
    assert len(offers) == 2
    assert offers[0]["url"].startswith("https://www.amazon.in/")
    assert offers[1]["url"].startswith("https://www.flipkart.com/")


def test_history_keeps_two_searches_within_same_second_as_distinct_points():
    rows = [
        {"observed_at": "2026-11-04T10:00:00.100000+00:00", "price": 61900, "seller": "Store A"},
        {"observed_at": "2026-11-04T10:00:00.900000+00:00", "price": 62500, "seller": "Store A"},
    ]
    series = Database.daily_series(rows)
    assert len(series) == 2
    assert [p["price"] for p in series] == [61900, 62500]


def test_history_groups_sellers_from_one_search_into_one_lowest_point():
    rows = [
        {"observed_at": "2026-11-04T10:00:00.123456+00:00", "price": 62500, "seller": "Store B"},
        {"observed_at": "2026-11-04T10:00:00.123456+00:00", "price": 61900, "seller": "Store A"},
    ]
    series = Database.daily_series(rows)
    assert len(series) == 1
    assert series[0]["price"] == 61900
    assert series[0]["seller"] == "Store A"
