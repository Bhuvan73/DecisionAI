"""Tiny JSON-file TTL cache for live provider results."""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path
from typing import List, Optional


class FileCache:
    def __init__(self, directory: Path, ttl_minutes: float = 60.0, enabled: bool = True):
        self.dir, self.ttl, self.enabled = Path(directory), ttl_minutes * 60, enabled

    def _path(self, key: str) -> Path:
        return self.dir / (hashlib.sha256(key.encode()).hexdigest()[:24] + ".json")

    def get(self, key: str) -> Optional[List[dict]]:
        if not self.enabled:
            return None
        p = self._path(key)
        try:
            blob = json.loads(p.read_text(encoding="utf-8"))
            if time.time() - float(blob["saved_at"]) > self.ttl or not isinstance(blob["items"], list):
                return None
            return blob["items"]
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def set(self, key: str, items: List[dict]) -> None:
        if not self.enabled:
            return
        try:
            self.dir.mkdir(parents=True, exist_ok=True)
            self._path(key).write_text(json.dumps({"saved_at": time.time(), "items": items}), encoding="utf-8")
        except OSError:
            pass  # caching is best-effort
