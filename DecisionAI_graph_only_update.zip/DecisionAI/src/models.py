"""Shared data models."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class Product:
    id: str
    name: str
    price: float
    brand: str = ""
    model: str = ""
    category: str = ""
    seller: str = "Unknown seller"
    currency: str = "INR"
    original_price: Optional[float] = None  # only set when verified by the source
    url: Optional[str] = None  # validated http(s) URL or None
    image_url: Optional[str] = None
    rating: Optional[float] = None
    review_count: Optional[int] = None
    availability: str = "unknown"
    source: str = ""
    source_type: str = "demo"  # "live" | "cached" | "demo"
    retrieved_at: str = ""
    specs: Dict[str, Any] = field(default_factory=dict)
    features: List[str] = field(default_factory=list)
    use_cases: List[str] = field(default_factory=list)
    warranty_months: Optional[int] = None
    condition: str = "unknown"  # new | refurbished | used | unknown
    storage_gb: Optional[int] = None
    ram_gb: Optional[int] = None
    color: str = ""
    shipping: Optional[str] = None   # only when the source states it
    delivery: Optional[str] = None   # only when the source states it
    retailer: str = ""               # canonical key, e.g. "amazon_in", "flipkart"
    url_kind: str = "direct"         # "direct" (merchant page) | "aggregator" (e.g. Google Shopping page)
    other_offers: List[Dict[str, Any]] = field(default_factory=list)  # filled by grouping

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Product":
        names = set(cls.__dataclass_fields__)
        return cls(**{k: v for k, v in d.items() if k in names})


@dataclass
class SearchCriteria:
    query: str = ""
    category: Optional[str] = None
    max_budget: Optional[float] = None
    min_budget: Optional[float] = None
    brands: List[str] = field(default_factory=list)
    sellers: List[str] = field(default_factory=list)
    use_case: Optional[str] = None
    features: List[str] = field(default_factory=list)
    keywords: List[str] = field(default_factory=list)
    priorities: List[str] = field(default_factory=list)
    budget_tolerance: float = 0.0  # 0.1 = allow 10% over budget (score decays)
    in_stock_only: bool = False
    conditions: List[str] = field(default_factory=list)  # subset of new/refurbished/used; empty = all
    compare_queries: List[str] = field(default_factory=list)


@dataclass
class ScoredProduct:
    product: Product
    total: float
    components: Dict[str, Optional[float]]
    quality: float
    value_index: float
    matched_features: List[str] = field(default_factory=list)
    missing_features: List[str] = field(default_factory=list)
    pros: List[str] = field(default_factory=list)
    cons: List[str] = field(default_factory=list)
    qualifies: bool = True


@dataclass
class Recommendation:
    label: str  # "Best Overall" | "Lowest Price" | "Best Value"
    scored: ScoredProduct
    reason: str


@dataclass
class RecommendationResult:
    recommendations: List[Recommendation]
    ranked: List[ScoredProduct]
    notes: List[str]
    weights_used: Dict[str, float]
    sufficient: bool
