import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import requests

from src.cache import FileCache
from src.config import Settings
from src.data_validation import normalize_products
from src.models import SearchCriteria
from src.product_search import ProductSearchService, dedupe_products, fallback_parse_query
from src.providers.base import ProviderError
from tests.fixture_provider import DemoProvider
from src.providers.serpapi_provider import SerpApiShoppingProvider, parse_response as parse_serpapi
from src.providers.serper_provider import SerperShoppingProvider, parse_response as parse_serper

# NOTE: these payloads are hand-written FIXTURES shaped like each vendor's public documentation.
# They are not real retailer data and no live API was called.
SERPAPI_FIXTURE = {"shopping_results": [
    {"position": 1, "title": "Apple iPhone 17 Pro Max 256GB Cosmic Orange", "source": "Amazon.in", "price": "₹1,49,900",
     "extracted_price": 149900, "link": "https://www.amazon.in/dp/FIXTURE1", "thumbnail": "https://img.example.com/a.jpg",
     "rating": 4.5, "reviews": 120, "delivery": "Free delivery"},
    {"position": 2, "title": "Apple iPhone 17 Pro Max (256 GB) - Cosmic Orange", "source": "Flipkart", "price": "₹1,48,500",
     "extracted_price": 148500, "product_link": "https://www.google.com/shopping/product/FIXTURE2"},
    {"position": 3, "title": "Apple iPhone 17 Pro Max 256GB Cosmic Orange", "source": "Croma", "extracted_price": 150500,
     "link": "https://www.croma.com/p/FIXTURE3", "old_price": "₹1,59,900", "extracted_old_price": 159900},
    {"position": 4, "title": "Apple iPhone 17 Pro Max 512GB Cosmic Orange", "source": "Croma", "extracted_price": 170500,
     "link": "https://www.croma.com/p/FIXTURE4"},
    {"title": "Broken record without a price", "source": "X"}, "not-a-dict"]}
SERPER_FIXTURE = {"shopping": [{"title": "Logitech G304 Wireless Gaming Mouse", "source": "Amazon.in", "price": "₹2,495",
                                "link": "https://www.amazon.in/dp/FIXTURE5", "imageUrl": "https://img.example.com/m.jpg",
                                "rating": 4.6, "ratingCount": 9000, "delivery": "Free delivery"}]}


def resp(status=200, body=None, bad_json=False):
    r = MagicMock(); r.status_code = status
    r.json.side_effect = ValueError("bad") if bad_json else None
    if not bad_json:
        r.json.return_value = body
    return r


def svc(providers, settings=None):
    return ProductSearchService(settings or Settings(), providers, FileCache(Path(tempfile.mkdtemp()), 60, True))


def test_serpapi_parsing_normalises_and_drops_invalid():
    raws = parse_serpapi(SERPAPI_FIXTURE)
    products, rejected = normalize_products(raws, "fixture", "live")
    assert len(products) == 4 and rejected == 1  # non-dict entry skipped, priceless entry rejected
    assert [p.retailer for p in products[:3]] == ["amazon_in", "flipkart", "croma"]
    assert products[1].url_kind == "aggregator" and products[0].url_kind == "direct"
    assert products[2].original_price == 159900  # source-reported, shown only because the source gave it


def test_serper_parsing():
    products, _ = normalize_products(parse_serper(SERPER_FIXTURE), "fixture", "live")
    assert products[0].price == 2495 and products[0].review_count == 9000 and products[0].retailer == "amazon_in"


def test_serpapi_api_level_errors_and_empty():
    assert parse_serpapi({"error": "Google hasn't returned any results for this query."}) == []
    assert parse_serpapi({}) == []
    for body in ({"error": "Invalid API key. Your API key should be here: https://serpapi.com/manage-api-key"}, {"error": "Your account has run out of searches."}, [1, 2]):
        try:
            parse_serpapi(body); assert False
        except ProviderError:
            pass


def _run_with(provider, **resp_kw):
    with patch("src.providers._shopping.requests.request", return_value=resp(**resp_kw)):
        return provider.search(SearchCriteria(query="iphone 17 pro max"))


def test_provider_http_failures_are_reported_without_secrets():
    s = Settings(serpapi_key="sk-secret-12345", serper_key="serper-secret-9")
    for provider in (SerpApiShoppingProvider(s), SerperShoppingProvider(s)):
        for status, needle in ((401, "access denied"), (403, "access denied"), (429, "rate limit"), (500, "500")):
            try:
                _run_with(provider, status=status); assert False
            except ProviderError as e:
                assert needle in str(e) and "secret" not in str(e)
        try:
            _run_with(provider, bad_json=True); assert False
        except ProviderError as e:
            assert "not valid JSON" in str(e)
    with patch("src.providers._shopping.requests.request", side_effect=requests.Timeout()):
        try:
            SerpApiShoppingProvider(s).search(SearchCriteria(query="x")); assert False
        except ProviderError as e:
            assert "timed out" in str(e)
    with patch("src.providers._shopping.requests.request", side_effect=requests.ConnectionError("boom sk-secret-12345")):
        try:
            SerpApiShoppingProvider(s).search(SearchCriteria(query="x")); assert False
        except ProviderError as e:
            assert "sk-secret-12345" not in str(e)


def test_missing_credentials_is_a_clear_error_not_a_crash():
    for p in (SerpApiShoppingProvider(Settings()), SerperShoppingProvider(Settings())):
        assert not p.is_available()
        try:
            p.search(SearchCriteria(query="x")); assert False
        except ProviderError as e:
            assert "not set" in str(e)


def test_end_to_end_multi_seller_grouping_from_fixture_provider():
    s = Settings(serpapi_key="k")
    with patch("src.providers._shopping.requests.request", return_value=resp(body=SERPAPI_FIXTURE)):
        service = svc([SerpApiShoppingProvider(s), DemoProvider()], s)
        out = service.search(fallback_parse_query("iPhone 17 Pro Max"))
    assert out.mode == "live" and "Demo" not in " ".join(x.provider for x in out.statuses if x.count)
    assert len(out.products) == 2  # 256GB and 512GB are separate products
    g = out.products[0]
    assert g.storage_gb == 256 and g.price == 148500 and len(g.other_offers) == 2
    assert out.offer_count == 4 and out.seller_count == 3
    assert not any(p.source_type == "demo" for p in out.raw_products)  # demo never mixes with live


def test_live_failure_falls_back_to_labelled_demo_and_reports_error():
    s = Settings(serpapi_key="k")
    with patch("src.providers._shopping.requests.request", return_value=resp(status=429)):
        out = svc([SerpApiShoppingProvider(s), DemoProvider()], s).search(fallback_parse_query("best phone under 30k"))
    assert out.mode == "demo" and out.products and any((not x.ok) and "rate limit" in x.message for x in out.statuses)
    assert all(p.source_type == "demo" for p in out.raw_products)


def test_no_demo_fallback_when_disabled():
    s = Settings(serpapi_key="k", allow_demo_fallback=False)
    with patch("src.providers._shopping.requests.request", return_value=resp(status=401)):
        out = svc([SerpApiShoppingProvider(s), DemoProvider()], s).search(fallback_parse_query("best phone"))
    assert out.products == [] and out.mode == "demo" and not out.statuses[0].ok


def test_second_identical_search_uses_cache_not_the_network():
    s = Settings(serpapi_key="k")
    with patch("src.providers._shopping.requests.request", return_value=resp(body=SERPAPI_FIXTURE)) as m:
        service = svc([SerpApiShoppingProvider(s)], s)
        service.fetch(fallback_parse_query("iPhone 17 Pro Max"))
        second = service.fetch(fallback_parse_query("iPhone 17 Pro Max"))
    assert m.call_count == 1 and second.mode == "cached" and all(p.source_type == "cached" for p in second.raw_products)


# ------------------------------------------------------------------ HTML rendering
def groups_from_fixture():
    products, _ = normalize_products(parse_serpapi(SERPAPI_FIXTURE), "Google Shopping via SerpApi (fixture)", "live")
    return dedupe_products(products)
















def test_group_borrows_image_and_rating_from_any_offer_of_the_same_product():
    g = [x for x in groups_from_fixture() if x.storage_gb == 256][0]
    assert g.seller == "Flipkart" and g.image_url == "https://img.example.com/a.jpg" and g.rating == 4.5
