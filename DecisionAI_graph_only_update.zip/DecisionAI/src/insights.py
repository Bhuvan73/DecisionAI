"""Price insight: every sentence is derived from retrieved offers or stored observations. Nothing is guessed."""
from __future__ import annotations

from typing import List, Optional

from src.utils.formatting import format_inr


def price_insight(view: dict, series: List[dict]) -> dict:
    facts: List[str] = []
    offers = [o for o in view.get("offers", []) if o.get("available")]
    if view.get("source_type") == "demo":
        facts.append("Sample data: these prices are fictional, so this insight is only an illustration.")
    if len(offers) >= 2:
        a, b = offers[0], offers[1]
        facts.append(f"This is the lowest price among the {len(offers)} offers checked: {format_inr(a['price'])} at {a['seller']}.")
        gap = b["price"] - a["price"]
        facts.append(f"{b['seller']} lists the same product for {format_inr(gap)} more." if gap > 0
                     else f"{b['seller']} lists the same price.")
    elif len(offers) == 1:
        facts.append(f"Only one seller was found ({offers[0]['seller']} at {format_inr(offers[0]['price'])}), so there is nothing to compare it with.")
    else:
        facts.append("No verified prices were retrieved for this product.")
    cur = offers[0]["price"] if offers else None
    days = {p["date"] for p in series}
    if cur is not None and len(days) >= 2 and view.get("source_type") == "live":
        prior = [p["price"] for p in series if p["price"] is not None]
        lo, avg = min(prior), sum(prior) / len(prior)
        if cur <= lo:
            facts.append(f"This matches or beats the lowest price this app has recorded ({format_inr(lo)}).")
        else:
            facts.append(f"It is {format_inr(cur - lo)} above the lowest price this app has recorded ({format_inr(lo)}).")
        facts.append(f"It is {'below' if cur < avg else 'above'} the recorded average of {format_inr(avg)}.")
    else:
        facts.append("There is not enough historical data to determine whether this is a good time to buy.")
    return {"facts": facts, "text": " ".join(facts[:3]), "grounded": True}
