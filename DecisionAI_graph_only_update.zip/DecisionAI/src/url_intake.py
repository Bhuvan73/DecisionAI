"""Product-link intake. No page is fetched: we validate the URL, recognise the retailer and read the product name
from the link's own text (its slug). Prices/details always come from an authorised provider, never from scraping."""
from __future__ import annotations

import re
from typing import Optional
from urllib.parse import unquote, urlparse

from src.utils.validation import clean_url

HOSTS = {"amazon_in": ("Amazon India", ("amazon.in", "amzn.in")), "flipkart": ("Flipkart", ("flipkart.com", "fkrt.it", "dl.flipkart.com")),
         "croma": ("Croma", ("croma.com",)), "reliance_digital": ("Reliance Digital", ("reliancedigital.in",)),
         "vijay_sales": ("Vijay Sales", ("vijaysales.com",)), "tata_cliq": ("Tata CLiQ", ("tatacliq.com",))}
JUNK = {"dp", "gp", "product", "p", "pd", "itm", "ref", "buy", "html", "www", "amp", "s"}


def retailer_for_host(host: str) -> Optional[str]:
    host = host.lower().split(":")[0]
    for key, (_, domains) in HOSTS.items():
        if any(host == d or host.endswith("." + d) for d in domains):
            return key
    return None


def _is_id(tok: str) -> bool:
    return tok.isdigit() and len(tok) >= 6 or (len(tok) >= 8 and any(c.isdigit() for c in tok) and any(c.isalpha() for c in tok))


def title_from_path(path: str, retailer: Optional[str]) -> str:
    segs = [unquote(s) for s in path.split("/") if s]
    cands = []
    for s in segs:
        words = [w for w in re.split(r"[-_+\s]+", s) if w]
        if len(words) >= 2 and not all(_is_id(w) or w.lower() in JUNK for w in words):
            cands.append(words)
    if not cands:
        return ""
    words = max(cands[:3] if retailer in ("amazon_in", "flipkart", "croma") else cands, key=len)
    words = [w for w in words if not _is_id(w) and w.lower() not in JUNK]
    return " ".join(words).strip()


def intake_url(raw: str) -> dict:
    url = clean_url((raw or "").strip())
    if not url:
        return {"valid": False, "error": "That doesn't look like a valid product link (it must start with http:// or https://).",
                "retailer": None, "title_guess": ""}
    p = urlparse(url)
    key = retailer_for_host(p.netloc)
    title = title_from_path(p.path, key)
    return {"valid": True, "url": url, "retailer": key, "retailer_name": HOSTS[key][0] if key else p.netloc,
            "recognised": key is not None, "title_guess": title,
            "notes": ["The product name was read from the link text only; the page itself was not opened.",
                      "Prices come from the configured data providers, which may or may not list this seller."]}
