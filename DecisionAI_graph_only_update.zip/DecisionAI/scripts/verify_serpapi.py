"""LIVE verification against the real SerpApi service, using YOUR key from .env.

This was NOT run by the author (no key/network in the build environment). Run it yourself:
    python scripts/verify_serpapi.py            # uses 4 searches + 0 repeats (cache) from your SerpApi allowance
    python scripts/verify_serpapi.py "my query" # your own query instead of the four defaults (1 search)
It prints real sellers/prices, then checks them: sorted offers, positive prices, statistics, separate variants,
stored price snapshots and cache behaviour (a repeated search must not call SerpApi again).
"""
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import requests  # noqa: E402
from src.api import ApiError, AppService  # noqa: E402
from src.config import LOCAL_DIR, Settings  # noqa: E402
from src.db import Database  # noqa: E402

QUERIES = ["iPhone 16 128GB", "Samsung Galaxy S25", "Sony WH-1000XM5", "Lenovo LOQ RTX 4060"]


def main():
    s = Settings.from_env()
    if not s.serpapi_key:
        print("SERPAPI_KEY is not set. Put it in .env first (see .env.example).")
        return 2
    calls = []
    real = requests.request

    def counting(method, url, **kw):
        if "serpapi.com" in url:
            calls.append(url)
        return real(method, url, **kw)
    requests.request = counting
    LOCAL_DIR.mkdir(exist_ok=True)
    app = AppService(s, Database(str(LOCAL_DIR / "verify.db")))
    failures, queries = [], sys.argv[1:] or QUERIES
    for q in queries:
        print(f"\n=== {q}")
        try:
            r = app.search({"query": q})
        except ApiError as e:
            print(f"  ERROR {e.status}: {e.message}")
            failures.append(f"{q}: {e.message}")
            continue
        print(f"  mode={r['mode']} products={len(r['products'])} offers={r['offer_count']} sellers={r['seller_count']} (SerpApi calls so far: {len(calls)})")
        if not r["products"]:
            print("  no products returned (SerpApi gave no usable shopping results)")
            failures.append(f"{q}: empty")
            continue
        seen_variants = set()
        for p in r["products"][:6]:
            offers = [o for o in p["offers"] if o["available"]]
            prices = [o["price"] for o in offers]
            print(f"  - {p['name']} | {p['variant_label'] or '-'} | {p['match']['label'] or 'browse'} | lowest {p['stats']['lowest']} avg {p['stats']['average']} high {p['stats']['highest']}")
            for o in offers[:4]:
                print(f"      {o['seller']:<24} ₹{o['price']:<10} {o['kind']:<10} {o['url'][:70]}")
            checks = {
                "prices positive": all(x > 0 for x in prices), "sorted ascending": prices == sorted(prices),
                "stats match": (not prices) or (p["stats"]["lowest"] == min(prices) and p["stats"]["highest"] == max(prices) and abs(p["stats"]["average"] - sum(prices) / len(prices)) < 0.01),
                "has sellers": all(o["seller"] for o in offers), "variant unique": p["key"] not in seen_variants,
                "snapshots stored": len(app.db.history(p["key"])) >= 1,
            }
            seen_variants.add(p["key"])
            for name, ok in checks.items():
                if not ok:
                    failures.append(f"{q} / {p['name']}: {name}")
                    print(f"      CHECK FAILED: {name}")
    if queries:
        before = len(calls)
        r2 = app.search({"query": queries[0].upper() + "  "})
        ok = len(calls) == before and r2["mode"] == "cached"
        print(f"\ncache check: repeated search made {len(calls) - before} extra SerpApi calls, mode={r2['mode']} -> {'OK' if ok else 'FAILED'}")
        if not ok:
            failures.append("cache")
    print(f"\nTotal SerpApi calls: {len(calls)}. Database for inspection: {LOCAL_DIR / 'verify.db'}")
    print("RESULT:", "ALL CHECKS PASSED" if not failures else "FAILURES: " + "; ".join(failures))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
