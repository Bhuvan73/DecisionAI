"""Offer rows for one product: verified offers sorted by price + honest placeholders for Amazon India / Flipkart."""
from __future__ import annotations

from typing import List, Optional, Tuple

from src.identity import RETAILERS
from src.models import Product
from src.utils.formatting import add_affiliate, retailer_search_url, search_links
from src.utils.validation import clean_url

PINNED = ("amazon_in", "flipkart")


def seller_id(name: str, retailer: str = "") -> str:
    import re
    return retailer or re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "unknown"


def build_offers(p: Product, amazon_tag: str = "") -> Tuple[List[dict], bool]:
    raw = [{"seller": p.seller, "retailer": p.retailer, "price": p.price, "original_price": p.original_price, "url": p.url,
            "url_kind": p.url_kind, "condition": p.condition, "shipping": p.shipping, "delivery": p.delivery,
            "source_type": p.source_type, "availability": p.availability, "source": p.source,
            "retrieved_at": p.retrieved_at, "rating": p.rating, "review_count": p.review_count}] + [{**o, "source": o.get("source", p.source), "retrieved_at": o.get("retrieved_at", p.retrieved_at)}
                                               for o in p.other_offers]
    raw.sort(key=lambda o: (o["price"], o["seller"]))
    rows, affiliate = [], False
    for o in raw:
        url = clean_url(o.get("url"))
        kind = "search"
        if url:
            kind = "aggregator" if o.get("url_kind") == "aggregator" else "direct"
            if kind == "direct":
                url, applied = add_affiliate(url, amazon_tag)
                affiliate = affiliate or applied
        else:  # price is verified but the source gave no product link: labelled search link, never a made-up product URL
            url = retailer_search_url(o.get("retailer", ""), p.name) or search_links(p.name)["Google Shopping (India)"]
        rows.append({"seller": o["seller"], "seller_id": seller_id(o["seller"], o.get("retailer", "")), "retailer": o.get("retailer", ""),
                     "price": o["price"], "original_price": o.get("original_price"), "url": url, "kind": kind, "available": True,
                     "availability": o.get("availability") or "unknown", "condition": o.get("condition"),
                     "shipping": o.get("shipping"), "delivery": o.get("delivery"), "source_type": o.get("source_type"),
                     "source": o.get("source"), "retrieved_at": o.get("retrieved_at"), "last_checked": o.get("retrieved_at"),
                     "product_url": url, "rating": o.get("rating"), "review_count": o.get("review_count"), "currency": p.currency})
    have = {r["retailer"] for r in rows if r["retailer"]}
    for key in PINNED:
        if key not in have:
            rows.append({"seller": RETAILERS[key][0], "seller_id": key, "retailer": key, "price": None, "original_price": None,
                         "url": retailer_search_url(key, p.name), "kind": "search", "available": False, "availability": "unknown",
                         "condition": None, "shipping": None, "delivery": None, "source_type": p.source_type, "source": None,
                         "retrieved_at": None, "last_checked": None, "product_url": None, "rating": None, "review_count": None, "currency": p.currency})
    low: Optional[float] = min((r["price"] for r in rows if r["available"]), default=None)
    for r in rows:
        r["diff"] = round(r["price"] - low, 2) if r["available"] and low is not None else None
        r["is_lowest"] = bool(r["available"] and r["price"] == low)
    return rows, affiliate


def offer_stats(rows: List[dict]) -> dict:
    prices = [r["price"] for r in rows if r["available"]]
    if not prices:
        return {"count": 0, "lowest": None, "highest": None, "average": None, "comparable": False}
    return {"count": len(prices), "lowest": min(prices), "highest": max(prices), "average": round(sum(prices) / len(prices), 2),
            "comparable": len(prices) >= 2}
