import json
import os
import tempfile
import threading
import urllib.error
import urllib.request
from datetime import timedelta
from pathlib import Path

from server import create_server
from src import rag
from src.api import ApiError, AppService
from src.cache import FileCache
from src.config import Settings
from src.data_validation import normalize_products
from src.db import Database, utcnow
from src.insights import price_insight
from src.llm import LLMClient, LLMError
from src.models import Product
from src.offers import build_offers, offer_stats
from src.product_search import ProductSearchService, dedupe_products
from src.providers.base import ProviderBase, ProviderError
from tests.fixture_provider import DemoProvider
from src.providers.flipkart_provider import FlipkartAffiliateProvider, parse_response as parse_flipkart
from src.url_intake import intake_url

# FIXTURES: hand-written, not retailer data.
RAWS = [
    {"id": "1", "name": "Apple iPhone 17 Pro Max 256GB Cosmic Orange", "seller": "Amazon.in", "price": 149900, "url": "https://www.amazon.in/dp/FIX1", "rating": 4.5, "review_count": 120},
    {"id": "2", "name": "Apple iPhone 17 Pro Max (256 GB) - Cosmic Orange", "seller": "Flipkart", "price": 148500, "url": "https://www.flipkart.com/p/FIX2"},
    {"id": "3", "name": "Apple iPhone 17 Pro Max 256GB Cosmic Orange", "seller": "Croma", "price": 152500, "url": "https://www.croma.com/p/FIX3"},
    {"id": "4", "name": "Apple iPhone 17 Pro Max 512GB Cosmic Orange", "seller": "Croma", "price": 170500, "url": "https://www.croma.com/p/FIX4"},
]


class FixtureLive(ProviderBase):
    name, source_type = "Fixture live", "live"
    prices = None

    def search(self, criteria, limit=40):
        raws = [dict(r) for r in RAWS]
        if self.prices:
            for r, p in zip(raws, self.prices):
                r["price"] = p
        return normalize_products(raws, self.name, "live")[0]


def make_app(live=True, llm=None, settings=None, url_reader=None):
    s = settings or Settings()
    db = Database(os.path.join(tempfile.mkdtemp(), "t.db"))
    app = AppService(s, db, llm=llm or LLMClient(s), url_reader=url_reader)
    provs = [FixtureLive()] if live else [DemoProvider()]
    app.assistant.search = ProductSearchService(s, provs, FileCache(Path(tempfile.mkdtemp()), 60, False))
    return app


class GoodLLM(LLMClient):
    available = True

    def __init__(self, reply):
        super().__init__(Settings())
        self.reply = reply

    def ask(self, system, user):
        return self.reply

    def parse_criteria(self, q, cats):
        return None

    def explain(self, r, c):
        return None


class DownLLM(GoodLLM):
    def ask(self, system, user):
        raise LLMError("The AI request timed out.")


# ------------------------------------------------------------------ database / history / alerts
def test_observations_are_stored_and_deduplicated_within_gap():
    db = Database(os.path.join(tempfile.mkdtemp(), "d.db"))
    t0 = utcnow() - timedelta(days=3)
    o = [{"seller_id": "flipkart", "seller": "Flipkart", "price": 100.0, "currency": "INR", "url": "https://x.example.com/p"}]
    assert db.record_offers("k1", o, now=t0) == 1
    assert db.record_offers("k1", o, now=t0 + timedelta(hours=1)) == 0          # same price, too soon
    assert db.record_offers("k1", o, now=t0 + timedelta(hours=7)) == 1          # same price, later: a real new observation
    o[0]["price"] = 90.0
    assert db.record_offers("k1", o, now=t0 + timedelta(hours=8)) == 1          # price changed: always stored
    assert len(db.history("k1")) == 3 and len(db.list_offers("k1")) == 1 and db.list_offers("k1")[0]["price"] == 90.0


def test_history_series_stats_and_no_fake_history():
    db = Database(os.path.join(tempfile.mkdtemp(), "d.db"))
    assert db.history("nothing") == [] and Database.series_stats(Database.daily_series([])) is None
    now = utcnow()
    for days, price, seller in ((10, 120.0, "a"), (10, 110.0, "b"), (5, 100.0, "a"), (1, 130.0, "a")):
        db.record_offers("k", [{"seller_id": seller, "seller": seller.upper(), "price": price}], now=now - timedelta(days=days))
    series = Database.daily_series(db.history("k"))
    assert [p["price"] for p in series] == [110.0, 100.0, 130.0]  # lowest per day
    st = Database.series_stats(series)
    assert (st["lowest"], st["highest"], st["average"]) == (100.0, 130.0, 113.33)
    assert len(db.history("k", days=7)) == 2 and len(db.history("k", seller="B")) == 1


def test_alerts_trigger_only_when_target_reached_and_only_once():
    db = Database(os.path.join(tempfile.mkdtemp(), "d.db"))
    aid = db.add_alert("k", "Phone", 1000.0)
    assert db.trigger_alerts("k", 1200.0, "S") == []
    hit = db.trigger_alerts("k", 950.0, "Flipkart")
    assert [a["id"] for a in hit] == [aid]
    assert db.trigger_alerts("k", 900.0, "Flipkart") == []  # already triggered
    a = db.list_alerts()[0]
    assert a["active"] == 0 and a["triggered_price"] == 950.0 and db.delete_alert(aid)


# ------------------------------------------------------------------ offers / stats / insight
def test_offers_sorted_diff_lowest_pinned_rows_and_affiliate():
    g = dedupe_products(normalize_products(RAWS, "f", "live")[0])
    g256 = [x for x in g if x.storage_gb == 256][0]
    rows, aff = build_offers(g256, amazon_tag="tag-21")
    verified = [r for r in rows if r["available"]]
    assert [r["seller"] for r in verified] == ["Flipkart", "Amazon India", "Croma"]
    assert [r["diff"] for r in verified] == [0, 1400, 4000] and verified[0]["is_lowest"] and not verified[1]["is_lowest"]
    assert aff and "tag=tag-21" in verified[1]["url"] and "tag=" not in verified[2]["url"]
    g512 = [x for x in g if x.storage_gb == 512][0]
    rows, _ = build_offers(g512)
    na = [r for r in rows if not r["available"]]
    assert [r["seller"] for r in na] == ["Amazon India", "Flipkart"] and all(r["kind"] == "search" and r["price"] is None for r in na)
    assert "amazon.in/s?k=" in na[0]["url"]


def test_price_stats_exact_and_single_offer_not_comparable():
    g = dedupe_products(normalize_products(RAWS, "f", "live")[0])
    rows, _ = build_offers([x for x in g if x.storage_gb == 256][0])
    st = offer_stats(rows)
    assert (st["lowest"], st["highest"], st["average"], st["count"], st["comparable"]) == (148500, 152500, 150300.0, 3, True)
    rows, _ = build_offers([x for x in g if x.storage_gb == 512][0])
    assert offer_stats(rows)["comparable"] is False and offer_stats(rows)["count"] == 1


def test_insight_only_states_supported_facts():
    view = {"source_type": "live", "offers": [{"available": True, "price": 100, "seller": "A"}, {"available": True, "price": 150, "seller": "B"}]}
    ins = price_insight(view, [])
    assert "lowest price among the 2 offers" in ins["text"] and "₹50 more" in " ".join(ins["facts"])
    assert any("not enough historical data" in f for f in ins["facts"])
    hist = [{"date": "2026-01-01", "price": 90.0, "seller": "A"}, {"date": "2026-01-05", "price": 140.0, "seller": "A"}]
    f = " ".join(price_insight(view, hist)["facts"])
    assert "₹10 above the lowest price this app has recorded" in f and "not enough historical" not in f
    demo = price_insight({**view, "source_type": "demo"}, hist)
    assert "Sample data" in demo["facts"][0] and "recorded" not in " ".join(demo["facts"][1:])


# ------------------------------------------------------------------ API service
def test_search_live_groups_variants_records_history_and_non_live_never_does():
    app = make_app(live=True)
    r = app.search({"query": "iPhone 17 Pro Max"})
    assert r["mode"] == "live" and len(r["products"]) == 2 and r["offer_count"] == 4
    top = r["products"][0]
    assert top["variant"]["storage_gb"] == 256 and top["stats"]["lowest"] == 148500 and top["stats"]["comparable"]
    assert top["match"]["level"] == "exact" and top["title"] == top["name"] and "256 GB" in top["variant_label"]
    assert len(app.db.history(top["key"])) == 3
    app.search({"query": "iPhone 17 Pro Max"})
    assert len(app.db.history(top["key"])) == 6  # each explicit fresh search is a timestamped observation
    other = make_app(live=False)  # fixture catalogue with a non-live source type: must never be stored as history
    d = other.search({"query": "Aurora A7 5G"})
    assert all(other.db.history(p["key"]) == [] for p in d["products"])
    h = other.history(d["products"][0]["key"])
    assert h["available"] is False and h["message"] == "Price history starts when tracking begins."


def test_endpoints_product_offers_history_shapes():
    app = make_app(live=True)
    r = app.search({"query": "iPhone 17 Pro Max"})
    pid = r["products"][0]["key"]
    assert app.product(pid)["product"]["title"].startswith("Apple iPhone 17 Pro Max")
    o = app.offers(pid)
    assert [x["seller"] for x in o["offers"]] == ["Flipkart", "Amazon India", "Croma"] and o["stats"]["lowest"] == 148500
    assert all(x["last_checked"] for x in o["offers"])
    h = app.history(pid)
    assert h["available"] and len(h["observations"]) == 3 and h["observations"][0]["observed_at"]
    for bad in ("zzz", "../x", ""):
        try:
            app.offers(bad); assert False
        except ApiError as e:
            assert e.status == 400
    try:
        app.product("aaaaaaaaaaaa"); assert False
    except ApiError as e:
        assert e.status == 404


def test_no_provider_configured_gives_clear_setup_error():
    s = Settings()
    app = AppService(s, Database(os.path.join(tempfile.mkdtemp(), "n.db")))
    assert app.assistant.search.providers == []
    for params in ({"query": "iPhone 16 128GB"}, {"url": "https://www.flipkart.com/a-b/p/itm1"}):
        try:
            app.search(params); assert False
        except ApiError as e:
            assert e.status == 503 and "SERPAPI_KEY" in e.message and e.extra["code"] == "no_provider"
    assert app.health()["serpapi_configured"] is False


def test_provider_failures_become_honest_http_errors():
    class Quota(ProviderBase):
        name, source_type = "SerpApi", "live"
        def __init__(self, msg): self.msg = msg
        def search(self, c, limit=40): raise ProviderError(self.msg)
    for msg, status in (("SerpApi: search quota reached for this account.", 429), ("SerpApi: request timed out.", 504),
                        ("SerpApi: access denied - check SERPAPI_KEY.", 401), ("SerpApi: unexpected HTTP status 500.", 502)):
        app = make_app(live=True)
        app.assistant.search = ProductSearchService(Settings(), [Quota(msg)], FileCache(Path(tempfile.mkdtemp()), 60, False))
        try:
            app.search({"query": "phone"}); assert False
        except ApiError as e:
            assert e.status == status and msg.split(": ", 1)[1].rstrip(".") in e.message


def test_empty_result_is_not_an_error():
    r = make_app(live=True).search({"query": "zzzz qqqq 99"})
    assert r["products"] == [] and r["suggestions"] is not None


def test_possible_match_and_variant_labels():
    app = make_app(live=True)
    prods = app.search({"query": "iPhone 17 Pro Max 256GB"})["products"]
    assert [p["variant"]["storage_gb"] for p in prods] == [256]  # 512GB is a different variant: excluded
    prods = app.search({"query": "iPhone 17 Pro"})["products"]
    assert prods and all(p["match"]["level"] in ("related", "possible") for p in prods)  # Pro Max is NOT claimed identical to Pro


def test_search_validation_errors():
    app = make_app(live=True)
    for params, needle in (({}, "Enter a product name"), ({"query": "x" * 300}, "too long"), ({"query": "phone", "budget": "99999999999"}, "typo"),
                           ({"query": "phone", "budget": "abc"}, "rupees")):
        try:
            app.search(params); assert False, params
        except ApiError as e:
            assert needle in e.message and e.status == 400


def test_url_intake_parsing():
    info = intake_url("https://www.amazon.in/Apple-iPhone-17-Pro-Max-256GB/dp/B0FXXXXXXXX/ref=sr_1_1")
    assert info["retailer"] == "amazon_in" and info["title_guess"] == "Apple iPhone 17 Pro Max 256GB" and info["recognised"]
    assert intake_url("javascript:alert(1)")["valid"] is False and intake_url("")["valid"] is False
    assert intake_url("https://www.flipkart.com/apple-iphone-15-128-gb-blue/p/itm6ac6485515ae4")["retailer"] == "flipkart"
    assert intake_url("https://shop.example.org/a-b-c")["recognised"] is False


def test_url_flow_uses_page_metadata_and_refuses_honestly_when_unreadable():
    from src.url_extractor import UrlReadError

    def good(url):
        return {"url": url, "title": "Apple iPhone 17 Pro Max 256GB Cosmic Orange", "brand": "Apple", "variant": "256 GB, Cosmic Orange", "price": 150000.0,
                "currency": "INR", "image_url": None, "source": "json-ld", "retailer": "amazon_in", "retailer_name": "Amazon India", "recognised": True}

    def blocked(url):
        raise UrlReadError("The website refused automated access to this page (it may require a browser or login). It was not bypassed.", "Apple iPhone 17 Pro Max 256GB")
    app = make_app(live=True, url_reader=good)
    r = app.search({"url": "https://www.amazon.in/dp/FIX1"})
    assert r["url"]["title"].startswith("Apple iPhone 17") and r["url"]["price"] == 150000.0 and len(r["products"]) == 1
    assert "uses only prices from the data provider" in " ".join(r["url"]["notes"])
    app = make_app(live=True, url_reader=blocked)
    try:
        app.search({"url": "https://www.amazon.in/dp/FIX1"}); assert False
    except ApiError as e:
        assert e.status == 422 and "enter the product name" in e.message and e.extra["suggested_query"] == "Apple iPhone 17 Pro Max 256GB"
    try:  # an invalid URL never reaches the network: the real reader rejects it
        make_app(live=True).search({"url": "javascript:alert(1)"}); assert False
    except ApiError as e:
        assert e.status == 422 and "valid product link" in e.message


def test_alert_flow_triggers_on_new_live_price():
    app = make_app(live=True)
    key = app.search({"query": "iPhone 17 Pro Max"})["products"][0]["key"]
    a = app.create_alert({"key": key, "target_price": 140000})
    assert not a["already_met"]
    FixtureLive.prices = [139000, 138500, 152500, 170500]
    try:
        r = app.search({"query": "iPhone 17 Pro Max"})
    finally:
        FixtureLive.prices = None
    assert [t["target"] for t in r["alerts_triggered"]] == [140000.0] and r["alerts_triggered"][0]["price"] == 138500
    assert app.alerts()[0]["active"] == 0
    for bad in ({"key": key, "target_price": "abc"}, {"key": key, "target_price": 5}, {"key": "nope", "target_price": 5000}):
        try:
            app.create_alert(bad); assert False
        except ApiError:
            pass
    assert AppService(Settings(), Database(os.path.join(tempfile.mkdtemp(), "z.db"))).check_alerts()["checked"] == 0  # no provider: nothing checked


def test_trending_and_recent_use_real_searches_only():
    app = make_app(live=True)
    assert app.trending()["items"] == [] and app.db.recent() == []  # nothing invented
    app.search({"query": "iPhone 17 Pro Max"}); app.search({"query": "iPhone 17 Pro Max"})
    t = app.trending()
    assert t["items"][0]["count"] == 2 and app.db.recent()[0]["name"].startswith("Apple iPhone 17 Pro Max") and t["sample"] is False


# ------------------------------------------------------------------ RAG
def test_retrieval_prefers_relevant_chunk_types():
    app = make_app(live=True)
    r = app.search({"query": "iPhone 17 Pro Max"})
    views = r["products"][:1]
    chunks = rag.build_chunks(views, {views[0]["key"]: {"lowest": 1, "highest": 2, "average": 1.5, "points": 3, "first": "a", "last": "b"}})
    kinds = lambda q: {c["type"] for c in rag.retrieve(q, chunks, k=3)}
    assert "offer" in kinds("which seller is cheapest")
    assert "history" in kinds("what is the price history trend")
    assert "meta" in kinds("anything")  # product meta always present so answers name the product


def test_chat_without_ai_returns_sourced_facts_only():
    app = make_app(live=True)
    key = app.search({"query": "iPhone 17 Pro Max"})["products"][0]["key"]
    r = app.chat({"message": "which seller is cheapest?", "keys": [key]})
    assert r["mode"] == "facts" and "₹1,48,500" in r["answer"] and "[S" in r["answer"] and "No AI model is configured" in r["note"]
    assert r["sources"] and all(s["id"].startswith("S") for s in r["sources"])


def test_chat_accepts_grounded_ai_answer_and_rejects_bad_ones():
    base = make_app(live=True)
    key = base.search({"q": "iPhone 17 Pro Max"})["products"][0]["key"]
    cases = {
        "ok": ("Flipkart is cheapest at ₹1,48,500 [S2]. My take: good deal.", "ai"),
        "invented_price": ("Flipkart is cheapest at ₹99,999 [S2].", "facts"),
        "no_citation": ("Flipkart is cheapest at ₹1,48,500.", "facts"),
        "bad_citation": ("Flipkart is cheapest [S99].", "facts"),
    }
    for name, (reply, mode) in cases.items():
        app = make_app(live=True, llm=GoodLLM(reply)); app.db = base.db
        r = app.chat({"message": "which seller is cheapest?", "keys": [key]})
        assert r["mode"] == mode, name
        if mode == "facts":
            assert "discarded" in r["note"]
    down = make_app(live=True, llm=DownLLM("")); down.db = base.db
    r = down.chat({"message": "cheapest?", "keys": [key]})
    assert r["mode"] == "facts" and "timed out" in r["note"]


def test_compare_is_deterministic_table_plus_grounded_answer():
    app = make_app(live=True)
    prods = app.search({"query": "iPhone 17 Pro Max"})["products"]
    keys = [p["key"] for p in prods]
    c = app.compare({"keys": keys, "question": "Is the 512GB worth paying more?"})
    assert c["table"]["columns"][0].startswith("Apple iPhone 17 Pro Max") and c["mode"] == "facts"
    assert any("₹22,000 cheaper" in f or "cheaper than" in f for f in c["facts"])
    assert c["table"]["rows"][0][0] == "Lowest verified price"
    for bad in ([keys[0]], [], "x"):
        try:
            app.compare({"keys": bad}); assert False
        except ApiError:
            pass
    try:
        app.chat({"message": "hi", "keys": ["aaaaaaaaaaaa"]}); assert False
    except ApiError as e:
        assert "Search for a product first" in e.message


# ------------------------------------------------------------------ providers: Flipkart fixture
FK = {"products": [{"productBaseInfoV1": {"productId": "MOB1", "title": "Acme Phone 5G", "productBrand": "Acme",
      "flipkartSellingPrice": {"amount": 20000, "currency": "INR"}, "flipkartSpecialPrice": {"amount": 18999, "currency": "INR"},
      "maximumRetailPrice": {"amount": 24999}, "productUrl": "https://www.flipkart.com/acme-phone/p/itmx", "inStock": True,
      "imageUrls": {"200x200": "https://rukminim.example.com/a.jpg"}}}, {"junk": 1}]}


def test_flipkart_fixture_parsing_and_missing_credentials():
    products, rejected = normalize_products(parse_flipkart(FK), "Flipkart Affiliate API", "live")
    p = products[0]
    assert (p.price, p.original_price, p.seller, p.retailer, p.availability) == (18999, 24999, "Flipkart", "flipkart", "in_stock")
    assert parse_flipkart({}) == []
    prov = FlipkartAffiliateProvider(Settings())
    assert not prov.is_available()
    try:
        prov.search(__import__("src.models", fromlist=["x"]).SearchCriteria(query="x")); assert False
    except ProviderError as e:
        assert "not set" in str(e)


# ------------------------------------------------------------------ HTTP server
def http(port, path, data=None, method=None):
    req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=json.dumps(data).encode() if data is not None else None,
                                 method=method, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, r.read(), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read(), dict(e.headers)


def test_http_api_static_and_error_handling():
    app = make_app(live=True)
    srv = create_server(app, "127.0.0.1", 0)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    port = srv.server_address[1]
    try:
        st, body, hdr = http(port, "/")
        assert st == 200 and b"DecisionAI" in body and b"Make the Smarter Choice" in body and "script-src 'self'" in hdr["Content-Security-Policy"]
        assert http(port, "/app.js")[0] == 200 and http(port, "/app.css")[0] == 200
        assert http(port, "/../server.py")[0] == 404 and http(port, "/%2e%2e/.env")[0] == 404
        h = json.loads(http(port, "/api/health")[1])
        assert h["ok"] and h["database"] and "serpapi_configured" in h and "key" not in json.dumps(h).lower().replace("serpapi_configured", "")
        st, body, _ = http(port, "/api/search", {"query": "iPhone 17 Pro Max"})
        d = json.loads(body)
        assert st == 200 and len(d["products"]) == 2 and d["products"][0]["offers"][0]["seller"] == "Flipkart"
        st, body, _ = http(port, "/api/search", {"query": "phone", "budget": "99999999999"})
        assert st == 400 and "typo" in json.loads(body)["error"]
        assert http(port, "/api/search", {})[0] == 400 and http(port, "/api/nope")[0] == 404 and http(port, "/api/search")[0] == 404
        key = d["products"][0]["key"]
        assert json.loads(http(port, f"/api/products/{key}")[1])["product"]["id"] == key
        assert len(json.loads(http(port, f"/api/products/{key}/offers")[1])["offers"]) == 3
        hist = json.loads(http(port, f"/api/products/{key}/history")[1])
        assert hist["available"] and hist["observations"]
        assert http(port, "/api/products/nope/offers")[0] == 400 and http(port, "/api/products/aaaaaaaaaaaa/history")[0] == 200
        st, body, _ = http(port, "/api/chat", {"message": "cheapest seller?", "keys": [key]})
        assert st == 200 and json.loads(body)["mode"] == "facts"
        req = urllib.request.Request(f"http://127.0.0.1:{port}/api/chat", data=b"{not json", method="POST")
        try:
            urllib.request.urlopen(req, timeout=5); assert False
        except urllib.error.HTTPError as e:
            assert e.code == 400
        st, body, _ = http(port, "/api/alerts", {"key": key, "target_price": 140000})
        aid = json.loads(body)["id"]
        assert http(port, "/api/alerts")[0] == 200 and json.loads(http(port, f"/api/alerts/{aid}", method="DELETE")[1])["deleted"]
    finally:
        srv.shutdown()


def test_setup_error_reaches_the_browser_as_json_with_code():
    app = AppService(Settings(), Database(os.path.join(tempfile.mkdtemp(), "n.db")))
    srv = create_server(app, "127.0.0.1", 0)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        st, body, _ = http(srv.server_address[1], "/api/search", {"query": "iPhone 16 128GB"})
        d = json.loads(body)
        assert st == 503 and d["code"] == "no_provider" and "SERPAPI_KEY" in d["error"]
    finally:
        srv.shutdown()


def test_server_errors_do_not_leak_internals():
    app = make_app(live=True)
    app.search = lambda p: (_ for _ in ()).throw(RuntimeError("secret-token-xyz /home/user/path"))
    srv = create_server(app, "127.0.0.1", 0)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        st, body, _ = http(srv.server_address[1], "/api/search", {"query": "phone"})
        assert st == 500 and b"secret-token-xyz" not in body and b"/home/user" not in body
    finally:
        srv.shutdown()
