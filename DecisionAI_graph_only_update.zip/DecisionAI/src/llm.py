"""Optional LLM layer (OpenAI-compatible chat-completions). Every output is validated before use."""
from __future__ import annotations

import json
import re
from typing import Dict, List, Optional

import requests

from src.config import Settings
from src.models import RecommendationResult, SearchCriteria
from src.utils.validation import clean_str_list, to_float

LABELS = ("Best Overall", "Lowest Price", "Best Value")


class LLMError(Exception):
    pass


def extract_json(text: str) -> Optional[dict]:
    if not isinstance(text, str):
        return None
    t = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    try:
        obj = json.loads(t)
    except ValueError:
        m = re.search(r"\{.*\}", t, re.S)
        if not m:
            return None
        try:
            obj = json.loads(m.group(0))
        except ValueError:
            return None
    return obj if isinstance(obj, dict) else None


def validate_criteria_payload(obj: Optional[dict], original_query: str, allowed_categories: List[str]) -> Optional[SearchCriteria]:
    """Turn AI JSON into SearchCriteria; None if it is unusable. Unknown/invalid fields are dropped."""
    if not isinstance(obj, dict):
        return None
    c = SearchCriteria(query=original_query)
    cat = obj.get("category")
    if isinstance(cat, str) and cat.strip().lower() in allowed_categories:
        c.category = cat.strip().lower()
    budget = to_float(obj.get("max_budget"))
    if budget and 0 < budget < 1e9:
        c.max_budget = budget
    c.brands = clean_str_list(obj.get("brands"))[:10]
    use = obj.get("use_case")
    c.use_case = use.strip().lower() if isinstance(use, str) and use.strip() else None
    c.features = [f.lower() for f in clean_str_list(obj.get("features"))][:10]
    pri = [p.lower() for p in clean_str_list(obj.get("priorities"))]
    c.priorities = [p for p in pri if p in ("lowest price", "performance", "durability", "warranty", "ratings")]
    c.keywords = [k.lower() for k in clean_str_list(obj.get("keywords"))][:10]
    if not (c.category or c.keywords or c.brands):
        return None
    return c


def explanation_is_grounded(text: str, allowed_prices: List[float]) -> bool:
    """Reject explanations that quote a rupee amount not present in the data we supplied."""
    for m in re.finditer(r"₹\s?([\d,]+(?:\.\d+)?)", text):
        val = float(m.group(1).replace(",", ""))
        if not any(abs(val - p) <= 1 for p in allowed_prices):
            return False
    return True


def validate_explanation_payload(obj: Optional[dict], allowed_prices: List[float]) -> Optional[Dict[str, str]]:
    if not isinstance(obj, dict):
        return None
    out = {}
    summary = obj.get("summary")
    if isinstance(summary, str) and summary.strip():
        out["summary"] = summary.strip()[:1200]
    per = obj.get("per_label")
    if isinstance(per, dict):
        for k, v in per.items():
            if k in LABELS and isinstance(v, str) and v.strip():
                out[k] = v.strip()[:600]
    if not out or not all(explanation_is_grounded(v, allowed_prices) for v in out.values()):
        return None
    return out


class LLMClient:
    def __init__(self, settings: Settings):
        self.s = settings

    @property
    def available(self) -> bool:
        return self.s.ai_enabled

    def _chat(self, system: str, user: str) -> str:
        if not self.available:
            raise LLMError("AI is not configured.")
        try:
            r = requests.post(
                f"{self.s.llm_base_url}/chat/completions",
                headers={"Authorization": f"Bearer {self.s.llm_api_key}", "Content-Type": "application/json"},
                json={"model": self.s.llm_model, "temperature": 0.2,
                      "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}]},
                timeout=self.s.llm_timeout)
        except requests.Timeout:
            raise LLMError("The AI request timed out.")
        except requests.RequestException as exc:
            raise LLMError(self.s.redact(f"AI network error ({type(exc).__name__})."))
        if r.status_code == 429:
            raise LLMError("The AI provider rate limit was reached.")
        if r.status_code in (401, 403):
            raise LLMError("The AI provider rejected the API key.")
        if r.status_code != 200:
            raise LLMError(f"The AI provider returned HTTP {r.status_code}.")
        try:
            return r.json()["choices"][0]["message"]["content"]
        except (ValueError, KeyError, IndexError, TypeError):
            raise LLMError("The AI response had an unexpected format.")

    def ask(self, system: str, user: str) -> str:
        """Free-text completion (callers must validate the output before showing it)."""
        return self._chat(system, user)

    def parse_criteria(self, query: str, allowed_categories: List[str]) -> Optional[SearchCriteria]:
        system = ("You convert shopping requests into JSON. Reply with ONLY a JSON object with keys: "
                  "category (one of %s or null), max_budget (number in INR or null), brands (list), use_case (string or null), "
                  "features (list of short strings like '16gb ram','5g'), priorities (subset of: lowest price, performance, durability, warranty, ratings), "
                  "keywords (list of product words). Never invent values the user did not state." % allowed_categories)
        return validate_criteria_payload(extract_json(self._chat(system, query)), query, allowed_categories)

    def explain(self, result: RecommendationResult, criteria: SearchCriteria) -> Optional[Dict[str, str]]:
        facts = []
        for r in result.recommendations:
            p = r.scored.product
            facts.append({"label": r.label, "name": p.name, "seller": p.seller, "price_inr": p.price,
                          "rating": p.rating, "review_count": p.review_count, "specs": p.specs,
                          "pros": r.scored.pros, "cons": r.scored.cons, "score_0_100": round(r.scored.total * 100)})
        system = ("You explain shopping recommendations in simple, friendly language. Use ONLY the facts provided; never add specs, "
                  "prices, ratings, discounts or claims that are not in the facts. Do not say a price is the lowest on the internet. "
                  "Mention trade-offs. Reply with ONLY JSON: {\"summary\": str, \"per_label\": {\"Best Overall\": str, \"Lowest Price\": str, \"Best Value\": str}}.")
        user = json.dumps({"user_request": criteria.query, "budget_inr": criteria.max_budget, "recommendations": facts}, ensure_ascii=False)
        prices = [r.scored.product.price for r in result.recommendations]
        if criteria.max_budget:
            prices.append(criteria.max_budget)
        prices += [d["price_inr"] - e for d in facts for e in (0,)]
        for r in result.recommendations:  # also allow the price gaps we computed deterministically
            for r2 in result.recommendations:
                prices.append(abs(r.scored.product.price - r2.scored.product.price))
        return validate_explanation_payload(extract_json(self._chat(system, user)), prices)
