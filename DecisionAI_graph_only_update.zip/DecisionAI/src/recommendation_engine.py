"""Transparent, deterministic ranking. The LLM never computes scores; Python does."""
from __future__ import annotations

import re
import statistics
from typing import Dict, List, Optional, Tuple

from src.config import DEFAULT_WEIGHTS, PRIORITY_BOOSTS
from src.models import Product, Recommendation, RecommendationResult, ScoredProduct, SearchCriteria
from src.utils.formatting import format_price

RATING_PRIOR, RATING_PRIOR_WEIGHT = 3.5, 50  # Bayesian shrinkage: few reviews -> pulled towards 3.5
MIN_FEATURE_MATCH = 0.5       # with required features, products matching fewer are not "qualifying"
MIN_QUALITY_FOR_VALUE = 0.40  # a cheap but poor-quality product must not win "Best Value"
LOWER_IS_BETTER = {"weight_kg", "weight_g", "latency_ms", "response_time_ms", "price"}
COMPONENTS = ["budget_fit", "feature_match", "price", "rating", "spec_strength", "use_case", "warranty"]


def effective_weights(base: Optional[Dict[str, float]], priorities: List[str]) -> Dict[str, float]:
    w = dict(DEFAULT_WEIGHTS if base is None else base)
    for pr in priorities:
        for k, add in PRIORITY_BOOSTS.get(pr.lower(), {}).items():
            w[k] = w.get(k, 0.0) + add
    w = {k: max(float(v), 0.0) for k, v in w.items() if k in COMPONENTS}
    total = sum(w.values())
    return {k: v / total for k, v in w.items()} if total > 0 else {k: 1 / len(COMPONENTS) for k in COMPONENTS}


def _compact(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


def feature_hit(product: Product, feature: str) -> bool:
    """Does the product text/specs mention the feature? ('16gb ram' matches spec ram_gb=16)."""
    f = feature.lower().strip()
    if not f:
        return True
    parts = [product.name, product.brand, product.model, *product.features, *product.use_cases]
    for k, v in product.specs.items():
        parts += [f"{k} {v}", f"{v} {k}", f"{v}{k.split('_')[-1] if '_' in k else ''}"]
        if isinstance(v, (int, float)) and "_" in k:  # ram_gb=16 -> "16gb", "16gb ram"
            unit = k.split("_")[-1]
            parts += [f"{int(v) if float(v).is_integer() else v}{unit} {k.split('_')[0]}", f"{int(v) if float(v).is_integer() else v}{unit}"]
            if unit == "gb" and v >= 1000 and float(v) % 1000 == 0:
                parts.append(f"{int(v // 1000)}tb")
    hay = " ".join(str(p).lower() for p in parts)
    compact_hay = _compact(hay)
    if _compact(f) in compact_hay:
        return True
    m = re.fullmatch(r"(\d+)\s?(gb|tb)(?:\s?ram)?", f)
    if m and f.endswith("ram"):
        return f"{m.group(1)}{m.group(2)}ram" in compact_hay or f"ram{m.group(1)}" in compact_hay
    toks = [t for t in re.findall(r"[a-z0-9]+", f) if t]
    return bool(toks) and all(t in re.findall(r"[a-z0-9]+", hay) for t in toks)


def bayesian_rating(rating: float, reviews: Optional[int]) -> float:
    n = reviews or 0
    return (rating * n + RATING_PRIOR * RATING_PRIOR_WEIGHT) / (n + RATING_PRIOR_WEIGHT)


def _spec_strength(products: List[Product]) -> Dict[int, Optional[float]]:
    """Average min-max position of each product's numeric specs vs. the other candidates (0 weakest, 1 strongest).
    Only specs present as numbers on >=3 candidates count; lower-is-better specs (e.g. weight) are inverted."""
    keys = {}
    for p in products:
        for k, v in p.specs.items():
            if isinstance(v, (int, float)):
                keys.setdefault(k, []).append(v)
    usable = {k: (min(v), max(v)) for k, v in keys.items() if len(v) >= 3 and max(v) > min(v)}
    out: Dict[int, Optional[float]] = {}
    for i, p in enumerate(products):
        parts = []
        for k, (lo, hi) in usable.items():
            v = p.specs.get(k)
            if isinstance(v, (int, float)):
                x = (v - lo) / (hi - lo)
                parts.append(1 - x if k in LOWER_IS_BETTER else x)
        out[i] = sum(parts) / len(parts) if parts else None
    return out


def _score_components(products: List[Product], c: SearchCriteria) -> Dict[str, Dict[str, Optional[float]]]:
    prices = [p.price for p in products]
    lo, hi = min(prices), max(prices)
    comp: Dict[str, Dict[str, Optional[float]]] = {}
    strength = _spec_strength(products)
    for i, p in enumerate(products):
        d: Dict[str, Optional[float]] = {}
        if c.max_budget:
            d["budget_fit"] = 1.0 if p.price <= c.max_budget else max(0.0, 1 - (p.price - c.max_budget) / c.max_budget)
        else:
            d["budget_fit"] = None
        feats = c.features
        d["feature_match"] = (sum(feature_hit(p, f) for f in feats) / len(feats)) if feats else None
        d["price"] = 1.0 if hi == lo else 1 - (p.price - lo) / (hi - lo)
        d["rating"] = min(max((bayesian_rating(p.rating, p.review_count) - 3.0) / 2.0, 0.0), 1.0) if p.rating is not None else None  # 3★->0, 5★->1
        d["spec_strength"] = strength[i]
        d["use_case"] = (1.0 if c.use_case and c.use_case.lower() in p.use_cases else 0.0) if c.use_case else None
        d["warranty"] = min(p.warranty_months / 24.0, 1.0) if p.warranty_months is not None else None
        comp[p.id + "|" + p.seller] = d
    return comp


def _combine(d: Dict[str, Optional[float]], w: Dict[str, float], active: set, skip: set = frozenset()) -> float:
    """Weighted mean over active components. A component missing for THIS product but present for others
    counts as a neutral 0.5 so missing data neither rewards nor hides a product."""
    num = den = 0.0
    for k in active:
        if k in skip:
            continue
        v = d.get(k)
        num += w.get(k, 0) * (0.5 if v is None else v)
        den += w.get(k, 0)
    return num / den if den else 0.0


def _numeric_spec_notes(p: Product, pool: List[Product]) -> Tuple[List[str], List[str]]:
    pros, cons = [], []
    for k, v in p.specs.items():
        if not isinstance(v, (int, float)):
            continue
        vals = [q.specs[k] for q in pool if isinstance(q.specs.get(k), (int, float))]
        if len(vals) < 3 or max(vals) == min(vals):
            continue
        label = k.replace("_", " ")
        best = min(vals) if k in LOWER_IS_BETTER else max(vals)
        worst = max(vals) if k in LOWER_IS_BETTER else min(vals)
        if v == best:
            pros.append(f"Best {label} among compared options ({v:g})")
        elif v == worst:
            cons.append(f"Lowest-ranked {label} among compared options ({v:g})")
    return pros[:3], cons[:2]


def _pros_cons(sp: ScoredProduct, pool: List[Product], c: SearchCriteria, median_price: float) -> None:
    p = sp.product
    pros, cons = _numeric_spec_notes(p, pool)
    if len(pool) > 1:
        if p.price == min(q.price for q in pool):
            pros.insert(0, "Lowest price among the compared offers")
        elif p.price <= median_price * 0.85:
            pros.append(f"Priced {(1 - p.price / median_price) * 100:.0f}% below the median of compared offers")
        if p.price == max(q.price for q in pool):
            cons.insert(0, "Highest price among the compared offers")
        elif p.price >= median_price * 1.15:
            cons.append(f"Priced {(p.price / median_price - 1) * 100:.0f}% above the median of compared offers")
    if sp.matched_features:
        pros.append("Matches: " + ", ".join(sp.matched_features))
    if sp.missing_features:
        cons.append("No evidence of: " + ", ".join(sp.missing_features))
    if p.rating is not None:
        if (p.review_count or 0) >= 500 and p.rating >= 4.2:
            pros.append(f"Well rated ({p.rating:.1f}★ from {p.review_count:,} reviews)")
        elif (p.review_count or 0) < 50:
            cons.append(f"Few reviews ({p.review_count or 0}), so the {p.rating:.1f}★ rating is less reliable")
        elif p.rating < 3.8:
            cons.append(f"Modest rating ({p.rating:.1f}★)")
    else:
        cons.append("No rating data available")
    if p.warranty_months and p.warranty_months >= 24:
        pros.append(f"{p.warranty_months}-month warranty listed")
    if c.use_case and c.use_case.lower() in p.use_cases:
        pros.append(f"Suited to {c.use_case}")
    elif c.use_case:
        cons.append(f"Not listed as suited to {c.use_case}")
    sp.pros, sp.cons = pros[:5], cons[:4]


def _score_all(products: List[Product], c: SearchCriteria, w: Dict[str, float]) -> List[ScoredProduct]:
    comps = _score_components(products, c)
    active = {k for k in COMPONENTS if any(comps[key][k] is not None for key in comps)}
    median_price = statistics.median(p.price for p in products)
    scored: List[ScoredProduct] = []
    for p in products:
        d = comps[p.id + "|" + p.seller]
        total = _combine(d, w, active)
        quality = _combine(d, w, active, skip={"price", "budget_fit"})
        value = quality / (p.price / median_price) if median_price else 0.0
        matched = [f for f in c.features if feature_hit(p, f)]
        missing = [f for f in c.features if f not in matched]
        fm = d["feature_match"]
        sp = ScoredProduct(p, total, d, quality, value, matched, missing,
                           qualifies=(fm is None or fm >= MIN_FEATURE_MATCH))
        _pros_cons(sp, products, c, median_price)
        scored.append(sp)
    return scored


def rank_products(products: List[Product], c: SearchCriteria,
                  weights: Optional[Dict[str, float]] = None) -> RecommendationResult:
    w = effective_weights(weights, c.priorities)
    if not products:
        return RecommendationResult([], [], ["No products matched your search and filters."], w, False)

    scored = _score_all(products, c, w)

    # Deterministic tie handling: score, then lower price, then higher rating, then name.
    key = lambda s: (-round(s.total, 6), s.product.price, -(s.product.rating or 0), s.product.name, s.product.seller)
    scored.sort(key=key)

    notes: List[str] = []
    if c.use_case and any(c.use_case.lower() in s.product.use_cases for s in scored):
        for s in scored:  # "suitable" also means listed for the intended use, when any product is
            if c.use_case.lower() not in s.product.use_cases:
                s.qualifies = False
    qualifying = [s for s in scored if s.qualifies]
    if 0 < len(qualifying) < len(scored):  # score suitable products against each other, list the rest after them
        excluded = [s for s in scored if not s.qualifies]
        rescored = _score_all([s.product for s in qualifying], c, w)
        for s in rescored:
            s.qualifies = True
        rescored.sort(key=key)
        scored = rescored + sorted(excluded, key=key)
        qualifying = rescored
    if c.features and not qualifying:
        notes.append("No product clearly matches all of your required features; showing the closest matches instead.")
        qualifying = scored
    elif c.features and len(qualifying) < len(scored):
        notes.append(f"{len(scored) - len(qualifying)} product(s) did not meet your requirements (features/intended use) and were excluded from the three picks.")

    median_price = statistics.median(s.product.price for s in qualifying)
    recs: List[Recommendation] = []
    best = qualifying[0]
    recs.append(Recommendation("Best Overall", best, _reason_overall(best, c)))
    cheapest = sorted(qualifying, key=lambda s: (s.product.price, -s.total, s.product.name))[0]
    recs.append(Recommendation("Lowest Price", cheapest, _reason_cheapest(cheapest, best, c)))
    value_pool = [s for s in qualifying if s.quality >= MIN_QUALITY_FOR_VALUE]
    if value_pool:
        val = sorted(value_pool, key=lambda s: (-round(s.value_index, 6), s.product.price, s.product.name))[0]
        recs.append(Recommendation("Best Value", val, _reason_value(val, best, cheapest, median_price)))
    else:
        notes.append("No option reached the minimum quality needed to be called 'Best Value'.")

    sufficient = len(qualifying) >= 3
    if len(qualifying) == 1:
        notes.append("Only one qualifying product was found, so there is nothing to compare it against. Treat this as a single data point.")
    elif len(qualifying) == 2:
        notes.append("Only two qualifying products were found; the comparison is limited.")
    notes.append("'Lowest price' refers only to the sources searched, not the entire internet.")
    if not any(p.rating is not None for p in products):
        notes.append("No ratings were available, so ratings did not influence the ranking.")
    return RecommendationResult(recs, scored, notes, w, sufficient)


def _reason_overall(s: ScoredProduct, c: SearchCriteria) -> str:
    bits = [f"Highest combined score ({s.total * 100:.0f}/100) across your criteria"]
    if s.matched_features:
        bits.append("matches " + ", ".join(s.matched_features))
    if c.use_case and c.use_case.lower() in s.product.use_cases:
        bits.append(f"is listed as suited to {c.use_case}")
    if c.max_budget:
        bits.append(f"fits your {format_price(c.max_budget)} budget")
    return "; ".join(bits) + "."


def _reason_cheapest(s: ScoredProduct, best: ScoredProduct, c: SearchCriteria) -> str:
    if s is best:
        return "It is both the cheapest qualifying offer and the best overall match, so there is no trade-off."
    diff = best.product.price - s.product.price
    return (f"Cheapest qualifying offer, {format_price(diff, s.product.currency)} less than the Best Overall pick. "
            f"Trade-off: its overall score is {(best.total - s.total) * 100:.0f} points lower.")


def _reason_value(s: ScoredProduct, best: ScoredProduct, cheapest: ScoredProduct, median: float) -> str:
    if s is best:
        return "Gives the most quality per rupee among qualifying options, and is also the Best Overall match."
    return (f"Best balance of quality to price (quality {s.quality * 100:.0f}/100 at {format_price(s.product.price, s.product.currency)}, "
            f"median of compared options is {format_price(median, s.product.currency)}).")
