from src.data_validation import normalize_product
from src.identity import canonical_retailer, identity_key, parse_title
from src.matching import filter_relevant, parse_intent, split_compare, suggestions
from src.models import SearchCriteria
from src.product_search import dedupe_products, parse_budget, validate_budget


def mk(title, price, seller="Seller", **kw):
    return normalize_product({"name": title, "price": price, "seller": seller, **kw}, "fixture", "live")


def test_title_parsing_extracts_structured_attributes():
    i = parse_title("Apple iPhone 17 Pro Max (256 GB) - Cosmic Orange")
    assert (i.brand, i.model_key, i.storage_gb, i.color) == ("Apple", "iphone 17 pro max", 256, "cosmic orange")
    i = parse_title("Samsung Galaxy S24 Ultra 5G (Titanium Gray, 12GB, 256GB Storage)")
    assert i.ram_gb == 12 and i.storage_gb == 256 and i.model_key == "galaxy s24 ultra"
    assert parse_title("Crucial P3 1TB NVMe SSD").storage_gb == 1000
    assert parse_title("Apple iPhone 15 128GB Blue Refurbished").condition == "refurbished"


def test_same_product_from_different_titles_groups_together():
    a = mk("Apple iPhone 17 Pro Max (256 GB) - Cosmic Orange", 149900, "Amazon.in")
    b = mk("Apple iPhone 17 Pro Max 256GB Cosmic Orange", 148500, "Flipkart")
    c = mk("iPhone 17 Pro Max 256 GB, Cosmic Orange", 150500, "Croma")
    groups = dedupe_products([a, b, c])
    assert len(groups) == 1 and groups[0].price == 148500 and len(groups[0].other_offers) == 2


def test_different_storage_colour_generation_or_condition_never_merge():
    base = mk("Apple iPhone 17 Pro Max 256GB Orange", 1)
    others = [mk("Apple iPhone 17 Pro Max 512GB Orange", 1), mk("Apple iPhone 17 Pro Max 256GB Blue", 1),
              mk("Apple iPhone 17 Pro 256GB Orange", 1), mk("Apple iPhone 16 Pro Max 256GB Orange", 1),
              mk("Apple iPhone 17 Pro Max 256GB Orange Refurbished", 1)]
    keys = {identity_key(p) for p in [base] + others}
    assert len(keys) == 6
    assert len(dedupe_products([base] + others)) == 6


def test_similar_titles_are_not_merged_on_similarity_alone():
    assert len(dedupe_products([mk("Acme Zed 100", 5), mk("Acme Zed 1000", 6), mk("Acme Zed 100 Pro", 7)])) == 3


def test_retailer_detection():
    assert canonical_retailer("Amazon.in") == ("amazon_in", "Amazon India")
    assert canonical_retailer("Flipkart") == ("flipkart", "Flipkart")
    assert canonical_retailer("Some Shop")[0] == ""
    assert mk("Acme X 1", 5, "AMAZON INDIA").retailer == "amazon_in"


def test_specific_query_returns_only_that_product_not_generic_or_accessories():
    ps = [mk("Apple iPhone 17 Pro Max 256GB", 150000), mk("Apple iPhone 17 Pro 256GB", 130000),
          mk("Samsung Galaxy S24 128GB", 60000), mk("Spigen Case for iPhone 17 Pro Max", 999),
          mk("Tempered Glass Screen Protector iPhone 17 Pro Max", 299), mk("Apple iPhone 17 Pro Max 512GB", 170000)]
    kept, tiers = filter_relevant(ps, parse_intent("iPhone 17 Pro Max"))
    names = [p.name for p in kept]
    assert names == ["Apple iPhone 17 Pro Max 256GB", "Apple iPhone 17 Pro Max 512GB"]
    kept, _ = filter_relevant(ps, parse_intent("iphone 17 pro max 512gb"))
    assert [p.storage_gb for p in kept] == [512]


def test_case_punctuation_and_spelling_variants():
    ps = [mk("Samsung Galaxy S24 Ultra 256GB", 100), mk("Apple iPhone 15 128GB", 50)]
    for q in ["GALAXY S24 ULTRA", "galaxy  s24-ultra", "galexy s24 ultra", "i phone 15", "iphone15"]:
        kept, _ = filter_relevant(ps, parse_intent(q))
        assert len(kept) == 1, q


def test_generic_queries_have_no_model_requirement():
    it = parse_intent("Best phone under ₹30,000")
    assert not it.specific and it.category == "phone" and it.model_tokens == []
    assert parse_intent("1 TB SSD").storage_gb == 1000 and parse_intent("1 TB SSD").category == "ssd"
    assert parse_intent("Best gaming mouse for FPS games").category == "mouse"


def test_compare_query_split():
    assert split_compare("Compare iPhone 15 and Galaxy S24") == ["iPhone 15", "Galaxy S24"]
    assert split_compare("iPhone 15 vs Pixel 8") == ["iPhone 15", "Pixel 8"]
    assert split_compare("best phone under 30000") == []


def test_no_match_gives_suggestions_for_near_miss():
    ps = [mk("Acme Zephyr 9 Pro", 5), mk("Other Thing 1", 6)]
    kept, _ = filter_relevant(ps, parse_intent("acme zephyr 8 pro"))
    assert kept == []
    assert suggestions(parse_intent("acme zephyr 8 pro"), ps)[0] == "Acme Zephyr 9 Pro"


def test_budget_parsing_and_validation():
    assert parse_budget("laptop 60k") == 60000 and parse_budget("under ₹1.5 lakh") == 150000
    assert validate_budget("") == (None, None) and validate_budget(None) == (None, None)
    assert validate_budget("30k") == (30000.0, None)
    assert validate_budget(500000) == (500000.0, None)  # a large but plausible budget is accepted
    for bad in ["99999999999", "0", "-5", "abc", "50"]:
        val, err = validate_budget(bad)
        assert val is None and err, bad


def test_huge_budget_value_does_not_silently_return_nothing():
    from src.assistant import DecisionAssistant
    from src.config import Settings
    from pathlib import Path
    import tempfile
    from src.cache import FileCache
    from src.product_search import ProductSearchService
    from tests.fixture_provider import DemoProvider
    st = Settings()
    a = DecisionAssistant(st, ProductSearchService(st, [DemoProvider()], FileCache(Path(tempfile.mkdtemp()), 1, False)))
    r = a.run("best phone", {"max_budget": 5_000_000.0})
    assert r.outcome.products  # big-but-valid budget keeps every product
