"""Query parsing, budget validation, provider orchestration (concurrent), offer grouping, filtering, sorting."""
from __future__ import annotations

import logging
import re
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from src.cache import FileCache
from src.config import LOCAL_DIR, Settings
from src.identity import BRAND_DISPLAY, identity_key
from src.matching import CATEGORY_OF, Intent, filter_relevant, parse_intent, split_compare, suggestions
from src.models import Product, SearchCriteria
from src.providers.base import ProviderBase, ProviderError
from src.providers.configured_api_provider import ConfiguredApiProvider
from src.providers.flipkart_provider import FlipkartAffiliateProvider
from src.providers.serpapi_provider import SerpApiShoppingProvider
from src.providers.serper_provider import SerperShoppingProvider
from src.utils.formatting import format_inr
from src.utils.validation import to_float

log = logging.getLogger("decision_assistant")

# kept for backwards compatibility with earlier code/tests
CATEGORY_SYNONYMS = {"phone": ["phone"], "laptop": ["laptop"], "ssd": ["ssd"], "mouse": ["mouse"]}
USE_KEYWORDS = {
    "competitive gaming": ["competitive", "esports", "fps"], "gaming": ["gaming", "games", "gamer"],
    "coding": ["coding", "programming", "developer", "development"], "college": ["college", "student", "students", "study"],
    "office": ["office", "work from home", "business"], "photography": ["photography", "camera", "photos"],
    "video editing": ["video editing", "editing"], "everyday use": ["everyday", "daily use"],
}
FEATURE_PATTERNS = [r"\b\d+\s?(?:gb|tb)(?:\s?ram)?\b", r"\b5g\b", r"\bamoled\b", r"\boled\b", r"\bnvme\b", r"\bsata\b",
                    r"\bwireless\b", r"\bwired\b", r"\bbacklit\b", r"\bfast charging\b", r"\blightweight\b",
                    r"\brgb\b", r"\b\d+\s?hz\b", r"\bdedicated gpu\b"]
PRICE_WORDS = ("cheapest", "lowest price", "lowest-priced", "lowest priced", "cheap", "least expensive")
MAX_REASONABLE_BUDGET = 10_000_000  # ₹1 crore
MIN_REASONABLE_BUDGET = 100


# ------------------------------------------------------------------ budget
def parse_budget(text: str) -> Optional[float]:
    """'under ₹70,000' / 'below 25k' / 'within 1.5 lakh' / 'laptop 60k' -> float (None if no budget stated)."""
    t = (text or "").lower().replace(",", "")
    m = re.search(r"(?:under|below|within|upto|up to|less than|max(?:imum)?|budget(?: of)?|around|<=?)\s*(?:rs\.?|inr|₹)?\s*(\d+(?:\.\d+)?)\s*(k|lakh|lac|l)?\b", t)
    if not m:
        m = re.search(r"(?:rs\.?|inr|₹)\s*(\d+(?:\.\d+)?)\s*(k|lakh|lac|l)?\b", t)
    if not m:
        m = re.search(r"\b(\d+(?:\.\d+)?)\s*(k|lakh|lac)\b", t)
    if not m:
        return None
    val, unit = float(m.group(1)), m.group(2)
    if unit == "k":
        val *= 1_000
    elif unit in ("lakh", "lac", "l"):
        val *= 100_000
    return val if val > 0 else None


def validate_budget(raw) -> Tuple[Optional[float], Optional[str]]:
    """Validate a budget typed in the form. Returns (value_or_None, error_message_or_None).

    An empty budget means 'no budget set' (never 'unlimited'): no budget filter is applied and none is implied.
    """
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        return None, None
    value = raw if isinstance(raw, (int, float)) and not isinstance(raw, bool) else parse_budget(str(raw)) or to_float(raw)
    if value is None:
        return None, "Enter the budget as an amount in rupees, for example 30000 or 30k."
    if value <= 0:
        return None, "Enter a budget above ₹0, or leave it blank."
    if value > MAX_REASONABLE_BUDGET:
        return None, f"That budget is above {format_inr(MAX_REASONABLE_BUDGET)}, which is probably a typo. Leave it blank for no limit."
    if value < MIN_REASONABLE_BUDGET:
        return None, f"Budgets under {format_inr(MIN_REASONABLE_BUDGET)} are unlikely. Did you mean a larger amount?"
    return float(value), None


# ------------------------------------------------------------------ parsing
def fallback_parse_query(text: str, known_brands: Optional[List[str]] = None) -> SearchCriteria:
    """Rule-based understanding of a request. Used whenever the AI is unavailable or its output is invalid."""
    low = (text or "").lower()
    it = parse_intent(text or "")
    c = SearchCriteria(query=(text or "").strip())
    c.max_budget = parse_budget(low)
    c.category = it.category
    for use, words in USE_KEYWORDS.items():
        if any(w in low for w in words):
            c.use_case = use
            break
    seen = []
    for pat in FEATURE_PATTERNS:
        for m in re.finditer(pat, low):
            f = re.sub(r"\s+", " ", m.group(0)).strip()
            if f not in seen:
                seen.append(f)
    if it.specific:  # storage/RAM already enforced by the structured intent
        seen = [f for f in seen if not re.fullmatch(r"\d+\s?(?:gb|tb)(?:\s?ram)?", f)]
    c.features = seen
    brands = list(known_brands or [])
    if it.brand:
        brands.append(it.brand)
    c.brands = [b for b in dict.fromkeys(brands) if re.search(rf"\b{re.escape(b.lower())}\b", low) or (it.brand and b == it.brand)]
    if any(w in low for w in PRICE_WORDS):
        c.priorities.append("lowest price")
    if re.search(r"\bwarranty\b", low):
        c.priorities.append("warranty")
    c.keywords = [w for w in re.findall(r"[a-z0-9]+", low) if len(w) > 1 and not w.isdigit()
                  and w not in ("best", "under", "below", "for", "the", "and", "with", "cheapest", "lowest", "price")]
    c.compare_queries = split_compare(text or "")
    return c


def merge_criteria(base: SearchCriteria, **over) -> SearchCriteria:
    """Apply explicit form inputs on top of parsed criteria (form values win when provided)."""
    for k, v in over.items():
        if v is None or v == "" or v == [] or v == 0 or v == 0.0 or v is False:
            continue
        if isinstance(v, list):
            setattr(base, k, list(dict.fromkeys(list(getattr(base, k)) + v)))
        else:
            setattr(base, k, v)
    return base


# ------------------------------------------------------------------ grouping / filtering / sorting
def _offer_dict(o: Product) -> dict:
    return {"seller": o.seller, "retailer": o.retailer, "price": o.price, "original_price": o.original_price, "url": o.url,
            "url_kind": o.url_kind, "source": o.source, "source_type": o.source_type, "retrieved_at": o.retrieved_at,
            "condition": o.condition, "shipping": o.shipping, "delivery": o.delivery, "availability": o.availability,
            "name": o.name, "rating": o.rating, "review_count": o.review_count}


def dedupe_products(products: List[Product]) -> List[Product]:
    """Group offers for the SAME product (brand+model+storage+RAM+colour+condition all equal).

    The cheapest offer represents the group; every other offer is kept in `other_offers`, nothing is hidden.
    """
    groups: Dict[str, List[Product]] = {}
    for p in products:
        groups.setdefault(identity_key(p), []).append(p)
    out = []
    for offers in groups.values():
        offers = sorted(offers, key=lambda o: (o.price, o.seller))
        best = offers[0]
        if not best.image_url:  # use the first real image any seller supplied for this exact product
            best.image_url = next((o.image_url for o in offers if o.image_url), None)
        if best.rating is None:
            rated = [o for o in offers if o.rating is not None]
            if rated:
                top = max(rated, key=lambda o: o.review_count or 0)
                best.rating, best.review_count = top.rating, top.review_count
        seen, others = {(best.seller, best.price)}, []
        for o in offers[1:]:
            if (o.seller, o.price) in seen:
                continue
            seen.add((o.seller, o.price))
            others.append(_offer_dict(o))
        best.other_offers = others
        out.append(best)
    return out


def apply_filters(products: List[Product], c: SearchCriteria) -> List[Product]:
    out = []
    cap = c.max_budget * (1 + max(c.budget_tolerance, 0)) if c.max_budget else None
    brands = {b.lower() for b in c.brands}
    sellers = {s.lower() for s in c.sellers}
    conds = {x.lower() for x in c.conditions}
    for p in products:
        if p.availability in ("out_of_stock", "unavailable", "discontinued"):
            continue
        if c.in_stock_only and p.availability not in ("in_stock", "limited_stock"):
            continue
        if cap is not None and p.price > cap:
            continue
        if c.min_budget and p.price < c.min_budget:
            continue
        if brands and p.brand.lower() not in brands:
            continue
        if sellers and p.seller.lower() not in sellers:
            continue
        if conds and (p.condition if p.condition != "unknown" else "new") not in conds:
            continue
        if c.category and p.category and p.category != c.category:
            continue
        out.append(p)
    return out


def sort_products(products: List[Product], key: str = "price") -> List[Product]:
    if key == "price_desc":
        return sorted(products, key=lambda p: (-p.price, p.name))
    if key == "rating":  # only compares products that actually have a rating; unrated go last
        return sorted(products, key=lambda p: (p.rating is None, -(p.rating or 0), p.price))
    return sorted(products, key=lambda p: (p.price, p.name))


def sort_groups(groups: List[Product], tiers: Dict[str, int], key: str = "relevance") -> List[Product]:
    if key == "relevance":
        return sorted(groups, key=lambda g: (tiers.get(identity_key(g), 9), -len(g.other_offers), g.price, g.name))
    return sort_products(groups, {"price": "price", "price_desc": "price_desc", "rating": "rating"}.get(key, "price"))


# ------------------------------------------------------------------ service
@dataclass
class ProviderStatus:
    provider: str
    ok: bool
    message: str
    count: int = 0
    mode: str = "demo"  # demo | live | cached


@dataclass
class SearchOutcome:
    products: List[Product] = field(default_factory=list)      # grouped, filtered, relevance-sorted (set by finalize)
    raw_products: List[Product] = field(default_factory=list)  # everything the providers returned
    statuses: List[ProviderStatus] = field(default_factory=list)
    mode: str = "demo"  # demo | live | cached | mixed
    raw_count: int = 0
    tiers: Dict[str, int] = field(default_factory=dict)
    suggestions: List[str] = field(default_factory=list)
    intent: Optional[Intent] = None
    offer_count: int = 0
    seller_count: int = 0


class ProductSearchService:
    def __init__(self, settings: Settings, providers: Optional[List[ProviderBase]] = None, cache: Optional[FileCache] = None):
        self.settings = settings
        if providers is None:
            providers = []
            for prov in (FlipkartAffiliateProvider(settings), SerpApiShoppingProvider(settings), SerperShoppingProvider(settings), ConfiguredApiProvider(settings)):
                if prov.is_available():
                    providers.append(prov)
        self.providers = providers
        self.cache = cache or FileCache(LOCAL_DIR / "cache", settings.cache_ttl_minutes, settings.cache_enabled)

    # network/provider stage (cached); filtering is separate so UI filters never re-query providers
    def fetch(self, c: SearchCriteria, force_refresh: bool = False) -> SearchOutcome:
        out = SearchOutcome()
        live = [p for p in self.providers if p.source_type == "live"]
        demo = [p for p in self.providers if p.source_type != "live"]
        results = self._run_all(live, c, force_refresh=force_refresh)
        collected: List[Product] = []
        modes = set()
        for prov, res in zip(live, results):
            if isinstance(res, Exception):
                msg = self.settings.redact(str(res)) if isinstance(res, ProviderError) else f"Unexpected error ({type(res).__name__})."
                log.warning("provider %s failed: %s", prov.name, msg)
                out.statuses.append(ProviderStatus(prov.name, False, msg, 0, "live"))
            else:
                items, mode = res
                collected += items
                out.statuses.append(ProviderStatus(prov.name, True, "OK", len(items), mode))
                if items:
                    modes.add(mode)
        use_demo = bool(demo) and (not live or (not collected and self.settings.allow_demo_fallback))
        if use_demo:
            for prov in demo:
                try:
                    items = prov.search(c)
                    collected += items
                    out.statuses.append(ProviderStatus(prov.name, True, "OK", len(items), "demo"))
                    modes.add("demo")
                except ProviderError as exc:
                    out.statuses.append(ProviderStatus(prov.name, False, str(exc), 0, "demo"))
        out.raw_products, out.raw_count = collected, len(collected)
        out.mode = "demo" if modes == {"demo"} or not modes else "cached" if modes == {"cached"} else "live" if modes == {"live"} else "mixed"
        return out

    def _run_all(self, providers: List[ProviderBase], c: SearchCriteria, force_refresh: bool = False):
        if not providers:
            return []

        def one(prov):
            try:
                return self._run(prov, c, force_refresh=force_refresh)
            except Exception as exc:  # collected, never raised: one broken provider must not break the page
                return exc
        with ThreadPoolExecutor(max_workers=min(4, len(providers))) as ex:
            return list(ex.map(one, providers))

    def _run(self, prov: ProviderBase, c: SearchCriteria, force_refresh: bool = False):
        from src.providers._shopping import search_text
        key = f"{prov.name}|{' '.join(search_text(c).lower().split())}"  # same words => same cache entry (saves API quota)
        cached = None if force_refresh else self.cache.get(key)
        if cached is not None:
            items = [Product.from_dict(d) for d in cached]
            for it in items:
                it.source_type = "cached"
            return items, "cached"
        items = prov.search(c)
        self.cache.set(key, [p.to_dict() for p in items])
        return items, "live"

    def finalize(self, out: SearchOutcome, c: SearchCriteria) -> SearchOutcome:
        """Relevance + filters + grouping on already-fetched offers (no network)."""
        parts = c.compare_queries or [c.query]  # "compare A and B" shows the union of what each part matches
        intent = parse_intent(parts[0])
        kept, tier_by_key, seen = [], {}, set()
        for part in parts:
            k_part, tiers = filter_relevant(out.raw_products, parse_intent(part))
            for p in k_part:
                key = identity_key(p)
                tier_by_key[key] = min(tier_by_key.get(key, 9), tiers[f"{p.id}|{p.seller}"])
                if (p.id, p.seller) not in seen:
                    seen.add((p.id, p.seller))
                    kept.append(p)
        seller_filter, c_nosell = c.sellers, SearchCriteria(**{**c.__dict__, "sellers": []})
        groups = dedupe_products(apply_filters(kept, c_nosell))
        if seller_filter:
            want = {s.lower() for s in seller_filter}
            groups = [g for g in groups if g.seller.lower() in want or any(o["seller"].lower() in want for o in g.other_offers)]
        out.products = sort_groups(groups, tier_by_key, "relevance")
        out.tiers, out.intent = tier_by_key, intent
        out.offer_count = sum(1 + len(g.other_offers) for g in groups)
        out.seller_count = len({g.seller for g in groups} | {o["seller"] for g in groups for o in g.other_offers})
        out.suggestions = suggestions(intent, out.raw_products) if not groups else []
        return out

    def search(self, c: SearchCriteria) -> SearchOutcome:
        return self.finalize(self.fetch(c), c)
