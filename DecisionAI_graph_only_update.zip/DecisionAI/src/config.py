"""Configuration: environment variables / .env file. No secrets are ever hardcoded."""
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
LOCAL_DIR = ROOT / ".local_data"

# Editable ranking weights. They are normalised at scoring time, so only ratios matter.
DEFAULT_WEIGHTS: Dict[str, float] = {
    "budget_fit": 0.10,
    "feature_match": 0.25,
    "price": 0.25,
    "rating": 0.20,
    "spec_strength": 0.20,
    "use_case": 0.15,
    "warranty": 0.05,
}

# User priorities nudge the weights (added before normalising).
PRIORITY_BOOSTS: Dict[str, Dict[str, float]] = {
    "lowest price": {"price": 0.30},
    "performance": {"spec_strength": 0.30, "feature_match": 0.15, "use_case": 0.10},
    "durability": {"rating": 0.10, "warranty": 0.15},
    "warranty": {"warranty": 0.25},
    "ratings": {"rating": 0.40},
}
PRIORITY_OPTIONS = list(PRIORITY_BOOSTS.keys())


def load_dotenv(path: Path) -> None:
    """Tiny .env reader (does not override variables already set in the environment)."""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key, value = key.strip(), value.strip().strip('"').strip("'")
        if key and key not in os.environ:
            os.environ[key] = value


def _bool(value: Optional[str], default: bool) -> bool:
    if value is None or value == "":
        return default
    return value.strip().lower() in ("1", "true", "yes", "on")


def _num(value: Optional[str], default: float) -> float:
    try:
        return float(value) if value not in (None, "") else default
    except ValueError:
        return default


@dataclass
class Settings:
    llm_provider: str = "openai_compatible"
    llm_api_key: str = ""
    llm_base_url: str = "https://api.openai.com/v1"
    llm_model: str = "gpt-4o-mini"
    llm_timeout: float = 30.0
    product_api_name: str = ""
    product_api_url: str = ""
    product_api_key: str = ""
    product_api_key_header: str = "Authorization"
    product_api_key_prefix: str = "Bearer"
    product_api_items_path: str = ""
    product_api_field_map: Optional[dict] = None
    product_api_timeout: float = 15.0
    amazon_affiliate_tag: str = ""
    serpapi_key: str = ""
    serper_key: str = ""
    allow_demo_fallback: bool = True
    flipkart_affiliate_id: str = ""
    flipkart_affiliate_token: str = ""
    db_path: str = ""
    host: str = "127.0.0.1"
    port: int = 8000
    contact_email: str = ""
    alert_check_minutes: float = 0.0
    log_level: str = "INFO"
    cache_enabled: bool = True
    cache_ttl_minutes: float = 180.0
    country: str = "IN"
    currency: str = "INR"

    @classmethod
    def from_env(cls, load_file: bool = True) -> "Settings":
        if load_file:
            load_dotenv(ROOT / ".env")
        e = os.environ.get
        field_map = None
        raw_map = e("PRODUCT_API_FIELD_MAP", "").strip()
        if raw_map:
            try:
                parsed = json.loads(raw_map)
                field_map = parsed if isinstance(parsed, dict) else None
            except json.JSONDecodeError:
                field_map = None
        return cls(
            llm_provider=e("LLM_PROVIDER", "openai_compatible") or "openai_compatible",
            llm_api_key=e("LLM_API_KEY", "").strip(),
            llm_base_url=(e("LLM_BASE_URL", "https://api.openai.com/v1") or "https://api.openai.com/v1").rstrip("/"),
            llm_model=e("LLM_MODEL", "gpt-4o-mini") or "gpt-4o-mini",
            llm_timeout=_num(e("LLM_TIMEOUT_SECONDS"), 30.0),
            product_api_name=e("PRODUCT_API_NAME", "").strip(),
            product_api_url=e("PRODUCT_API_URL", "").strip(),
            product_api_key=e("PRODUCT_API_KEY", "").strip(),
            product_api_key_header=e("PRODUCT_API_KEY_HEADER", "Authorization") or "Authorization",
            product_api_key_prefix=e("PRODUCT_API_KEY_PREFIX", "Bearer"),
            product_api_items_path=e("PRODUCT_API_ITEMS_PATH", "").strip(),
            product_api_field_map=field_map,
            product_api_timeout=_num(e("PRODUCT_API_TIMEOUT_SECONDS"), 15.0),
            amazon_affiliate_tag=e("AMAZON_AFFILIATE_TAG", "").strip(),
            serpapi_key=(e("SERPAPI_KEY", "") or e("SERPAPI_API_KEY", "")).strip(),
            serper_key=e("SERPER_API_KEY", "").strip(),
            allow_demo_fallback=_bool(e("ALLOW_DEMO_FALLBACK"), True),
            flipkart_affiliate_id=e("FLIPKART_AFFILIATE_ID", "").strip(),
            flipkart_affiliate_token=e("FLIPKART_AFFILIATE_TOKEN", "").strip(),
            db_path=e("DB_PATH", "").strip() or str(LOCAL_DIR / "decisionai.db"),
            host=e("HOST", "127.0.0.1") or "127.0.0.1",
            port=int(_num(e("PORT"), 8000)),
            contact_email=e("CONTACT_EMAIL", "").strip(),
            alert_check_minutes=_num(e("ALERT_CHECK_MINUTES"), 0.0),
            log_level=(e("LOG_LEVEL", "INFO") or "INFO").upper(),
            cache_enabled=_bool(e("CACHE_ENABLED"), True),
            cache_ttl_minutes=_num(e("CACHE_TTL_MINUTES"), 180.0),
            country=e("COUNTRY", "IN") or "IN",
            currency=e("CURRENCY", "INR") or "INR",
        )

    @property
    def ai_enabled(self) -> bool:
        return bool(self.llm_api_key)

    @property
    def live_enabled(self) -> bool:
        return bool(self.serpapi_key or self.serper_key or self.product_api_url or self.flipkart_affiliate_token)

    def redact(self, text: str) -> str:
        """Remove any configured secret from a string before it is shown or logged."""
        for secret in (self.llm_api_key, self.product_api_key, self.serpapi_key, self.serper_key, self.flipkart_affiliate_token):
            if secret and len(secret) >= 4:
                text = text.replace(secret, "***")
        return text
