"""Provider interface: add a new data source by subclassing ProviderBase."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import List

from src.models import Product, SearchCriteria


class ProviderError(Exception):
    """Raised for expected provider failures (timeouts, bad responses, rate limits). Message is user-safe."""


class ProviderBase(ABC):
    name: str = "provider"
    source_type: str = "live"  # "live" | "demo"

    def is_available(self) -> bool:
        return True

    @abstractmethod
    def search(self, criteria: SearchCriteria, limit: int = 40) -> List[Product]:
        """Return normalised products or raise ProviderError."""
