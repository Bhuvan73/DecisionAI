"""Orchestrates: understand request -> fetch offers -> filter/group -> rank -> (optional) AI explanation."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from src.config import Settings
from src.llm import LLMClient, LLMError
from src.models import RecommendationResult, SearchCriteria
from src.product_search import CATEGORY_SYNONYMS, ProductSearchService, SearchOutcome, fallback_parse_query, merge_criteria
from src.recommendation_engine import rank_products


@dataclass
class Fetched:
    """Everything network-bound for one query. Re-used while only filters/sorting change."""
    text: str
    criteria: SearchCriteria
    outcome: SearchOutcome
    ai_understood: bool = False
    messages: List[str] = field(default_factory=list)
    compare_outcomes: List[SearchOutcome] = field(default_factory=list)


@dataclass
class AssistantResult:
    criteria: SearchCriteria
    outcome: SearchOutcome
    result: RecommendationResult
    ai_understood: bool = False
    ai_explanation: Optional[Dict[str, str]] = None
    messages: List[str] = field(default_factory=list)  # user-facing notes about AI fallbacks
    compare_top: List = field(default_factory=list)    # best group for each part of a "compare A and B" query


class DecisionAssistant:
    def __init__(self, settings: Settings, search: Optional[ProductSearchService] = None, llm: Optional[LLMClient] = None):
        self.settings = settings
        self.search = search or ProductSearchService(settings)
        self.llm = llm or LLMClient(settings)
        self._expl_cache: Dict[str, Optional[Dict[str, str]]] = {}

    def fetch(self, text: str, overrides: Optional[dict] = None, use_ai: bool = True, force_refresh: bool = False) -> Fetched:
        msgs: List[str] = []
        criteria, ai_ok = None, False
        if use_ai and self.llm.available and text.strip():
            try:
                criteria = self.llm.parse_criteria(text, list(CATEGORY_SYNONYMS))
                ai_ok = criteria is not None
                if criteria is None:
                    msgs.append("The AI's interpretation could not be validated, so standard parsing was used.")
            except LLMError as exc:
                msgs.append(f"{exc} Standard parsing was used.")
        if criteria is None:
            criteria = fallback_parse_query(text)
        else:
            criteria.compare_queries = fallback_parse_query(text).compare_queries
        merge_criteria(criteria, **(overrides or {}))
        outcome = self.search.fetch(criteria, force_refresh=force_refresh)
        fetched = Fetched(text, criteria, outcome, ai_ok, msgs)
        if criteria.compare_queries:
            for part in criteria.compare_queries:
                sub = fallback_parse_query(part)
                sub.max_budget = criteria.max_budget
                sub_out = self.search.fetch(sub, force_refresh=force_refresh)
                fetched.compare_outcomes.append(sub_out)
                have = {(x.id, x.seller, x.price) for x in outcome.raw_products}
                outcome.raw_products += [x for x in sub_out.raw_products if (x.id, x.seller, x.price) not in have]
                outcome.statuses += sub_out.statuses
            outcome.raw_count = len(outcome.raw_products)
        return fetched

    def rank(self, fetched: Fetched, filters: Optional[dict] = None, weights: Optional[Dict[str, float]] = None,
             use_ai: bool = True) -> AssistantResult:
        """Filter, group and rank already-fetched offers. No provider calls happen here."""
        c = SearchCriteria(**fetched.criteria.__dict__)
        for k, v in (filters or {}).items():  # replace semantics: the UI owns these fields (clearing a filter must clear it)
            if hasattr(c, k):
                setattr(c, k, v)
        outcome = self.search.finalize(_clone(fetched.outcome), c)
        pool = outcome.products
        if not (c.conditions or (outcome.intent and outcome.intent.condition)):
            pool = [g for g in pool if g.condition not in ("refurbished", "used")] or pool  # picks default to new items
        result = rank_products(pool, c, weights)
        msgs = list(fetched.messages)

        compare_top = []
        for part in c.compare_queries:
            sc = fallback_parse_query(part)
            sc.max_budget = c.max_budget
            top = self.search.finalize(_clone(fetched.outcome), sc).products
            if top:
                compare_top.append(top[0])
        if c.compare_queries and not compare_top:
            msgs.append("None of the products you asked to compare could be found.")

        explanation = None
        if use_ai and self.llm.available and result.recommendations:
            sig = hashlib.sha1(json.dumps([c.query, [(r.label, r.scored.product.id, r.scored.product.price) for r in result.recommendations]]).encode()).hexdigest()
            if sig not in self._expl_cache:
                try:
                    self._expl_cache[sig] = self.llm.explain(result, c)
                    if self._expl_cache[sig] is None:
                        msgs.append("The AI explanation failed validation, so the built-in explanations are shown.")
                except LLMError as exc:
                    self._expl_cache[sig] = None
                    msgs.append(f"{exc} Built-in explanations are shown.")
            explanation = self._expl_cache.get(sig)
        return AssistantResult(c, outcome, result, fetched.ai_understood, explanation, msgs, compare_top)

    def run(self, text: str, overrides: Optional[dict] = None, weights: Optional[Dict[str, float]] = None,
            use_ai: bool = True) -> AssistantResult:
        return self.rank(self.fetch(text, overrides, use_ai), None, weights, use_ai)


def _clone(o: SearchOutcome) -> SearchOutcome:
    return SearchOutcome(raw_products=[_copy(p) for p in o.raw_products], statuses=o.statuses, mode=o.mode, raw_count=o.raw_count)


def _copy(p):
    from src.models import Product
    return Product.from_dict(p.to_dict())
