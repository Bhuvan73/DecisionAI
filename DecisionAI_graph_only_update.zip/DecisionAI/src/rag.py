"""Simple, genuine RAG: structured retrieval over stored product facts -> grounded LLM answer -> validation.

Sources are chunks (offers, specs, rating, price history, product meta) built from retrieved data. The LLM may only
use retrieved chunks and must cite them; answers that cite nothing or quote an unknown rupee amount are rejected and
replaced by a facts-only answer. No embeddings: with a handful of structured chunks, keyword retrieval is enough.
"""
from __future__ import annotations

import math
import re
from typing import Dict, List, Optional

from src.llm import LLMClient, LLMError, explanation_is_grounded
from src.utils.formatting import format_inr

PRICE_W = {"price", "cheap", "cheapest", "cost", "seller", "store", "stores", "lowest", "expensive", "pay", "deal", "worth", "more",
           "amazon", "flipkart", "croma", "buy", "cheaper", "value", "budget"}
SPEC_W = {"ram", "storage", "battery", "camera", "weight", "dpi", "sensor", "polling", "fps", "gaming", "display", "processor", "gpu",
          "performance", "wireless", "specs", "spec", "features", "screen", "speed", "better", "difference", "differences", "compare"}
HIST_W = {"history", "trend", "drop", "when", "wait", "increase", "earlier", "before", "previous", "recorded"}
RATE_W = {"rating", "ratings", "review", "reviews", "reliable", "quality", "rated"}
STOP = {"the", "a", "an", "is", "are", "of", "for", "to", "and", "or", "in", "on", "it", "this", "that", "which", "what", "one", "me", "my", "i", "do", "does", "than", "with"}

SYSTEM = ("You are a careful shopping advisor. Answer ONLY from the numbered SOURCES provided. Cite every factual statement "
          "with its source id like [S2]. Never state a price, rating, specification, warranty or availability that is not in the "
          "sources. If the sources do not contain the answer, say you don't have that information. Separate clearly what the "
          "sources say from your own judgement, and label judgement as 'My take:'. Be concise (under 150 words).")


def _tok(s: str) -> List[str]:
    return [t for t in re.findall(r"[a-z0-9]+", s.lower()) if t not in STOP]


def build_chunks(views: List[dict], hist: Optional[Dict[str, dict]] = None) -> List[dict]:
    """Turn product views (+ stored price-history stats) into citable fact chunks."""
    hist, chunks = hist or {}, []

    def add(kind, view, text):
        chunks.append({"id": f"S{len(chunks) + 1}", "type": kind, "product_key": view["key"], "product": view["name"], "text": text})

    for v in views:
        var = v.get("variant") or {}
        bits = [f"brand {v['brand']}" if v.get("brand") else "", f"category {v['category']}" if v.get("category") else "",
                f"{var['storage_gb']} GB storage" if var.get("storage_gb") else "", f"colour {var['color']}" if var.get("color") else "",
                f"condition {var['condition']}" if var.get("condition") not in (None, "unknown") else ""]
        add("meta", v, f"{v['name']}: " + ", ".join(b for b in bits if b) + f". Data source: {v.get('source') or 'unknown'} ({v.get('source_type')}).")
        for o in v.get("offers", []):
            if not o.get("available"):
                add("offer", v, f"{v['name']}: {o['seller']} has no verified price in the data retrieved.")
                continue
            extra = [o["availability"].replace("_", " ")] if o.get("availability") not in (None, "unknown") else []
            extra += [x for x in (o.get("shipping"), o.get("delivery")) if x]
            add("offer", v, f"{v['name']}: {o['seller']} lists {format_inr(o['price'])}" + (f" ({', '.join(extra)})" if extra else "") +
                (f", {format_inr(o['diff'])} above the lowest offer" if o.get("diff") else "") + ".")
        st = v.get("stats") or {}
        if st.get("comparable"):
            add("stats", v, f"{v['name']}: across {st['count']} verified offers the lowest price is {format_inr(st['lowest'])}, the average is "
                            f"{format_inr(st['average'])} and the highest is {format_inr(st['highest'])}.")
        if v.get("specs"):
            add("spec", v, f"{v['name']} specifications: " + "; ".join(f"{k.replace('_', ' ')} {val}" for k, val in v["specs"].items()) + ".")
        if v.get("rating") is not None:
            add("rating", v, f"{v['name']} is rated {v['rating']:.1f} out of 5" + (f" from {v['review_count']:,} reviews" if v.get("review_count") else "") + ".")
        h = hist.get(v["key"])
        if h:
            add("history", v, f"{v['name']} price history recorded by this app: lowest {format_inr(h['lowest'])}, highest {format_inr(h['highest'])}, "
                              f"average {format_inr(h['average'])} over {h['points']} day(s) ({h['first']} to {h['last']}).")
    return chunks


def retrieve(question: str, chunks: List[dict], k: int = 10) -> List[dict]:
    q = set(_tok(question))
    if not chunks:
        return []
    df: Dict[str, int] = {}
    toks = [set(_tok(c["text"] + " " + c["product"])) for c in chunks]
    for t in toks:
        for w in t:
            df[w] = df.get(w, 0) + 1
    boost = {"offer": 1.5 if q & PRICE_W else 0, "stats": 1.0 if q & PRICE_W else 0, "spec": 1.5 if q & SPEC_W else 0, "history": 1.5 if q & HIST_W else 0,
             "rating": 1.5 if q & RATE_W else 0, "meta": 0.3}
    scored = []
    for c, t in zip(chunks, toks):
        s = sum(math.log(1 + len(chunks) / df[w]) for w in q & t) + boost.get(c["type"], 0)
        scored.append((s, c))
    scored.sort(key=lambda x: -x[0])
    chosen = [c for s, c in scored[:k]]
    for key in {c["product_key"] for c in chunks}:  # every product always has its meta chunk so answers name it correctly
        meta = next(c for c in chunks if c["product_key"] == key and c["type"] == "meta")
        if meta not in chosen:
            chosen.append(meta)
    return sorted(chosen, key=lambda c: int(c["id"][1:]))


def allowed_amounts(chunks: List[dict]) -> List[float]:
    nums = [float(n.replace(",", "")) for c in chunks for n in re.findall(r"₹\s?([\d,]+(?:\.\d+)?)", c["text"])]
    return nums + [abs(a - b) for a in nums for b in nums]


def question_amounts(question: str) -> List[float]:
    """Rupee amounts the USER typed (e.g. their budget) may be repeated in an answer."""
    out = [float(n.replace(",", "")) for n in re.findall(r"₹\s?([\d,]+(?:\.\d+)?)", question or "")]
    try:
        from src.product_search import parse_budget
        b = parse_budget(question or "")
        if b:
            out.append(b)
    except Exception:
        pass
    return out


def validate_answer(text: str, chunks: List[dict], extra_amounts: Optional[List[float]] = None) -> Optional[str]:
    """Return None if the answer is acceptable, else the reason it was rejected."""
    if not isinstance(text, str) or not text.strip():
        return "empty answer"
    cited = set(re.findall(r"\[(S\d+)\]", text))
    ids = {c["id"] for c in chunks}
    if not cited:
        return "no source citations"
    if cited - ids:
        return "cited a source that was not provided"
    allowed = allowed_amounts(chunks) + list(extra_amounts or [])
    allowed += [abs(a - b) for a in allowed for b in allowed]
    if not explanation_is_grounded(text, allowed):
        return "quoted a price that is not in the sources"
    return None


def _prompt(question: str, chunks: List[dict], turns: Optional[List[dict]] = None) -> str:
    src = "\n".join(f"[{c['id']}] {c['text']}" for c in chunks)
    convo = "\n".join(f"{t.get('role', 'user').upper()}: {str(t.get('text', ''))[:300]}" for t in (turns or [])[-4:])
    return f"SOURCES:\n{src}\n\n" + (f"CONVERSATION SO FAR:\n{convo}\n\n" if convo else "") + f"QUESTION: {question}"


def facts_answer(question: str, chunks: List[dict], views: List[dict]) -> str:
    """Deterministic fallback: relevant sourced facts, no generation."""
    q = set(_tok(question))
    pick = [c for c in chunks if c["type"] != "meta"]
    if q & PRICE_W:
        pick = [c for c in pick if c["type"] == "offer"] or pick
    elif q & HIST_W:
        pick = [c for c in pick if c["type"] == "history"] or pick
    elif q & SPEC_W:
        pick = [c for c in pick if c["type"] in ("spec", "rating")] or pick
    pick = pick[:6]
    if not pick:
        return "I don't have that information in the data retrieved."
    note = ""
    if q & HIST_W and not any(c["type"] == "history" for c in chunks):
        note = "No price history has been recorded for these products yet. "
    return note + " ".join(f"{c['text']} [{c['id']}]" for c in pick)


def _cid(chunks: List[dict], key: str, kind: str, needle: str = "") -> str:
    for c in chunks:
        if c["product_key"] == key and c["type"] == kind and (not needle or needle in c["text"]):
            return f" [{c['id']}]"
    return ""


def _best_offer(v: dict) -> Optional[dict]:
    return next((o for o in v.get("offers", []) if o.get("available")), None)


def advice_answer(question: str, chunks: List[dict], views: List[dict]) -> str:
    """Deterministic buying advice from retrieved data only (used when no LLM is configured or its answer is rejected)."""
    from src.product_search import parse_budget
    q = question.lower()
    words = set(re.findall(r"[a-z0-9]+", q))
    out: List[str] = []
    budget = parse_budget(question) if words & {"budget", "under", "within", "below", "upto"} or "₹" in question else None
    priced = [(v, _best_offer(v)) for v in views]
    priced = [(v, o) for v, o in priced if o]
    if not priced:
        return "None of the selected products has a verified price in the data retrieved, so I can't advise on price."
    if budget:
        ok = sorted([(v, o) for v, o in priced if o["price"] <= budget], key=lambda x: (-(x[0].get("rating") or 0), x[1]["price"]))
        if ok:
            out.append(f"Within {format_inr(budget)}: " + "; ".join(f"{v['name']} at {format_inr(o['price'])} ({o['seller']}){_cid(chunks, v['key'], 'offer', o['seller'])}" for v, o in ok[:4]) + ".")
            out.append("They are ordered by listed rating, then price. Ratings only reflect what the listings report.")
        else:
            v, o = min(priced, key=lambda x: x[1]["price"])
            out.append(f"Nothing retrieved is within {format_inr(budget)}. The cheapest is {v['name']} at {format_inr(o['price'])} ({o['seller']}), {format_inr(o['price'] - budget)} over budget{_cid(chunks, v['key'], 'offer', o['seller'])}.")
        return " ".join(out)
    if len(views) >= 2 and words & {"variant", "variants", "compare", "cheaper", "expensive", "upgrade", "versus", "vs", "difference", "differences", "between"} and not words & {"seller", "sellers"}:
        comp = compare_views(views)
        cites = "".join(_cid(chunks, v["key"], "offer", o["seller"]) for v, o in priced)
        out.append(" ".join(comp["facts"][:5]) + cites)
        known = sorted(priced, key=lambda x: x[1]["price"])
        if len(known) >= 2:
            out.append(f"My take: choose {known[0][0]['name']} if price matters most; the extra {format_inr(known[-1][1]['price'] - known[0][1]['price'])} for {known[-1][0]['name']} is only worth it if you need the specification differences above. The data doesn't say which is better for your use.")
        return " ".join(out)
    v, o = priced[0]
    st = v.get("stats") or {}
    if words & {"pros", "cons", "advantage", "advantages", "disadvantage", "disadvantages"}:
        for v2, o2 in priced[:3]:
            pros, cons = [], []
            s2 = v2.get("stats") or {}
            if s2.get("comparable") and o2["price"] == s2["lowest"]:
                pros.append(f"lowest price among {s2['count']} offers")
            if v2.get("rating") and v2["rating"] >= 4.2 and (v2.get("review_count") or 0) >= 100:
                pros.append(f"rated {v2['rating']:.1f}/5 from {v2['review_count']:,} reviews")
            pros += [f"{k.replace('_', ' ')} {val}" for k, val in list(v2.get("specs", {}).items())[:2]]
            if not v2.get("rating"):
                cons.append("no rating in the data")
            elif (v2.get("review_count") or 0) < 50:
                cons.append("few reviews, so the rating is less reliable")
            if s2.get("count", 0) < 2:
                cons.append("only one seller found")
            out.append(f"{v2['name']}: advantages - {', '.join(pros) or 'none stated in the data'}; disadvantages - {', '.join(cons) or 'none evident in the data'}." + _cid(chunks, v2["key"], "offer", o2["seller"]))
        return " ".join(out)
    if words & {"cheapest", "cheap", "seller", "sellers", "lowest", "where", "who"} and not words & {"worth", "value"}:
        for v2, o2 in priced[:3]:
            others = [x for x in v2["offers"] if x.get("available") and x is not o2][:3]
            out.append(f"{v2['name']}: cheapest verified offer is {format_inr(o2['price'])} at {o2['seller']}{_cid(chunks, v2['key'], 'offer', o2['seller'])}." +
                       (" Others: " + ", ".join(f"{x['seller']} {format_inr(x['price'])}" for x in others) + "." if others else " No other seller was found."))
        return " ".join(out)
    # worth buying / value / default
    out.append(f"{v['name']}: the lowest verified price is {format_inr(o['price'])} at {o['seller']}{_cid(chunks, v['key'], 'offer', o['seller'])}.")
    if st.get("comparable"):
        pct = (st["average"] - st["lowest"]) / st["average"] * 100
        out.append(f"That is {pct:.0f}% below the average of {format_inr(st['average'])} across {st['count']} offers" + "".join(_cid(chunks, v["key"], "offer", x["seller"]) for x in v["offers"] if x.get("available")) + ".")
    else:
        out.append("Only one verified offer was found, so there's nothing to compare the price against.")
    hist = _cid(chunks, v["key"], "history")
    out.append(("Recorded price history exists" + hist + ", see the chart for how today's price compares.") if hist else
               "No price history has been recorded yet, so I can't tell whether this is an unusually good or bad time to buy.")
    if v.get("rating") is not None:
        n = v.get("review_count") or 0
        out.append(f"Listings rate it {v['rating']:.1f}/5" + (f" from {n:,} reviews" if n else "") + _cid(chunks, v["key"], "rating") + (" (few reviews, so treat the rating cautiously)." if n < 50 else "."))
    else:
        out.append("The data has no rating for it.")
    tail = "competitive" if st.get("comparable") and (st["average"] - st["lowest"]) / st["average"] >= 0.05 else "not clearly better than the other sellers'"
    out.append(f"My take: on price alone the best offer looks {tail}. I can't judge product quality beyond the listed rating and specifications.")
    return " ".join(out)


def answer(question: str, chunks: List[dict], views: List[dict], llm: Optional[LLMClient], turns: Optional[List[dict]] = None) -> dict:
    retrieved = retrieve(question, chunks)
    note = None
    if llm is not None and llm.available:
        try:
            text = llm.ask(SYSTEM, _prompt(question, retrieved, turns))
            problem = validate_answer(text, retrieved, question_amounts(question))
            if problem is None:
                return {"mode": "ai", "answer": text.strip(), "sources": retrieved, "note": None}
            note = f"The AI answer was discarded ({problem}); showing sourced facts instead."
        except LLMError as exc:
            note = f"{exc} Showing a rule-based answer instead."
    else:
        note = "No AI model is configured, so this answer is rule-based and uses only the retrieved data."
    text = advice_answer(question, chunks, views)
    cited = set(re.findall(r"\[(S\d+)\]", text))
    sources = sorted({c["id"]: c for c in retrieved + [c for c in chunks if c["id"] in cited]}.values(), key=lambda c: int(c["id"][1:]))
    return {"mode": "facts", "answer": text, "sources": sources, "note": note}


def compare_views(views: List[dict]) -> dict:
    """Deterministic comparison: table + factual differences. Always available, never generated."""
    names = [v["name"] + (f" ({v['variant']['storage_gb']} GB)" if (v.get("variant") or {}).get("storage_gb") else "") for v in views]
    keys = []
    for v in views:
        for k in v.get("specs", {}):
            if k not in keys:
                keys.append(k)
    rows = [["Lowest verified price"] + [format_inr((v.get("stats") or {}).get("lowest")) if (v.get("stats") or {}).get("lowest") else "—" for v in views],
            ["Seller"] + [next((o["seller"] for o in v.get("offers", []) if o.get("available")), "—") for v in views],
            ["Rating"] + [f"{v['rating']:.1f} ({v.get('review_count') or 0:,} reviews)" if v.get("rating") is not None else "—" for v in views]]
    diffs = []
    for k in keys:
        vals = [v.get("specs", {}).get(k) for v in views]
        rows.append([k.replace("_", " ").title()] + [("—" if x is None else str(x)) for x in vals])
        if len({str(x) for x in vals}) > 1:
            diffs.append(f"{k.replace('_', ' ')}: " + " vs ".join(f"{n} = {x if x is not None else 'not listed'}" for n, x in zip(names, vals)))
    prices = [(n, (v.get("stats") or {}).get("lowest")) for n, v in zip(names, views)]
    known = [(n, p) for n, p in prices if p]
    facts = []
    if len(known) >= 2:
        known.sort(key=lambda x: x[1])
        facts.append(f"Price: {known[0][0]} is {format_inr(known[-1][1] - known[0][1])} cheaper than {known[-1][0]} "
                     f"({format_inr(known[0][1])} vs {format_inr(known[-1][1])}, lowest verified offers).")
    facts += [f"Spec difference - {d}" for d in diffs]
    if not diffs:
        facts.append("No differing specifications are listed in the data retrieved.")
    return {"columns": names, "rows": rows, "facts": facts}
