import tempfile
from pathlib import Path

from src.assistant import DecisionAssistant
from src.cache import FileCache
from src.config import Settings
from src.data_validation import normalize_product
from src.llm import LLMClient, LLMError
from src.models import SearchCriteria
from src.product_search import ProductSearchService, fallback_parse_query
from tests.fixture_provider import DemoProvider
from src.recommendation_engine import bayesian_rating, effective_weights, feature_hit, rank_products


def mk(name, price, rating=4.0, reviews=500, **kw):
    return normalize_product({"name": name, "price": price, "brand": name.split()[0], "model": name.split(" ", 1)[-1],
                              "category": "phone", "rating": rating, "review_count": reviews, "seller": "S", **kw}, "t", "demo")


def labels(res):
    return {r.label: r.scored.product.name for r in res.recommendations}


def test_three_categories_with_enough_data():
    ps = [mk("Aa cheap", 8000, 3.9), mk("Bb mid", 12000, 4.3), mk("Cc top", 20000, 4.6), mk("Dd extra", 15000, 4.1)]
    res = rank_products(ps, SearchCriteria(max_budget=25000))
    got = labels(res)
    assert set(got) == {"Best Overall", "Lowest Price", "Best Value"} and got["Lowest Price"] == "Aa cheap"
    assert res.sufficient


def test_highest_rating_is_not_automatically_best():
    ps = [mk("Aa pricey", 60000, 4.9, 5), mk("Bb solid", 20000, 4.4, 3000), mk("Cc other", 22000, 4.2, 800)]
    res = rank_products(ps, SearchCriteria(max_budget=70000))
    assert labels(res)["Best Overall"] != "Aa pricey"  # 4.9 from 5 reviews is shrunk towards the prior


def test_bayesian_rating_shrinks_low_review_counts():
    assert bayesian_rating(5.0, 2) < 3.6 and bayesian_rating(5.0, 5000) > 4.9
    assert bayesian_rating(4.0, None) == 3.5


def test_empty_input():
    res = rank_products([], SearchCriteria())
    assert res.recommendations == [] and not res.sufficient and res.notes


def test_single_product_is_flagged_not_overclaimed():
    res = rank_products([mk("Aa only", 1000)], SearchCriteria())
    assert len(res.recommendations) >= 1 and not res.sufficient
    assert any("one qualifying product" in n for n in res.notes)


def test_missing_ratings_and_specs_do_not_crash():
    ps = [mk("Aa a", 100, rating=None, reviews=None), mk("Bb b", 200, rating=None, reviews=None, specs={"ram_gb": 8})]
    res = rank_products(ps, SearchCriteria())
    assert len(res.ranked) == 2 and any("No ratings" in n for n in res.notes)
    assert any("No rating data" in c for c in res.ranked[0].cons)


def test_tie_handling_is_deterministic_and_prefers_lower_price_then_name():
    ps = [mk("Bb same", 100), mk("Aa same", 100)]
    first = [s.product.name for s in rank_products(ps, SearchCriteria()).ranked]
    second = [s.product.name for s in rank_products(list(reversed(ps)), SearchCriteria()).ranked]
    assert first == second == ["Aa same", "Bb same"]


def test_feature_matching_and_hard_requirements():
    a = mk("Aa a", 100, specs={"ram_gb": 16, "storage_gb": 1000}, features=["5G", "NVMe"])
    assert feature_hit(a, "16gb ram") and feature_hit(a, "5g") and feature_hit(a, "1tb") and feature_hit(a, "nvme")
    assert not feature_hit(a, "32gb ram") and not feature_hit(a, "oled")
    b = mk("Bb b", 90, specs={"ram_gb": 8}, features=[])
    res = rank_products([a, b], SearchCriteria(features=["16gb ram", "5g"]))
    assert labels(res)["Best Overall"] == "Aa a"
    assert labels(res)["Lowest Price"] == "Aa a"  # b fails the features so it does not qualify as "cheapest suitable"


def test_no_product_matches_features_falls_back_with_note():
    res = rank_products([mk("Aa a", 100)], SearchCriteria(features=["oled", "5g"]))
    assert res.recommendations and any("closest matches" in n for n in res.notes)


def test_priority_changes_weights():
    base = effective_weights(None, [])
    price = effective_weights(None, ["lowest price"])
    assert abs(sum(base.values()) - 1) < 1e-9 and price["price"] > base["price"]
    ps = [mk("Aa cheap", 5000, 3.6, 900), mk("Bb good", 9000, 4.7, 900), mk("Cc mid", 7000, 4.1, 900)]
    assert labels(rank_products(ps, SearchCriteria(priorities=["lowest price"])))["Best Overall"] == "Aa cheap"
    assert labels(rank_products(ps, SearchCriteria(priorities=["ratings"])))["Best Overall"] == "Bb good"


def test_cheap_junk_cannot_win_best_value():
    ps = [mk("Aa junk", 500, 1.2, 3000, use_cases=["x"]), mk("Bb fine", 9000, 4.5, 3000), mk("Cc ok", 10000, 4.3, 3000)]
    res = rank_products(ps, SearchCriteria(features=[]))
    assert labels(res).get("Best Value") != "Aa junk"
    junk = [s for s in res.ranked if s.product.name == "Aa junk"][0]
    assert junk.quality < 0.7


def test_notes_never_claim_internet_wide_lowest_price():
    res = rank_products([mk("Aa a", 1), mk("Bb b", 2), mk("Cc c", 3)], SearchCriteria())
    assert any("not the entire internet" in n for n in res.notes)





# ---- AI fallback behaviour
class BrokenLLM(LLMClient):
    @property
    def available(self):
        return True
    def parse_criteria(self, q, cats):
        raise LLMError("The AI request timed out.")
    def explain(self, r, c):
        raise LLMError("The AI request timed out.")


class GarbageLLM(LLMClient):
    @property
    def available(self):
        return True
    def parse_criteria(self, q, cats):
        return None
    def explain(self, r, c):
        return None


def assistant(llm):
    s = Settings()
    return DecisionAssistant(s, ProductSearchService(s, [DemoProvider()], FileCache(Path(tempfile.mkdtemp()), 1, False)), llm)


def test_app_works_without_api_key():
    a = assistant(LLMClient(Settings()))
    assert not a.llm.available
    r = a.run("best laptop for coding under ₹60,000")
    assert r.result.recommendations and not r.ai_understood and r.ai_explanation is None and not r.messages
    assert all(x.scored.product.price <= 60000 for x in r.result.recommendations)


def test_llm_failure_falls_back_to_rule_based_with_message():
    r = assistant(BrokenLLM(Settings())).run("best phone under 25k")
    assert r.result.recommendations and not r.ai_understood and r.messages and "timed out" in r.messages[0]


def test_invalid_ai_output_is_rejected_gracefully():
    r = assistant(GarbageLLM(Settings())).run("best phone under 25k")
    assert r.result.recommendations and r.ai_explanation is None and len(r.messages) == 2


def test_form_overrides_beat_parsed_values():
    r = assistant(LLMClient(Settings())).run("best phone under 25k", {"max_budget": 15000.0, "brands": ["Aurora"]})
    assert r.criteria.max_budget == 15000 and all(s.product.brand == "Aurora" and s.product.price <= 15000 for s in r.result.ranked)


def test_secrets_are_redacted():
    s = Settings(llm_api_key="sk-abcdef123456", product_api_key="pk-zzzz9999")
    assert "sk-abcdef123456" not in s.redact("err sk-abcdef123456 and pk-zzzz9999")
