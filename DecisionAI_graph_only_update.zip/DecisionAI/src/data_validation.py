"""Normalise and validate raw product dicts from any source."""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import Any, List, Optional, Tuple
from urllib.parse import urlparse

from src.identity import canonical_retailer, identity_key, model_key, parse_title  # noqa: F401  (identity_key re-exported)
from src.models import Product
from src.utils.validation import clean_str_list, clean_url, to_float, to_int

AGGREGATOR_HOSTS = ("google.", "googleadservices.", "googleusercontent.")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def url_kind_for(url: Optional[str]) -> str:
    host = urlparse(url).netloc.lower() if url else ""
    return "aggregator" if any(a in host for a in AGGREGATOR_HOSTS) else "direct"


def _short_text(v: Any, limit: int = 80) -> Optional[str]:
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        v = f"{v}"
    return v.strip()[:limit] if isinstance(v, str) and v.strip() else None


def normalize_product(raw: Any, source: str, source_type: str, retrieved_at: Optional[str] = None,
                      default_currency: str = "INR") -> Optional[Product]:
    """Return a clean Product, or None if unusable (no name or no valid positive price)."""
    if not isinstance(raw, dict):
        return None
    name = raw.get("name")
    if not isinstance(name, str) or not name.strip():
        return None
    name = " ".join(name.split())
    price = to_float(raw.get("price"))
    if price is None or price <= 0:
        return None

    hint = raw.get("brand").strip() if isinstance(raw.get("brand"), str) else ""
    ident = parse_title(name, hint)
    brand = hint or ident.brand
    raw_model = raw.get("model").strip() if isinstance(raw.get("model"), str) else ""
    model = model_key(raw_model, brand) if raw_model else ident.model_key

    rating = to_float(raw.get("rating"))
    if rating is not None and not (0 <= rating <= 5):
        rating = None
    original = to_float(raw.get("original_price"))
    if not (raw.get("original_price_verified") is True and original is not None and original > price):
        original = None  # never show unverified "discounts"

    specs = raw.get("specs") if isinstance(raw.get("specs"), dict) else {}
    specs = {str(k): v for k, v in specs.items() if isinstance(v, (str, int, float)) and not isinstance(v, bool)}
    storage = to_int(raw.get("storage_gb")) or to_int(specs.get("storage_gb")) or to_int(specs.get("capacity_gb")) or ident.storage_gb
    ram = to_int(raw.get("ram_gb")) or to_int(specs.get("ram_gb")) or ident.ram_gb
    if storage and "storage_gb" not in specs and "capacity_gb" not in specs:
        specs["storage_gb"] = storage
    if ram and "ram_gb" not in specs:
        specs["ram_gb"] = ram

    cond = raw.get("condition") if isinstance(raw.get("condition"), str) else ""
    cond = cond.strip().lower()
    cond = {"pre-owned": "used", "renewed": "refurbished", "second hand": "used"}.get(cond, cond)
    if cond not in ("new", "refurbished", "used"):
        cond = ident.condition or "unknown"

    url = clean_url(raw.get("url"))
    seller_raw = raw.get("seller") if isinstance(raw.get("seller"), str) and raw.get("seller").strip() else "Unknown seller"
    retailer, seller = canonical_retailer(seller_raw.strip(), url if url_kind_for(url) == "direct" else None)
    pid = raw.get("id")
    if not isinstance(pid, (str, int)) or not str(pid).strip():
        pid = hashlib.sha1(f"{source}|{seller}|{name}".encode()).hexdigest()[:12]
    avail = raw.get("availability") if isinstance(raw.get("availability"), str) else "unknown"
    avail = avail.strip().lower().replace(" ", "_") or "unknown"
    kind = raw.get("url_kind") if raw.get("url_kind") in ("direct", "aggregator") else url_kind_for(url)

    return Product(
        id=str(pid), name=name, price=round(price, 2), brand=brand, model=model,
        category=str(raw.get("category") or "").strip().lower(), seller=seller,
        currency=str(raw.get("currency") or default_currency).upper(), original_price=original,
        url=url, image_url=clean_url(raw.get("image_url")),
        rating=rating, review_count=to_int(raw.get("review_count")), availability=avail, source=source,
        source_type=source_type, retrieved_at=retrieved_at or _now(), specs=specs,
        features=clean_str_list(raw.get("features")), use_cases=clean_str_list(raw.get("use_cases"), lower=True),
        warranty_months=to_int(raw.get("warranty_months")), condition=cond, storage_gb=storage, ram_gb=ram,
        color=(_short_text(raw.get("color"), 30) or ident.color).lower().replace("grey", "gray"),
        shipping=_short_text(raw.get("shipping")), delivery=_short_text(raw.get("delivery")),
        retailer=retailer, url_kind=kind,
    )


def normalize_products(raws: Any, source: str, source_type: str, retrieved_at: Optional[str] = None,
                       default_currency: str = "INR") -> Tuple[List[Product], int]:
    """Normalise a list; returns (valid_products, number_of_rejected_records)."""
    if not isinstance(raws, list):
        return [], 0
    products, rejected = [], 0
    for r in raws:
        p = normalize_product(r, source, source_type, retrieved_at, default_currency)
        if p is None:
            rejected += 1
        else:
            products.append(p)
    return products, rejected
