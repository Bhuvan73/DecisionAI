/* DecisionAI front end: plain JavaScript, no build step, no third-party libraries. The API key never reaches the browser. */
(() => {
"use strict";
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const inr = (n) => (n == null ? "—" : "₹" + Math.round(n).toLocaleString("en-IN"));
const when = (iso) => { if (!iso) return ""; const d = new Date(iso); return isNaN(d) ? "" : d.toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }); };
const ago = (iso) => { const m = Math.max(0, Math.round((Date.now() - new Date(iso)) / 60000)); return isNaN(m) ? "" : m < 1 ? "just now" : m < 90 ? m + " min ago" : m < 2880 ? Math.round(m / 60) + " h ago" : Math.round(m / 1440) + " days ago"; };
const state = { logos: {}, data: null, sel: 0, picks: new Set(), busy: false, recent: [] };

async function api(path, opts) {
  const r = await fetch(path, opts);
  let body = {};
  try { body = await r.json(); } catch (_) { /* non-JSON error page */ }
  if (!r.ok) { const e = new Error(body.error || "Request failed (" + r.status + ")."); e.info = body; throw e; }
  return body;
}
const post = (path, data) => api(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });

/* ---------- theme + routing ---------- */
const root = document.documentElement;
root.dataset.theme = localStorage.getItem("theme") || "light";
$("#theme").addEventListener("click", () => { root.dataset.theme = root.dataset.theme === "dark" ? "light" : "dark"; try { localStorage.setItem("theme", root.dataset.theme); } catch (_) {} });
const ROUTES = ["home", "compare", "tracker", "assistant", "trending", "stores", "faq", "about", "contact"];
function route() {
  const r = location.hash.replace(/^#\/?/, "") || "home";
  const name = ROUTES.includes(r) ? r : "home";
  ROUTES.forEach((x) => { $("#view-" + x).hidden = x !== name; });
  $$(".links a").forEach((a) => a.classList.toggle("on", a.dataset.route === name));
  ({ compare: loadCompare, tracker: loadTracker, assistant: loadAssistantPage, trending: loadTrending, stores: loadStores, contact: loadContact }[name] || (() => {}))();
  window.scrollTo(0, 0);
}
window.addEventListener("hashchange", route);

/* ---------- search ---------- */
const EXAMPLES = ["iPhone 16 128GB", "Samsung Galaxy S25", "Sony WH-1000XM5", "Lenovo LOQ RTX 4060", "OnePlus 13"];
$("#examples").innerHTML = '<span class="muted" style="font-size:.8rem">Try:</span> ' + EXAMPLES.map((e) => `<button type="button" data-q="${esc(e)}">${esc(e)}</button>`).join("");
$("#examples").addEventListener("click", (e) => { const b = e.target.closest("button[data-q]"); if (b) { $("#q").value = b.dataset.q; $("#search-form").requestSubmit(); } });
function setStatus(html, cls) { $("#status").innerHTML = html ? `<div class="${cls || "info"}">${html}</div>` : ""; }

$("#search-form").addEventListener("submit", async (ev) => {
  ev.preventDefault();
  if (state.busy) return;
  const text = $("#q").value.trim();
  if (!text) { setStatus("Type a product name or paste a product URL.", "err"); return; }
  // A manual search should retrieve fresh offers and record a new genuine snapshot.
  const body = /^https?:\/\//i.test(text) ? { url: text, refresh: true } : { query: text, refresh: true };
  ["budget", "brand", "category"].forEach((k) => { const v = $("#" + k).value.trim(); if (v) body[k] = v; });
  state.busy = true; $("#go").disabled = true;
  setStatus(`<span class="spin"></span>${body.url ? "Reading the page, then comparing offers…" : "Retrieving offers…"}`);
  try {
    state.data = await post("/api/search", body); state.sel = 0; state.picks = new Set();
    setStatus(""); render(); loadRecent(); loadAlerts();
  } catch (e) {
    $("#results").innerHTML = "";
    const i = e.info || {};
    if (i.code === "no_provider") setStatus(`<div class="setup"><b>Setup needed.</b> ${esc(e.message)}<br>Open the <code>.env</code> file, set <code>SERPAPI_KEY=…</code>, save, and restart the app.</div>`, "");
    else if (i.code === "url_unreadable") setStatus(`${esc(e.message)}${i.suggested_query ? `<br><span class="muted">From the link text, this might be:</span> <button type="button" class="btn sm" id="use-sug" data-q="${esc(i.suggested_query)}">Search “${esc(i.suggested_query)}”</button>` : ""}`, "err");
    else setStatus(esc(e.message), "err");
  } finally { state.busy = false; $("#go").disabled = false; }
});
$("#status").addEventListener("click", (e) => { const b = e.target.closest("#use-sug"); if (b) { $("#q").value = b.dataset.q; $("#search-form").requestSubmit(); } });

/* ---------- rendering ---------- */
const COLORS = ["#ea580c", "#2563eb", "#7c3aed", "#0f766e", "#be123c", "#4d7c0f", "#a16207"];
function logo(o) {
  const c = COLORS[[...o.seller].reduce((a, ch) => a + ch.charCodeAt(0), 0) % COLORS.length];
  const letters = esc(o.seller.replace(/[^A-Za-z0-9 ]/g, "").split(/\s+/).slice(0, 2).map((w) => w[0] || "").join("").toUpperCase());
  const img = o.retailer && state.logos[o.retailer] ? `<img src="/static/logos/${esc(state.logos[o.retailer])}" alt="" data-logo>` : "";
  return `<span class="logo-b" style="background:${c}">${img}<span>${letters}</span></span>`;
}
const KIND = { direct: "Direct retailer link", aggregator: "Link opens Google Shopping", search: "Search link (not a product page)" };
function tooltip(o) {
  if (o.kind === "direct") return `View this product on ${o.seller}`;
  if (o.kind === "aggregator") return `Open this listing (seller: ${o.seller}) via Google Shopping`;
  return `Search ${o.seller} for this product (a search page, not a direct product page)`;
}
function freshness(o) {
  const t = o.last_checked || o.retrieved_at; if (!t) return "";
  const cached = o.source_type === "cached";
  return cached ? `<span class="cached-tag" title="${esc(when(t))}">Cached · retrieved ${esc(ago(t))}</span>` : `<span title="${esc(when(t))}">Checked ${esc(ago(t))}</span>`;
}
function sellerCard(o, hiPrice, comparable) {
  const label = !o.available ? `Search on ${o.seller} ↗` : o.kind === "search" ? "Search for this product ↗" : "View Deal ↗";
  const diff = !o.available ? "" : o.is_lowest ? `<div class="s-diff lo">${comparable ? "Lowest price" : "Only offer found"}</div>` : `<div class="s-diff up">+${inr(o.diff)} vs lowest</div>`;
  const price = o.available ? `<div class="s-price ${comparable && o.price === hiPrice && !o.is_lowest ? "hi" : ""}">${inr(o.price)}${o.original_price ? ` <s class="muted" style="font-size:.75rem;font-weight:400">${inr(o.original_price)}</s>` : ""}</div>` : '<div class="s-price na">Price unavailable</div>';
  const rate = o.available && o.rating != null ? `<div class="s-rate">★ ${Number(o.rating).toFixed(1)}${o.review_count ? " (" + Number(o.review_count).toLocaleString("en-IN") + ")" : ""}</div>` : "";
  const meta = o.available ? [o.condition && !["unknown", "new"].includes(o.condition) ? o.condition : "", o.shipping || "", o.delivery || "", o.matches_pasted_link ? "matches your link" : ""].filter(Boolean).join(" · ") : "Not in the data retrieved";
  return `<a class="seller ${o.is_lowest && comparable ? "low" : ""} ${o.available ? "" : "na"}" href="${esc(o.url || "#")}" target="_blank" rel="noopener noreferrer sponsored" title="${esc(tooltip(o))}">
    <div class="s-top">${logo(o)}<span class="s-name">${esc(o.seller)}</span>${o.is_lowest && comparable ? '<span class="badge">LOWEST</span>' : ""}</div>
    ${price}${diff}${rate}<div class="s-meta">${esc(meta)}</div>${o.available ? `<div class="s-kind">${esc(KIND[o.kind] || "")}</div><div class="s-meta">${freshness(o)}${o.source ? " · " + esc(o.source) : ""}</div>` : ""}
    <span class="s-btn">${esc(label)}</span></a>`;
}
const gb = (n) => (n >= 1000 ? n / 1000 + " TB" : n + " GB");
function render() {
  const d = state.data, box = $("#results");
  if (!d.products.length) {
    const sug = d.suggestions.length ? `<p>Did you mean: ${d.suggestions.map((s) => `<button class="btn sm" data-sug="${esc(s)}">${esc(s)}</button>`).join(" ")}</p>` : "";
    box.innerHTML = `<div class="sec"><div class="card empty"><b>No offers found for “${esc(d.query)}”.</b><br>Check the spelling, try the model name only, or remove optional filters.${sug}${srcErrors(d)}</div></div>`;
    $("#ask-home").innerHTML = ""; return;
  }
  const p = d.products[state.sel] || d.products[0], v = p.variant || {};
  const offers = p.offers, verified = offers.filter((o) => o.available), st = p.stats, best = verified[0];
  const chips = [p.brand && `Brand: ${esc(p.brand)}`, p.variant_label && `Variant: ${esc(p.variant_label)}`, p.category && `Category: ${esc(p.category)}`].filter(Boolean).map((c) => `<span class="chip">${c}</span>`);
  const m = p.match || {};
  const matchChip = m.label ? `<span class="match ${esc(m.level)}">${esc(m.label)}</span>` : "";
  const variants = d.products.length > 1 ? `<div class="variants" aria-label="Matching products and variants">${d.products.map((x, i) => `<label class="variant ${i === state.sel ? "on" : ""}"><input type="checkbox" data-pick="${esc(x.key)}" ${state.picks.has(x.key) ? "checked" : ""} aria-label="Select to compare"><span data-sel="${i}">${esc(x.name)}${x.variant_label ? " · " + esc(x.variant_label) : ""} · ${inr(x.stats.lowest)}${x.match && x.match.level !== "exact" && x.match.label ? " · " + esc(x.match.label) : ""}</span></label>`).join("")}</div>
    <div style="margin-bottom:8px"><button type="button" class="btn sm" id="cmp-btn">Compare ticked products</button> <span class="muted" style="font-size:.78rem">Tick 2–4 products above</span></div>` : "";
  const ins = p.insight || { text: "", ai: false };
  const urlBox = d.url ? `<div class="notice" style="background:var(--amber-bg);color:var(--ink);font-weight:400"><b>Read from the page you pasted</b> (${esc(d.url.retailer_name)}, via ${esc(d.url.source)}): ${esc(d.url.title)}${d.url.brand ? " · " + esc(d.url.brand) : ""}${d.url.variant ? " · " + esc(d.url.variant) : ""}${d.url.price ? " · price on that page " + inr(d.url.price) : ""}. ${esc(d.url.notes[1])}</div>` : "";
  const statsHtml = st.comparable ? `<div class="stats4"><div class="stat lo"><small>Lowest price</small><b>${inr(st.lowest)}</b></div><div class="stat av"><small>Average price</small><b>${inr(st.average)}</b></div><div class="stat hi"><small>Highest price</small><b>${inr(st.highest)}</b></div><div class="stat sl"><small>Sellers</small><b>${st.count}</b></div></div>`
    : `<div class="stats4"><div class="stat lo"><small>Lowest price</small><b>${inr(st.lowest)}</b></div><div class="stat sl"><small>Sellers</small><b>${st.count}</b></div></div><div class="stat-note">${st.count === 1 ? "Only one verified offer was found, so average and highest prices aren't meaningful yet." : "No verified prices were retrieved for this product."}</div>`;
  const R = d.recommendations;
  const rec = (k, t) => R[k] ? `<div class="rec"><h3>${t}${R[k].ai ? '<span class="tag-ai">AI</span>' : ""}</h3><div class="n">${esc(R[k].name)}</div><p>${esc(R[k].reason)}</p></div>` : `<div class="rec"><h3>${t}</h3><p>Not enough evidence in the retrieved data to pick one.</p></div>`;
  const trig = (d.alerts_triggered || []).map((a) => `<div class="notice">🔔 Price alert reached: ${esc(a.product)} is ${inr(a.price)} at ${esc(a.seller)} (target ${inr(a.target)}).</div>`).join("");
  $("#results").innerHTML = `${trig}${urlBox}<div class="sec" style="margin-top:0">${variants}
  <div class="card product"><div class="pimg">${p.image_url ? `<img src="${esc(p.image_url)}" alt="" referrerpolicy="no-referrer" data-img>` : "No image provided"}</div>
   <div><div class="ptitle">${esc(p.name)}</div><div class="chips">${chips.join("")}${matchChip}</div>
    <div class="best">${best ? `<span class="big">${inr(best.price)}</span><span class="at">lowest current price at <b>${esc(best.seller)}</b></span>` : '<span class="at">No verified price retrieved</span>'}</div>
    <div class="insight"><b>${ins.ai ? "AI insight" : "Price insight"}</b>${esc(ins.text)}</div>
    <div class="actions">${best ? `<a class="btn primary" href="${esc(best.url)}" target="_blank" rel="noopener noreferrer sponsored" title="${esc(tooltip(best))}">${best.kind === "search" ? "Search for this product ↗" : "View best deal ↗"}</a>` : ""}
     <button type="button" class="btn" id="share">Share</button>
     <span class="alert-in"><input type="text" inputmode="numeric" id="alert-price" placeholder="Target ₹" aria-label="Target price"><button type="button" class="btn" id="alert-set">Set alert</button></span></div>
    <div class="fresh">${best ? freshness(best) : ""} <span id="alert-msg"></span></div></div></div>${statsHtml}</div>
  <div class="sec"><h2>Seller offers</h2><div class="sellers">${offers.map((o) => sellerCard(o, st.highest, st.comparable)).join("")}</div>
   ${d.affiliate ? '<p class="muted" style="font-size:.78rem">Some links are affiliate links; the site may earn a commission. This never affects ranking.</p>' : ""}</div>
  <div class="sec"><div class="card"><h2 style="margin-bottom:8px">Recommendations</h2>${d.ai.summary ? `<p class="muted" style="margin:0 0 10px"><span class="tag-ai" style="margin:0 6px 0 0">AI</span>${esc(d.ai.summary)}</p>` : ""}<div class="recs">${rec("best_overall", "Best Overall")}${rec("cheapest_suitable", "Cheapest Suitable Option")}${rec("best_value", "Best Value for Money")}</div>
   <p class="muted" style="font-size:.78rem;margin:10px 0 0">${d.ai.explained ? "Explanations written by AI from the retrieved data; " : "Rule-based explanations; "}prices and rankings are calculated by code. ${esc((d.notes || []).join(" "))}</p></div></div>
  <div class="sec"><div class="card" id="hist-card"></div></div>${srcErrors(d)}
  <div class="muted" style="font-size:.78rem">${d.seller_count} seller(s), ${d.offer_count} offer(s) across ${d.products.length} matched product(s) · data: ${esc(d.mode)}.</div>`;
  wireImages(); mountHistory($("#hist-card"), p.key);
  mountAssistant($("#ask-home"), () => keysFor(state.data, state.sel), "Ask about these products");
}
function srcErrors(d) {
  const bad = (d.sources || []).filter((s) => !s.ok), msgs = d.messages || [];
  return !bad.length && !msgs.length ? "" : `<p class="muted" style="font-size:.8rem">${bad.length ? "Some sources were unavailable: " + bad.map((s) => esc(s.name + " (" + s.message + ")")).join("; ") + ". " : ""}${msgs.map(esc).join(" ")}</p>`;
}
function wireImages() {
  $$("img[data-logo]").forEach((i) => i.addEventListener("error", () => i.remove(), { once: true }));
  $$("img[data-img]").forEach((i) => i.addEventListener("error", () => { i.parentElement.textContent = "Image unavailable"; }, { once: true }));
}
const keysFor = (d, sel) => (d ? [d.products[sel].key, ...d.products.filter((_, i) => i !== sel).map((x) => x.key)].slice(0, 4) : []);
$("#results").addEventListener("click", (e) => {
  const sug = e.target.closest("[data-sug]"); if (sug) { $("#q").value = sug.dataset.sug; $("#search-form").requestSubmit(); return; }
  const sel = e.target.closest("[data-sel]"); if (sel) { state.sel = +sel.dataset.sel; render(); return; }
  if (e.target.id === "share") return share();
  if (e.target.id === "alert-set") return setAlert();
  if (e.target.id === "cmp-btn") { if (state.picks.size < 2) { flash("Tick at least two products first."); return; } location.hash = "#/compare"; }
});
$("#results").addEventListener("change", (e) => { if (e.target.dataset.pick) { e.target.checked ? state.picks.add(e.target.dataset.pick) : state.picks.delete(e.target.dataset.pick); } });
async function share() {
  const p = state.data.products[state.sel], best = p.offers.find((o) => o.available);
  const text = `${p.name}${best ? " - lowest price " + inr(best.price) + " at " + best.seller : ""} (DecisionAI)`;
  try { if (navigator.share) await navigator.share({ title: p.name, text, url: location.href.split("#")[0] }); else { await navigator.clipboard.writeText(text + " " + location.href.split("#")[0]); flash("Copied to clipboard"); } }
  catch (_) { flash("Sharing was cancelled or isn't available here."); }
}
function flash(t) { const m = $("#alert-msg"); if (m) { m.textContent = " · " + t; setTimeout(() => (m.textContent = ""), 6000); } }

/* ---------- price history: own SVG chart, real observations only ---------- */
function mountHistory(card, key) {
  let range = "30", seller = "", h = null;
  async function load() {
    try { h = await api(`/api/products/${encodeURIComponent(key)}/history?seller=${encodeURIComponent(seller)}`, { cache: "no-store" }); }
    catch (e) { h = { available: false, message: e.message, series: [], sellers: [], observations: [] }; }
    draw();
  }
  function draw() {
    if (!h.available) { card.innerHTML = `<div class="chart-h"><h2>Price History</h2><button type="button" data-history-refresh>Refresh</button></div><div class="empty">${esc(h.message || "Price history starts when tracking begins.")}</div>`; return; }
    const days = { "7": 7, "30": 30, "90": 90, max: 0 }[range], cut = days ? Date.now() - days * 864e5 : 0;
    const s = h.series.filter((p) => new Date(p.ts).getTime() >= cut);
    const ranges = ["7", "30", "90", "max"].map((r) => `<button type="button" data-range="${r}" class="${range === r ? "on" : ""}">${r === "max" ? "Max" : r + " days"}</button>`).join("");
    const sel = `<select data-seller aria-label="Seller" style="padding:4px 10px;border-radius:999px;font-size:.8rem"><option value="">All sellers (lowest)</option>${h.sellers.map((x) => `<option value="${esc(x.id)}" ${seller === x.id ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select>`;
    let body;
    if (!s.length) body = '<div class="empty">No recorded prices in this date range. Try a longer range.</div>';
    else {
      const pr = s.map((p) => p.price), lo = Math.min(...pr), hi = Math.max(...pr), avg = pr.reduce((a, b) => a + b, 0) / pr.length;
      const obs = h.observations.filter((o) => new Date(o.observed_at).getTime() >= cut);
      body = `<div class="hstats"><div>Historical lowest<b style="color:var(--green)">${inr(lo)}</b></div><div>Historical average<b style="color:var(--orange-d)">${inr(avg)}</b></div><div>Historical highest<b style="color:var(--red)">${inr(hi)}</b></div></div><div class="chart" data-chart></div>
        <p class="muted" style="font-size:.76rem;margin:6px 0 0">${s.length} recorded collection point(s) · ${obs.length} observation(s). Only prices this app actually retrieved are shown${s.length < 2 ? ". Search again later to record another point; changed prices from later searches are included." : ""}.</p>
        <details class="obs"><summary>See every observation (when each price was collected)</summary><table><tr><th>Collected</th><th>Seller</th><th>Price</th></tr>${obs.slice().reverse().map((o) => `<tr><td>${esc(when(o.observed_at))}</td><td>${esc(o.seller)}</td><td>${inr(o.price)}</td></tr>`).join("")}</table></details>`;
    }
    card.innerHTML = `<div class="chart-h"><h2>Price History</h2>${sel}<div class="ranges">${ranges}</div><button type="button" data-history-refresh title="Reload saved price observations">↻</button></div>${body}`;
    if (s.length) drawChart($("[data-chart]", card), s);
  }
  card.onclick = (e) => { if (e.target.closest("[data-history-refresh]")) { load(); return; } if (e.target.dataset.range) { range = e.target.dataset.range; draw(); } };
  card.onchange = (e) => { if (e.target.matches("[data-seller]")) { seller = e.target.value; load(); } };
  load();
}
function drawChart(el, s) {
  const W = 900, H = 310, L = 86, R = 20, T = 18, B = 42;
  const t = s.map((p) => new Date(p.ts).getTime()), pr = s.map((p) => p.price);
  let lo = Math.min(...pr), hi = Math.max(...pr);
  if (lo === hi) { const spread = Math.max(lo * 0.015, 100); lo -= spread; hi += spread; }
  const pad = (hi - lo) * 0.08; lo -= pad; hi += pad;
  const t0 = Math.min(...t), t1 = Math.max(...t);
  const x = (v) => L + (t1 === t0 ? (W - L - R) / 2 : ((v - t0) / (t1 - t0)) * (W - L - R));
  const y = (v) => T + (1 - (v - lo) / (hi - lo)) * (H - T - B);
  const pts = s.map((p, i) => [x(t[i]), y(p.price)]);
  const grid = [0, .25, .5, .75, 1].map((f) => {
    const v = lo + (hi - lo) * f, yy = y(v);
    return `<line x1="${L}" x2="${W-R}" y1="${yy}" y2="${yy}" stroke="#d7d7d7" stroke-dasharray="5 5" opacity=".8"/><text x="${L-10}" y="${yy+4}" text-anchor="end" font-size="12" fill="#687080">${inr(v)}</text>`;
  }).join("");
  const sameDay = new Set(t.map((ms) => new Date(ms).toDateString())).size === 1;
  const fmt = (ms) => new Date(ms).toLocaleString("en-IN", sameDay
    ? { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }
    : { day: "numeric", month: "short" });
  // Smooth cubic Bézier curve through the real observation points (no synthetic data points).
  let curve = "";
  if (pts.length > 1) {
    curve = `M ${pts[0][0]} ${pts[0][1]}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
      const c1x = p1[0] + (p2[0] - p0[0]) / 6, c1y = p1[1] + (p2[1] - p0[1]) / 6;
      const c2x = p2[0] - (p3[0] - p1[0]) / 6, c2y = p2[1] - (p3[1] - p1[1]) / 6;
      curve += ` C ${c1x} ${c1y}, ${c2x} ${c2y}, ${p2[0]} ${p2[1]}`;
    }
  }
  const area = curve ? `${curve} L ${pts[pts.length-1][0]} ${H-B} L ${pts[0][0]} ${H-B} Z` : "";
  const path = curve ? `<path d="${area}" fill="url(#historyFill)"/><path d="${curve}" fill="none" stroke="#ff9200" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>` : "";
  const firstPointGuide = pts.length === 1 ? `<line x1="${pts[0][0]}" x2="${pts[0][0]}" y1="${T}" y2="${H-B}" stroke="#ff9200" stroke-dasharray="5 7" opacity=".55"/><text x="${Math.min(W-R-8,pts[0][0]+12)}" y="${Math.max(T+18,pts[0][1]-15)}" font-size="13" fill="#687080">First recorded price</text>` : "";
  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Price history chart" preserveAspectRatio="none"><defs><linearGradient id="historyFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#ffad36" stop-opacity=".48"/><stop offset="100%" stop-color="#ffad36" stop-opacity=".08"/></linearGradient></defs>${grid}${firstPointGuide}${path}${pts.map((p,i) => `<circle cx="${p[0]}" cy="${p[1]}" r="4.2" fill="#fff" stroke="#ff9200" stroke-width="2.5"><title>${esc(when(s[i].ts))}: ${inr(pr[i])} · ${esc(s[i].seller || "All sellers")}</title></circle>`).join("")}
    <text x="${L}" y="${H-10}" font-size="12" fill="#687080">${fmt(t0)}</text><text x="${W-R}" y="${H-10}" text-anchor="end" font-size="12" fill="#687080">${fmt(t1)}</text></svg><div class="tip" hidden></div>`;
  const tip = $(".tip", el), svg = $("svg", el);
  const move = (ev) => {
    const r = svg.getBoundingClientRect(), cx = ((ev.touches ? ev.touches[0].clientX : ev.clientX) - r.left) * (W / r.width);
    let k = 0; pts.forEach((p, i) => { if (Math.abs(p[0] - cx) < Math.abs(pts[k][0] - cx)) k = i; });
    tip.hidden = false; tip.textContent = `${when(s[k].ts)}: ${inr(pr[k])} · ${s[k].seller || "Lowest across sellers"}`;
    tip.style.left = (pts[k][0] / W) * r.width + "px"; tip.style.top = (pts[k][1] / H) * r.height + "px";
  };
  svg.addEventListener("mousemove", move); svg.addEventListener("touchstart", move, { passive: true }); svg.addEventListener("mouseleave", () => (tip.hidden = true));
}
/* ---------- alerts ---------- */
async function setAlert() {
  const p = state.data.products[state.sel], val = $("#alert-price").value.replace(/[,₹\s]/g, "");
  try { const r = await post("/api/alerts", { key: p.key, target_price: val }); flash(`Alert saved for ${inr(r.target_price)}. ${r.note}`); loadAlerts(); } catch (e) { flash(e.message); }
}
function alertsHtml(alerts) {
  return `<div class="sec"><div class="card"><div class="chart-h"><h2>Your price alerts</h2><button class="btn sm" data-check type="button">Check now</button></div><div data-amsg class="muted" style="font-size:.8rem"></div>
    ${alerts.map((a) => `<div class="alert-row"><span><b>${esc(a.product_name)}</b> · target ${inr(a.target_price)}</span><span>${a.active ? '<span class="live-tag">Active</span>' : `<span class="notice" style="margin:0;padding:2px 10px">Reached: ${inr(a.triggered_price)} at ${esc(a.triggered_seller || "")}</span>`} <button class="btn sm" data-del="${a.id}" type="button">Delete</button></span></div>`).join("")}
    <p class="muted" style="font-size:.76rem;margin:8px 0 0">Alerts trigger when a newly retrieved price reaches the target, and are checked only while this app is running.</p></div></div>`;
}
async function loadAlerts() {
  for (const sel of ["#trk-alerts"]) {
    const box = $(sel); if (!box) continue;
    try { const { alerts } = await api("/api/alerts"); box.innerHTML = alerts.length ? alertsHtml(alerts) : ""; } catch (_) { box.innerHTML = ""; }
  }
}
$("#trk-alerts").addEventListener("click", async (e) => {
  if (e.target.dataset.del) { await api("/api/alerts/" + e.target.dataset.del, { method: "DELETE" }); loadAlerts(); }
  if (e.target.matches("[data-check]")) { e.target.disabled = true; try { const r = await post("/api/alerts/check", {}); $("[data-amsg]").textContent = r.message; loadAlerts(); } catch (er) { $("[data-amsg]").textContent = er.message; } }
});

/* ---------- recent / pages ---------- */
function miniCard(i, extra = "") {
  return `<div class="mini ${extra}" data-search="${esc(i.name)}" data-key="${esc(i.key)}" role="button" tabindex="0"><div class="pimg">${i.image_url ? `<img src="${esc(i.image_url)}" alt="" referrerpolicy="no-referrer" data-img>` : "No image"}</div><b>${esc(i.name)}</b><span>${i.lowest != null ? "Lowest " + inr(i.lowest) : ""}${i.sellers ? " · " + i.sellers + " seller" + (i.sellers > 1 ? "s" : "") : ""}</span>${i.retrieved_at ? `<br><span>Retrieved ${esc(ago(i.retrieved_at))}</span>` : ""}${i.count ? `<br><span>Searched ${i.count}×</span>` : ""}</div>`;
}
function searchFromCard(el) {
  el.addEventListener("click", (e) => { const b = e.target.closest("[data-search]"); if (!b) return; location.hash = "#/"; $("#q").value = b.dataset.search; $("#search-form").requestSubmit(); });
}
async function loadRecent() {
  try {
    const { items } = await api("/api/recent"); state.recent = items;
    $("#recent-box").innerHTML = items.length ? `<div class="sec"><h2>Recently searched</h2><div class="cards">${items.map((i) => miniCard(i)).join("")}</div></div>` : "";
    wireImages();
  } catch (_) {}
}
searchFromCard($("#recent-box"));
async function candidates() {
  const { items } = await api("/api/recent"); state.recent = items;
  const have = new Set(items.map((i) => i.key)), extra = (state.data ? state.data.products : []).filter((p) => !have.has(p.key)).map((p) => ({ key: p.key, name: p.name, image_url: p.image_url, lowest: p.stats.lowest, sellers: p.stats.count, retrieved_at: p.retrieved_at }));
  return [...extra, ...items];
}
function pickList(el, list, max, multi, onChange, preset) {
  const chosen = new Set(preset || []);
  el.innerHTML = list.length ? list.map((i) => `<label class="mini pick ${chosen.has(i.key) ? "sel" : ""}"><input type="${multi ? "checkbox" : "radio"}" name="pk" value="${esc(i.key)}" ${chosen.has(i.key) ? "checked" : ""}><span>${miniCard(i).replace(/^<div class="mini ?/, "<div class=\"").replace(/ data-search="[^"]*"/, "").replace(/ role="button" tabindex="0"/, "")}</span></label>`).join("") : '<div class="empty">Search for a product first; products you have searched appear here.</div>';
  wireImages();
  el.onchange = () => { const v = $$("input", el).filter((i) => i.checked).map((i) => i.value).slice(0, max); chosen.clear(); v.forEach((k) => chosen.add(k)); $$("label", el).forEach((l) => l.classList.toggle("sel", $("input", l).checked)); onChange(v); };
}
async function loadCompare() {
  const list = await candidates().catch(() => []);
  pickList($("#cmp-list"), list, 4, true, (keys) => runCompare(keys), [...state.picks]);
  if (state.picks.size >= 2) runCompare([...state.picks]);
}
async function runCompare(keys, question) {
  const out = $("#cmp-out");
  if (keys.length < 2) { out.innerHTML = '<p class="muted">Tick at least two products.</p>'; return; }
  out.innerHTML = '<p><span class="spin"></span>Comparing…</p>';
  try {
    const r = await post("/api/compare", { keys, question }), t = r.table;
    out.innerHTML = `<div class="card" style="margin-top:12px"><div style="overflow-x:auto"><table class="cmp"><tr><th></th>${t.columns.map((c) => `<th>${esc(c)}</th>`).join("")}</tr>${t.rows.map((row) => `<tr>${row.map((c, i) => (i ? `<td>${esc(c)}</td>` : `<th>${esc(c)}</th>`)).join("")}</tr>`).join("")}</table></div>
      <h3 style="font-size:.95rem;margin:10px 0 4px">Differences (from the data)</h3><ul>${r.facts.map((f) => `<li>${esc(f)}</li>`).join("")}</ul>
      <h3 style="font-size:.95rem;margin:10px 0 4px">Answer</h3><div class="msg a" style="max-width:100%">${answerHtml(r)}</div>
      <form id="cmp-form" class="chat-f" style="padding:12px 0 0;border:0"><input id="cmp-q" type="text" maxlength="400" placeholder="Ask e.g. “Is the more expensive one worth paying more for?”"><button class="btn primary" type="submit">Ask</button></form></div>`;
    $("#cmp-form").addEventListener("submit", (e) => { e.preventDefault(); runCompare(keys, $("#cmp-q").value.trim() || undefined); });
  } catch (e) { out.innerHTML = `<div class="err">${esc(e.message)}</div>`; }
}
async function loadTracker() {
  const list = await candidates().catch(() => []);
  const box = $("#trk-list");
  box.innerHTML = list.length ? list.map((i) => miniCard(i)).join("") : '<div class="empty">Nothing is being tracked yet. Search for a product and its prices are saved from that moment on.</div>';
  wireImages();
  box.onclick = (e) => { const c = e.target.closest("[data-key]"); if (!c) return; $$(".mini", box).forEach((m) => m.classList.toggle("sel", m === c)); const d = $("#trk-detail"); d.innerHTML = `<div class="sec"><div class="card" id="trk-hist"></div></div>`; mountHistory($("#trk-hist"), c.dataset.key); };
  loadAlerts();
}
async function loadAssistantPage() {
  const list = await candidates().catch(() => []);
  pickList($("#asst-list"), list, 4, true, (keys) => { keysPage = keys; }, []);
  let keysPage = [];
  mountAssistant($("#asst-box"), () => (keysPage.length ? keysPage : list.slice(0, 1).map((i) => i.key)), "Ask about the selected products");
  $("#asst-list").onchange = (e) => { keysPage = $$("input", $("#asst-list")).filter((i) => i.checked).map((i) => i.value).slice(0, 4); $$("label", $("#asst-list")).forEach((l) => l.classList.toggle("sel", $("input", l).checked)); };
}
async function loadTrending() {
  try { const d = await api("/api/trending"); $("#trend-note").textContent = d.note; $("#trend-list").innerHTML = d.items.length ? d.items.map((i) => miniCard(i)).join("") : '<div class="empty">Nothing is trending yet.</div>'; wireImages(); } catch (e) { $("#trend-note").textContent = e.message; }
}
searchFromCard($("#trend-list"));
async function loadStores() {
  try {
    const d = await api("/api/stores");
    $("#stores-body").innerHTML = `<p class="muted">Offers come from the data providers below. Product links from these stores are recognised for URL search:</p><div class="chips">${d.retailers.map((r) => `<span class="chip">${esc(r.name)}</span>`).join("")}</div>
      <h3 style="margin:16px 0 6px;font-size:1rem">Data providers</h3><table><tr><th>Provider</th><th>Status</th></tr>${d.providers.map((p) => `<tr><td>${esc(p.name)}</td><td>${p.configured ? '<span class="live-tag">Configured</span>' : "Not configured"}</td></tr>`).join("")}</table>
      <p class="muted" style="font-size:.85rem">AI model: ${d.ai ? "configured" : "not configured (rule-based answers are used)"}.</p>`;
  } catch (e) { $("#stores-body").textContent = e.message; }
}
async function loadContact() {
  try { const d = await api("/api/stores"); $("#contact-body").innerHTML = d.contact_email ? `Email: <a href="mailto:${esc(d.contact_email)}">${esc(d.contact_email)}</a>` : "No contact address is configured. Set CONTACT_EMAIL in the .env file to show one here."; } catch (e) { $("#contact-body").textContent = e.message; }
}

/* ---------- AI assistant (RAG): reusable component ---------- */
function cites(t) { return esc(t).replace(/\[(S\d+)\]/g, '<span class="cite">$1</span>'); }
function answerHtml(r) {
  const src = r.sources && r.sources.length ? `<details class="src"><summary>Sources (${r.sources.length})</summary><ul>${r.sources.map((s) => `<li><b>${esc(s.id)}</b> ${esc(s.text)}</li>`).join("")}</ul></details>` : "";
  return `<span class="modeb ${r.mode === "ai" ? "ai" : "f"}">${r.mode === "ai" ? "AI answer" : "Rule-based answer"}</span>${cites(r.answer)}${r.note ? `<small>${esc(r.note)}</small>` : ""}${src}`;
}
const SUGGEST = ["Which seller is offering the cheapest price?", "Is this product worth buying?", "Which offer provides the best value?", "Should I choose the cheaper or the more expensive variant?", "What are the advantages and disadvantages?", "Which one should I buy within my budget?"];
function mountAssistant(el, getKeys, title) {
  el.innerHTML = `<div class="sec"><div class="asst"><h2>AI shopping assistant</h2><p class="muted" style="margin:0;font-size:.85rem">${esc(title)}. Answers use only retrieved data and cite sources; if data is missing it says so.</p>
    <div class="sugs">${SUGGEST.map((s) => `<button type="button">${esc(s)}</button>`).join("")}</div><div class="chat-log" data-log></div>
    <form class="chat-f" data-form><input type="text" maxlength="500" placeholder="Ask a question… (e.g. which is best under ₹60,000?)" aria-label="Question"><button class="btn primary" type="submit">Ask</button></form></div></div>`;
  const log = $("[data-log]", el), inp = $("input", $("[data-form]", el)); const turns = [];
  async function ask(q) {
    log.insertAdjacentHTML("beforeend", `<div class="msg u">${esc(q)}</div><div class="msg a" data-pend><span class="spin"></span>Thinking…</div>`); log.scrollTop = log.scrollHeight;
    try {
      const r = await post("/api/chat", { message: q, keys: getKeys(), history: turns.slice(-6) });
      $("[data-pend]", log).outerHTML = `<div class="msg a">${answerHtml(r)}</div>`; turns.push({ role: "user", text: q }, { role: "assistant", text: r.answer });
    } catch (er) { $("[data-pend]", log).outerHTML = `<div class="msg a">${esc(er.message)}</div>`; }
    log.scrollTop = log.scrollHeight;
  }
  $(".sugs", el).addEventListener("click", (e) => { if (e.target.tagName === "BUTTON") ask(e.target.textContent); });
  $("[data-form]", el).addEventListener("submit", (e) => { e.preventDefault(); const q = inp.value.trim(); if (q) { inp.value = ""; ask(q); } });
}

/* ---------- boot ---------- */
(async () => {
  route(); loadRecent();
  try { const h = await api("/api/health"); state.logos = h.logos || {}; if (!h.serpapi_configured && !h.providers) setStatus('<div class="setup"><b>Setup needed.</b> No SerpApi key is configured. Set <code>SERPAPI_KEY</code> in the <code>.env</code> file and restart the app to search real products.</div>', ""); } catch (_) {}
})();
})();
