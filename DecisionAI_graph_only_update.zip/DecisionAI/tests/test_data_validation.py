import json
import tempfile
from pathlib import Path

from src.data_validation import normalize_product, normalize_products
from src.llm import explanation_is_grounded, extract_json, validate_criteria_payload, validate_explanation_payload
from src.providers.configured_api_provider import dig, map_item
from src.utils.formatting import add_affiliate, buy_link, format_inr
from src.utils.validation import clean_url, to_float

GOOD = {"name": "Acme X1 Phone", "price": "₹12,999", "brand": "Acme", "rating": 4.2, "review_count": 120,
        "url": "https://shop.example.com/p/1", "category": "Phone", "specs": {"ram_gb": 8, "bad": [1]}}


def test_normalizes_price_strings_and_fields():
    p = normalize_product(GOOD, "src", "live")
    assert p.price == 12999.0 and p.category == "phone" and p.model == "x1"
    assert p.specs == {"ram_gb": 8}  # non-scalar spec dropped
    assert p.url == "https://shop.example.com/p/1"


def test_rejects_missing_name_or_bad_price():
    for bad in [{}, {"name": "x"}, {"name": "x", "price": 0}, {"name": "x", "price": -5},
                {"name": "x", "price": "abc"}, {"name": "", "price": 5}, "string", None, {"name": "x", "price": float("nan")}]:
        assert normalize_product(bad, "s", "live") is None


def test_malformed_external_data_is_survivable():
    products, rejected = normalize_products([GOOD, {"junk": 1}, 5, None], "s", "live")
    assert len(products) == 1 and rejected == 3
    assert normalize_products("not a list", "s", "live") == ([], 0)


def test_invalid_urls_are_dropped():
    for bad in ["javascript:alert(1)", "ftp://x.com/a", "http://", "not a url", "https://user:pw@shop.com/x",
                "https://nodot/x", "https://a.com/has space", None, 42]:
        assert clean_url(bad) is None
    assert normalize_product({**GOOD, "url": "javascript:alert(1)"}, "s", "live").url is None


def test_invalid_rating_and_unverified_discount_ignored():
    p = normalize_product({**GOOD, "rating": 9, "original_price": 20000}, "s", "live")
    assert p.rating is None and p.original_price is None
    q = normalize_product({**GOOD, "original_price": 20000, "original_price_verified": True}, "s", "live")
    assert q.original_price == 20000.0
    r = normalize_product({**GOOD, "original_price": 5000, "original_price_verified": True}, "s", "live")
    assert r.original_price is None  # "original" below price makes no sense


def test_to_float():
    assert to_float("1,299.50") == 1299.5 and to_float(True) is None and to_float("") is None


def test_inr_formatting():
    assert format_inr(1234567) == "₹12,34,567" and format_inr(999) == "₹999" and format_inr(70000) == "₹70,000"


def test_buy_link_direct_vs_search_fallback():
    direct = normalize_product(GOOD, "s", "live")
    url, label, is_direct, _ = buy_link(direct)
    assert is_direct and url == GOOD["url"] and label == "View Deal"
    nourl = normalize_product({**GOOD, "url": None}, "s", "demo")
    url, label, is_direct, _ = buy_link(nourl)
    assert not is_direct and "google.com/search" in url and "Search" in label


def test_affiliate_only_on_amazon_and_disclosed():
    u, applied = add_affiliate("https://www.amazon.in/dp/B0?tag=old", "mytag-21")
    assert applied and u.count("tag=") == 1 and "mytag-21" in u
    assert add_affiliate("https://shop.example.com/p", "mytag-21") == ("https://shop.example.com/p", False)
    assert add_affiliate("https://www.amazon.in/dp/B0", "") [1] is False


def test_api_field_mapping_helpers():
    item = {"title": "T", "offer": {"price": "10"}, "imgs": ["a", "b"]}
    assert dig(item, "offer.price") == "10" and dig(item, "imgs.1") == "b" and dig(item, "nope.x") is None
    assert map_item(item, {"name": "title", "price": "offer.price", "evil": "title"}) == {"name": "T", "price": "10"}


def test_ai_criteria_validation():
    ok = validate_criteria_payload({"category": "Laptop", "max_budget": "60000", "features": ["16GB RAM"],
                                    "priorities": ["lowest price", "hax"], "use_case": "Coding"}, "q", ["laptop", "phone"])
    assert ok.category == "laptop" and ok.max_budget == 60000 and ok.priorities == ["lowest price"] and ok.use_case == "coding"
    assert validate_criteria_payload({"category": "spaceship"}, "q", ["laptop"]) is None
    assert validate_criteria_payload("garbage", "q", ["laptop"]) is None
    assert validate_criteria_payload({"category": "laptop", "max_budget": -5}, "q", ["laptop"]).max_budget is None


def test_ai_output_parsing_and_grounding():
    assert extract_json('```json\n{"a": 1}\n```') == {"a": 1}
    assert extract_json("no json here") is None
    assert explanation_is_grounded("It costs ₹12,999.", [12999.0])
    assert not explanation_is_grounded("It costs ₹9,999.", [12999.0])
    assert validate_explanation_payload({"summary": "Fine at ₹100", "per_label": {}}, [5.0]) is None
    out = validate_explanation_payload({"summary": "Good", "per_label": {"Best Value": "ok", "Bogus": "x"}}, [])
    assert out == {"summary": "Good", "Best Value": "ok"}
