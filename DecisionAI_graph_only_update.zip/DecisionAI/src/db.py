"""SQLite persistence: PRODUCTS, OFFERS, PRICE_SNAPSHOTS (+ alerts, searches). Stdlib sqlite3.

Only prices genuinely retrieved from a data provider are ever written to price_snapshots.
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional

SCHEMA = """
CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY, title TEXT, brand TEXT, model TEXT, variant TEXT, image_url TEXT,
  created_at TEXT, category TEXT, snapshot TEXT, updated_at TEXT);
CREATE TABLE IF NOT EXISTS offers(id INTEGER PRIMARY KEY AUTOINCREMENT, product_id TEXT NOT NULL, seller TEXT NOT NULL, seller_id TEXT,
  price REAL NOT NULL, currency TEXT, product_url TEXT NOT NULL DEFAULT '', url_kind TEXT, source TEXT, last_checked TEXT,
  UNIQUE(product_id, seller, product_url));
CREATE INDEX IF NOT EXISTS ix_offers_product ON offers(product_id);
CREATE TABLE IF NOT EXISTS price_snapshots(id INTEGER PRIMARY KEY AUTOINCREMENT, offer_id INTEGER NOT NULL, price REAL NOT NULL,
  currency TEXT, observed_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_snap ON price_snapshots(offer_id, observed_at);
CREATE TABLE IF NOT EXISTS alerts(id INTEGER PRIMARY KEY AUTOINCREMENT, product_key TEXT NOT NULL, product_name TEXT,
  target_price REAL NOT NULL, currency TEXT, created_at TEXT, active INTEGER DEFAULT 1, triggered_at TEXT,
  triggered_price REAL, triggered_seller TEXT);
CREATE TABLE IF NOT EXISTS searches(id INTEGER PRIMARY KEY AUTOINCREMENT, query TEXT, product_key TEXT, searched_at TEXT, mode TEXT);
"""


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat(timespec="microseconds")


class Database:
    def __init__(self, path: str):
        self.path = str(path)
        os.makedirs(os.path.dirname(os.path.abspath(self.path)), exist_ok=True)
        self._lock = threading.Lock()
        with self.conn() as c:
            cols = [r["name"] for r in c.execute("PRAGMA table_info(products)").fetchall()]
            if "key" in cols:  # database from the previous layout: keep its tables aside, never delete data
                for t in ("products", "sellers", "price_observations"):
                    c.execute(f"ALTER TABLE {t} RENAME TO {t}_legacy")
            c.executescript(SCHEMA)

    @contextmanager
    def conn(self):
        c = sqlite3.connect(self.path, timeout=10)
        c.row_factory = sqlite3.Row
        try:
            yield c
            c.commit()
        finally:
            c.close()

    def ping(self) -> bool:
        try:
            with self.conn() as c:
                c.execute("SELECT 1 FROM products LIMIT 1")
            return True
        except sqlite3.Error:
            return False

    # ---------------------------------------------------------------- products
    def upsert_product(self, pid: str, view: dict, now: Optional[datetime] = None) -> None:
        v = view.get("variant") or {}
        label = view.get("variant_label") or ""
        t = iso(now or utcnow())
        with self._lock, self.conn() as c:
            c.execute("INSERT INTO products(id,title,brand,model,variant,image_url,created_at,category,snapshot,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) "
                      "ON CONFLICT(id) DO UPDATE SET title=excluded.title,brand=excluded.brand,model=excluded.model,variant=excluded.variant,"
                      "image_url=COALESCE(excluded.image_url,products.image_url),category=excluded.category,snapshot=excluded.snapshot,updated_at=excluded.updated_at",
                      (pid, view.get("name"), view.get("brand"), view.get("model"), label, view.get("image_url"), t, view.get("category"),
                       json.dumps(view, ensure_ascii=False), t))

    def get_product(self, pid: str) -> Optional[dict]:
        with self.conn() as c:
            r = c.execute("SELECT snapshot FROM products WHERE id=?", (pid,)).fetchone()
        try:
            return json.loads(r["snapshot"]) if r else None
        except ValueError:
            return None

    def product_row(self, pid: str) -> Optional[dict]:
        with self.conn() as c:
            r = c.execute("SELECT id,title,brand,model,variant,image_url,created_at,category,updated_at FROM products WHERE id=?", (pid,)).fetchone()
        return dict(r) if r else None

    # ---------------------------------------------------------------- offers + snapshots
    def record_offers(self, pid: str, offers: List[dict], now: Optional[datetime] = None, min_gap_hours: float = 6) -> int:
        """Upsert each offer and store a timestamped price snapshot (skipping an unchanged price seen within the gap).
        Returns the number of NEW snapshots."""
        now = now or utcnow()
        added = 0
        with self._lock, self.conn() as c:
            for o in offers:
                url = o.get("url") or ""
                c.execute("INSERT INTO offers(product_id,seller,seller_id,price,currency,product_url,url_kind,source,last_checked) VALUES(?,?,?,?,?,?,?,?,?) "
                          "ON CONFLICT(product_id,seller,product_url) DO UPDATE SET price=excluded.price,currency=excluded.currency,"
                          "url_kind=excluded.url_kind,source=excluded.source,last_checked=excluded.last_checked",
                          (pid, o["seller"], o.get("seller_id"), o["price"], o.get("currency", "INR"), url, o.get("url_kind"), o.get("source"), iso(now)))
                oid = c.execute("SELECT id FROM offers WHERE product_id=? AND seller=? AND product_url=?", (pid, o["seller"], url)).fetchone()["id"]
                last = c.execute("SELECT price, observed_at FROM price_snapshots WHERE offer_id=? ORDER BY observed_at DESC LIMIT 1", (oid,)).fetchone()
                if last and last["price"] == o["price"]:
                    try:
                        if now - datetime.fromisoformat(last["observed_at"]) < timedelta(hours=min_gap_hours):
                            continue
                    except ValueError:
                        pass
                c.execute("INSERT INTO price_snapshots(offer_id,price,currency,observed_at) VALUES(?,?,?,?)", (oid, o["price"], o.get("currency", "INR"), iso(now)))
                added += 1
        return added

    def list_offers(self, pid: str) -> List[dict]:
        with self.conn() as c:
            return [dict(r) for r in c.execute("SELECT * FROM offers WHERE product_id=? ORDER BY price, seller", (pid,)).fetchall()]

    def history(self, pid: str, seller: Optional[str] = None, days: int = 0, now: Optional[datetime] = None) -> List[dict]:
        sql = ("SELECT s.observed_at, o.seller, o.seller_id, s.price, o.product_url AS url, o.source FROM price_snapshots s "
               "JOIN offers o ON o.id=s.offer_id WHERE o.product_id=?")
        args: list = [pid]
        if seller:
            sql += " AND (o.seller=? OR o.seller_id=?)"
            args += [seller, seller]
        if days:
            sql += " AND s.observed_at>=?"
            args.append(iso((now or utcnow()) - timedelta(days=days)))
        with self.conn() as c:
            return [dict(r) for r in c.execute(sql + " ORDER BY s.observed_at", args).fetchall()]

    @staticmethod
    def daily_series(rows: List[dict]) -> List[dict]:
        """Lowest genuine price per collection batch, not per calendar day.

        Every search writes all its seller observations with one shared timestamp.
        Group by that full-precision timestamp so one search becomes one point, while
        two separate searches—even within the same second—remain separate points.
        """
        best: Dict[str, dict] = {}
        for r in rows:
            ts = r["observed_at"]
            bucket = ts  # Full-precision timestamp; offers in one search share it, separate searches remain distinct
            if bucket not in best or r["price"] < best[bucket]["price"]:
                best[bucket] = {"date": ts[:10], "ts": ts, "price": r["price"], "seller": r.get("seller")}
        return [best[k] for k in sorted(best)]

    @staticmethod
    def series_stats(series: List[dict]) -> Optional[dict]:
        if not series:
            return None
        prices = [p["price"] for p in series]
        return {"lowest": min(prices), "highest": max(prices), "average": round(sum(prices) / len(prices), 2),
                "points": len(prices), "first": series[0]["date"], "last": series[-1]["date"]}

    # ---------------------------------------------------------------- searches
    def add_search(self, query: str, pid: str, mode: str, now: Optional[datetime] = None) -> None:
        with self._lock, self.conn() as c:
            c.execute("INSERT INTO searches(query,product_key,searched_at,mode) VALUES(?,?,?,?)", (query, pid, iso(now or utcnow()), mode))

    def _join(self, rows) -> List[dict]:
        out = []
        for r in rows:
            snap = self.get_product(r["product_key"])
            if snap:
                out.append({"key": r["product_key"], "name": snap.get("name"), "image_url": snap.get("image_url"),
                            "lowest": (snap.get("stats") or {}).get("lowest"), "sellers": (snap.get("stats") or {}).get("count"),
                            "currency": snap.get("currency", "INR"), "retrieved_at": snap.get("retrieved_at"),
                            "count": r["c"] if "c" in r.keys() else None})
        return out

    def recent(self, limit: int = 8) -> List[dict]:
        with self.conn() as c:
            rows = c.execute("SELECT product_key, MAX(searched_at) t FROM searches WHERE product_key!='' GROUP BY product_key ORDER BY t DESC LIMIT ?", (limit,)).fetchall()
        return self._join(rows)

    def trending(self, limit: int = 8) -> List[dict]:
        """Most-searched products ON THIS INSTALL (real counts, not global popularity)."""
        with self.conn() as c:
            rows = c.execute("SELECT product_key, COUNT(*) c, MAX(searched_at) t FROM searches WHERE product_key!='' GROUP BY product_key ORDER BY c DESC, t DESC LIMIT ?", (limit,)).fetchall()
        return self._join(rows)

    # ---------------------------------------------------------------- alerts
    def add_alert(self, key: str, name: str, target: float, currency: str = "INR", now: Optional[datetime] = None) -> int:
        with self._lock, self.conn() as c:
            cur = c.execute("INSERT INTO alerts(product_key,product_name,target_price,currency,created_at,active) VALUES(?,?,?,?,?,1)", (key, name, target, currency, iso(now or utcnow())))
            return int(cur.lastrowid)

    def list_alerts(self) -> List[dict]:
        with self.conn() as c:
            return [dict(r) for r in c.execute("SELECT * FROM alerts ORDER BY active DESC, created_at DESC").fetchall()]

    def delete_alert(self, alert_id: int) -> bool:
        with self._lock, self.conn() as c:
            return c.execute("DELETE FROM alerts WHERE id=?", (alert_id,)).rowcount > 0

    def trigger_alerts(self, key: str, price: float, seller: str, now: Optional[datetime] = None) -> List[dict]:
        with self._lock, self.conn() as c:
            rows = [dict(r) for r in c.execute("SELECT * FROM alerts WHERE product_key=? AND active=1 AND target_price>=?", (key, price)).fetchall()]
            for r in rows:
                c.execute("UPDATE alerts SET active=0, triggered_at=?, triggered_price=?, triggered_seller=? WHERE id=?", (iso(now or utcnow()), price, seller, r["id"]))
        return rows
