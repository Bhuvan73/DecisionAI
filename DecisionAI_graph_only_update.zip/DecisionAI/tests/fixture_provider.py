"""TEST-ONLY provider backed by tests/fixtures/catalog.json (fictional brands/sellers). Never used by the application."""
from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional

from pathlib import Path as _P

DATA_DIR = _P(__file__).resolve().parent / "fixtures"
from src.data_validation import normalize_products
from src.models import Product, SearchCriteria
from src.providers.base import ProviderBase, ProviderError

STOP = {"best", "cheap", "cheapest", "under", "below", "for", "the", "a", "an", "with", "and", "find",
        "lowest", "price", "priced", "offer", "available", "good", "top", "buy", "me", "in", "of", "to"}


class DemoProvider(ProviderBase):
    name = "Demo dataset (sample data)"
    source_type = "demo"

    def __init__(self, path: Optional[Path] = None):
        self.path = Path(path) if path else DATA_DIR / "catalog.json"

    def search(self, criteria: SearchCriteria, limit: int = 40) -> List[Product]:
        try:
            payload = json.loads(self.path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ProviderError(f"Demo dataset could not be read ({type(exc).__name__}).")
        raws = payload.get("products", []) if isinstance(payload, dict) else payload
        products, _ = normalize_products(raws, self.name, "demo", retrieved_at=payload.get("generated", "") if isinstance(payload, dict) else "")
        if criteria.category:
            hits = [p for p in products if p.category == criteria.category]
        else:
            tokens = [t for t in criteria.query.lower().replace("-", " ").split() if t not in STOP and len(t) > 1]
            tokens += [k.lower() for k in criteria.keywords]
            hits = []
            for p in products:
                hay = " ".join([p.name, p.brand, p.category, *p.features, *p.use_cases]).lower()
                if tokens and any(t in hay for t in tokens):
                    hits.append(p)
        return hits[:limit]
